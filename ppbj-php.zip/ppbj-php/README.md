# Sistem Informasi Permintaan Pembelian Barang dan Jasa — PT. Potensi Bumi Sakti

Aplikasi web pengadaan resmi berbasis **PHP + MySQL (phpMyAdmin)** yang disusun mengikuti formulir **PPBJ (`FRM.APR.01.00`)**, **Bid Summary (Perbandingan Penawaran Vendor)**, **Purchase Order (PO Multi-PO & Edit PO)**, dan **Formulir Terima Barang/Jasa (`FTB revisi`)**.

## Alur Resmi Pengadaan (7 Tahap)
1. **Login & Pengajuan Form PPBJ (User / Pemohon)** — Pilih Divisi (dikelola Procurement), nomor PPBJ terisi **otomatis per divisi masing-masing** (misal `001/PPBJ/XI-2026/PBS-OIT` untuk IT dan `001/PPBJ/XI-2026/PBS-FIN` untuk Finance), input barang/jasa, peruntukan, harga anggaran, dan foto spesifikasi (`MENUNGGU_MANAGER`).
2. **Approval Atasan / Manager** — Tinjauan & Disposisi Operation (`MENUNGGU_DIR_OPS`).
3. **Approval Direktur Operasional** — Tinjauan & Disposisi Direksi (`MENUNGGU_DIR_KEU`).
4. **Approval Direktur Keuangan (Final Approval)** — Verifikasi anggaran & dana (`SIAP_BID`).
5. **Bid Summary (Procurement)** — Bandingkan harga 2–4 vendor referensi dari Master Vendor, pilih pemenang per item (1 Bid Summary dapat langsung di-split otomatis menjadi 1 atau beberapa PO sesuai vendor pemenang).
6. **Purchase Order / PO (Procurement)** — Menu **Purchase Order (PO)** di sidebar: generate otomatis dari Bid Summary atau pilih langsung tanpa ketik ulang, **Edit PO** (vendor, termin, qty, harga final), dan **Cetak PO**.
7. **Form Terima Barang/Jasa (FTB — Tahap Akhir)** — Pilih PO aktif untuk mengisi FTB, inspeksi jumlah *Accepted* / *Rejected*, catatan kondisi, serta tanda tangan Pemakai/Gudang & Procurement (`SELESAI_FTB`).

## Akun Login Demo (Password semua akun: `123456`)
| Username | Role | Nama | Tugas Utama |
|---|---|---|---|
| `pemohon` | Pemohon / User | Abdul Karim | Ajukan Form PPBJ & pantau progress |
| `manager` | Atasan / Manager | Bambang Sebastiar | Approval tahap 1 + Disposisi Operation |
| `dirops` | Direktur Operasional | Hendra Wijaya | Approval tahap 2 + Disposisi Direksi |
| `dirkeu` | Direktur Keuangan | Wesly Marugan Simatupang | Approval final (anggaran & dana) |
| `procurement` | Procurement | Siti Rahayu | Buat Bid Summary, Generate & Edit PO, Master Vendor, FTB |

## Instalasi di XAMPP / phpMyAdmin
1. Salin seluruh folder `ppbj-php` ke `C:\xampp\htdocs\ppbj-php\`.
2. Jalankan **Apache** dan **MySQL** dari XAMPP Control Panel.
3. Buka **phpMyAdmin** (`http://localhost/phpmyadmin`), klik tab **Import**, lalu pilih `/ppbj-php/database.sql` (penting: import ulang `database.sql` versi terbaru agar tabel `bid_summaries`, `bid_vendors`, `bid_items`, `purchase_orders`, dan `po_items` tersedia).
4. Buka di browser: `http://localhost/ppbj-php/login.php`.

## Modul Laporan Procurement (baru)
Menu di sidebar (untuk Procurement, Manager, Direksi, Admin — tidak tampil untuk Pemohon):

| Menu | Isi | Sumber data |
|---|---|---|
| **Cost Saving & KPI** | Saving per 14 kategori, Cost Avoidance, OTD Rate, Order Accuracy, SLA PR→PO (Total spent, Target, Achievement IDR/%, Note) | PPBJ/Logbook, PO/WO, Bid Summary, FTB |
| **Top 10 Transaksi** | 10 PO/WO terbesar: vendor, detail item, nilai, % dari total spent, saving, % dari total saving | PO/WO + Bid Summary |
| **Payment Term** | Jumlah & nilai order per termin (CBD, COD, Credit N days, DP/Progress, L/C, dst.) | PO/WO (Non-PO: penawaran pemenang) |
| **Order Tracking** | Per baris PO/WO: Order Qty, Total Value, Received Qty, Reject Qty, status | PO/WO + FTB |
| **Vendor & Compliance** | Top Performing, Under Watch, Governance (komparasi minimal 3 penawaran) + register SP/penalti/insiden K3 | PO/WO, FTB, Bid Summary, catatan vendor |

Semua laporan punya filter Bulan/Tahun, **Export .CSV**, dan **Cetak**.

**Setup:** tidak perlu import ulang. Saat login pertama aplikasi membuat otomatis tabel `report_settings`, `saving_targets`, `vendor_incidents` dan kolom `ppbj_items.kategori_pengadaan` (data lama dikategorikan otomatis dari nama barang). File `migration_laporan_procurement.sql` disediakan bila ingin menjalankannya manual di phpMyAdmin.

**Yang perlu diisi agar laporan bermakna:**
1. *Kategori* pada tiap item PPBJ (kolom baru di Form PPBJ; bila kosong ditebak otomatis dari nama barang). Item lama yang belum berkategori bisa diatur dari halaman Cost Saving.
2. *Target* saving per kategori & parameter KPI/SLA/compliance: menu Cost Saving → **Atur Target & Parameter** (Procurement/Admin).
3. *Catatan vendor* (SP, penalti, insiden K3): halaman Vendor & Compliance.
