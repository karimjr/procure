<?php
/**
 * Modul Laporan Procurement
 * ------------------------------------------------------------------
 * 1. Cost Saving & KPI Procurement
 * 2. Top 10 The Biggest Transaction
 * 3. Payment Term
 * 4. Order Tracking
 * 5. Vendor Performance & Compliance Highlights
 *
 * Sumber data (master data):
 *   - Procurement Logbook  : ppbj_requests -> ppbj_items -> po -> ftb
 *   - PO / WO              : purchase_orders + po_items
 *   - Bid Summary          : bid_summaries + bid_vendors + bid_items
 *   - FTB                  : ftb_receipts + ftb_items (penerimaan barang)
 */

const REPORT_SCHEMA_VERSION = '1';
const REPORT_UNCATEGORIZED = 'Belum dikategorikan';

const REPORT_INCIDENT_TYPES = [
    'SURAT_PERINGATAN' => 'Surat Peringatan (SP)',
    'PENALTI_KETERLAMBATAN' => 'Penalti Keterlambatan',
    'INSIDEN_K3' => 'Insiden K3',
    'PELANGGARAN_KEPATUHAN' => 'Pelanggaran Kepatuhan',
];

function report_categories(): array
{
    return [
        'Chemical',
        'Lubricant',
        'Kesehatan, Keselamatan Kerja & Lingkungan',
        'Information Technology & Communication',
        'Alat Tulis Kantor',
        'Mechanical Electrical Plumbing',
        'Laboratory',
        'Packaging',
        'Parts & Consumables',
        'Service',
        'Civil',
        'House Keeping',
        'Tools',
        'Vehicles',
    ];
}

function report_month_names(): array
{
    return [1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
}

/* ------------------------------------------------------------------
 *  Skema database (auto-migrasi, aman dijalankan berulang)
 * ------------------------------------------------------------------ */
function report_ensure_schema(PDO $pdo): void
{
    if (($_SESSION['report_schema_v'] ?? '') === REPORT_SCHEMA_VERSION) {
        return;
    }
    try {
        $pdo->exec(
            "CREATE TABLE IF NOT EXISTS report_settings (
                skey VARCHAR(60) NOT NULL PRIMARY KEY,
                svalue VARCHAR(255) NOT NULL,
                updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
             ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        );
        $pdo->exec(
            "CREATE TABLE IF NOT EXISTS saving_targets (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                periode VARCHAR(7) NOT NULL COMMENT 'YYYY (setahun) atau YYYY-MM (sebulan)',
                kategori VARCHAR(120) NOT NULL,
                target_amount DECIMAL(16,2) NOT NULL DEFAULT 0.00,
                updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY uq_periode_kategori (periode, kategori)
             ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        );
        $pdo->exec(
            "CREATE TABLE IF NOT EXISTS vendor_incidents (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                incident_date DATE NOT NULL,
                vendor_name VARCHAR(150) NOT NULL,
                jenis ENUM('SURAT_PERINGATAN','PENALTI_KETERLAMBATAN','INSIDEN_K3','PELANGGARAN_KEPATUHAN') NOT NULL,
                po_no VARCHAR(60) DEFAULT NULL,
                keterangan VARCHAR(255) DEFAULT NULL,
                dibuat_oleh VARCHAR(120) NOT NULL,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                KEY idx_vendor (vendor_name),
                KEY idx_date (incident_date)
             ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        );

        $colSt = $pdo->query(
            "SELECT COUNT(*) FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ppbj_items' AND COLUMN_NAME = 'kategori_pengadaan'"
        );
        if ((int)$colSt->fetchColumn() === 0) {
            $pdo->exec("ALTER TABLE ppbj_items ADD COLUMN kategori_pengadaan VARCHAR(80) DEFAULT NULL AFTER no_anggaran");
            // Backfill otomatis untuk data lama berdasarkan nama barang/jasa
            report_autocategorize($pdo);
        }

        $defaults = report_default_settings();
        $ins = $pdo->prepare("INSERT IGNORE INTO report_settings (skey, svalue) VALUES (?, ?)");
        foreach ($defaults as $k => $v) {
            $ins->execute([$k, (string)$v]);
        }
        $_SESSION['report_schema_v'] = REPORT_SCHEMA_VERSION;
    } catch (Throwable $e) {
        error_log('report_ensure_schema: ' . $e->getMessage());
    }
}

function report_default_settings(): array
{
    return [
        'target_otd_pct' => 95,          // target On-Time Delivery (%)
        'target_accuracy_pct' => 98,     // target Order Fulfillment Accuracy (%)
        'target_sla_pct' => 90,          // target % PO terbit dalam SLA
        'sla_pr_po_days' => 7,           // SLA lead time PR -> PO (hari kalender)
        'sla_start_basis' => 'FINAL_APPROVAL', // FINAL_APPROVAL | REQUEST_DATE
        'compliance_threshold' => 10000000,    // batas nilai transaksi wajib komparasi (Rp)
        'compliance_min_quotes' => 3,    // minimal jumlah penawaran
        'top_vendor_min_otd' => 95,      // syarat SLA vendor "Top Performing" (%)
        'watch_otd_below' => 80,         // OTD di bawah ini => vendor "Under Watch" (%)
    ];
}

function report_setting(PDO $pdo, string $key)
{
    static $cache = null;
    if ($cache === null) {
        $cache = report_default_settings();
        try {
            foreach ($pdo->query("SELECT skey, svalue FROM report_settings")->fetchAll() as $r) {
                $cache[$r['skey']] = $r['svalue'];
            }
        } catch (Throwable $e) {
            // tabel belum ada: gunakan default
        }
    }
    return $cache[$key] ?? null;
}

/* ------------------------------------------------------------------
 *  Kategori otomatis (tebakan berdasarkan kata kunci nama barang/jasa)
 * ------------------------------------------------------------------ */
function report_guess_category(string $name): ?string
{
    $n = strtolower($name);
    // Urutan penting: yang lebih spesifik dicek lebih dulu. Tanda * = awalan kata.
    $map = [
        'Service' => ['jasa', 'servis', 'service', 'kalibrasi*', 'perbaikan', 'sewa', 'rental', 'pelatihan', 'sertifikasi', 'uji riksa', 'maintenance', 'instalasi', 'pengerjaan'],
        'Lubricant' => ['oli', 'pelumas*', 'lubricant*', 'grease', 'gemuk'],
        'Kesehatan, Keselamatan Kerja & Lingkungan' => ['safety', 'apd', 'helm', 'sepatu', 'rompi', 'masker', 'sarung tangan', 'kacamata', 'earplug', 'apar', 'p3k', 'k3'],
        'Information Technology & Communication' => ['laptop', 'komputer*', 'pc', 'printer', 'router', 'switch', 'server', 'software', 'lisensi', 'cctv', 'handphone', 'monitor', 'toner', 'jaringan', 'ups', 'access point', 'radio'],
        'Laboratory' => ['laborat*', 'reagen*', 'pipet', 'beaker', 'erlenmeyer'],
        'Chemical' => ['kimia', 'chemical*', 'solvent', 'thinner', 'kaporit', 'soda api', 'asam', 'pelarut'],
        'Alat Tulis Kantor' => ['atk', 'kertas', 'pulpen', 'tinta', 'spidol', 'binder', 'stapler', 'amplop', 'map'],
        'Packaging' => ['kemasan', 'packaging', 'karung', 'plastik', 'pallet', 'karton', 'lakban'],
        'Civil' => ['semen', 'besi beton', 'beton', 'pasir', 'keramik', 'bangunan', 'pengecoran'],
        'House Keeping' => ['sapu', 'pel', 'sabun', 'pembersih', 'tisu', 'kebersihan', 'pewangi'],
        'Tools' => ['obeng', 'kunci', 'tang', 'bor', 'gerinda', 'palu', 'tools', 'toolkit', 'mesin las'],
        'Parts & Consumables' => ['filter', 'sparepart', 'spare part', 'suku cadang', 'seal', 'gasket', 'v-belt', 'belt', 'bearing', 'consumable*'],
        'Vehicles' => ['ban', 'mobil', 'motor', 'kendaraan', 'truk', 'aki', 'spooring', 'balancing'],
        'Mechanical Electrical Plumbing' => ['kabel', 'panel', 'pompa', 'pipa', 'genset', 'mcb', 'lampu', 'kran', 'valve', 'fitting', 'trafo', 'motor listrik'],
    ];
    foreach ($map as $cat => $words) {
        foreach ($words as $w) {
            $prefix = substr($w, -1) === '*';
            $kw = $prefix ? substr($w, 0, -1) : $w;
            $re = '/(?<![a-z0-9])' . preg_quote($kw, '/') . ($prefix ? '' : '(?![a-z0-9])') . '/u';
            if (preg_match($re, $n)) {
                return $cat;
            }
        }
    }
    return null;
}

function report_autocategorize(PDO $pdo): int
{
    $rows = $pdo->query(
        "SELECT id, nama_barang_jasa FROM ppbj_items WHERE kategori_pengadaan IS NULL OR kategori_pengadaan = ''"
    )->fetchAll();
    $upd = $pdo->prepare("UPDATE ppbj_items SET kategori_pengadaan = ? WHERE id = ?");
    $n = 0;
    foreach ($rows as $r) {
        $cat = report_guess_category((string)$r['nama_barang_jasa']);
        if ($cat !== null) {
            $upd->execute([$cat, (int)$r['id']]);
            $n++;
        }
    }
    return $n;
}

/* ------------------------------------------------------------------
 *  Periode & format
 * ------------------------------------------------------------------ */
function report_period(): array
{
    $hasYear = isset($_GET['tahun']) && $_GET['tahun'] !== '';
    $year = $hasYear ? (int)$_GET['tahun'] : (int)date('Y');
    if ($year < 2000 || $year > 2100) {
        $year = (int)date('Y');
    }
    if (isset($_GET['bulan']) && $_GET['bulan'] !== '') {
        $month = (int)$_GET['bulan'];
    } else {
        // tanpa parameter sama sekali -> default bulan berjalan; filter dikirim tapi bulan kosong -> setahun
        $month = $hasYear ? 0 : (int)date('n');
    }
    if ($month < 0 || $month > 12) {
        $month = 0;
    }
    $names = report_month_names();
    if ($month > 0) {
        $from = sprintf('%04d-%02d-01', $year, $month);
        $to = date('Y-m-t', strtotime($from));
        $label = $names[$month] . ' ' . $year;
    } else {
        $from = sprintf('%04d-01-01', $year);
        $to = sprintf('%04d-12-31', $year);
        $label = 'Tahun ' . $year;
    }
    return ['year' => $year, 'month' => $month, 'from' => $from, 'to' => $to, 'label' => $label];
}

function fmt_idr($v, bool $dash = true): string
{
    if ($v === null || $v === '') {
        return '-';
    }
    $f = (float)$v;
    if ($dash && abs($f) < 0.5) {
        return '-';
    }
    return ($f < 0 ? '-' : '') . number_format(abs($f), 0, ',', '.');
}

function fmt_pct($v, int $dec = 1): string
{
    if ($v === null || $v === '') {
        return '-';
    }
    return number_format((float)$v, $dec, ',', '.') . '%';
}

function fmt_qty($v): string
{
    $f = (float)$v;
    return rtrim(rtrim(number_format($f, 2, ',', '.'), '0'), ',');
}

function report_guard(array $user): void
{
    if (($user['role'] ?? '') === 'PEMOHON') {
        set_flash('Menu laporan hanya tersedia untuk Procurement, Manajemen, dan Admin.', 'error');
        redirect_to('index.php?page=dashboard');
    }
}

function report_can_edit(array $user): bool
{
    return in_array($user['role'] ?? '', ['PROCUREMENT', 'ADMIN'], true);
}

/* ------------------------------------------------------------------
 *  Dataset dasar: baris transaksi (PO/WO + Non-PO pemenang Bid Summary)
 * ------------------------------------------------------------------ */
function report_lines(PDO $pdo, string $from, string $to): array
{
    $quoteSub = "(SELECT COUNT(DISTINCT bq.bid_vendor_id) FROM bid_items bq
                  WHERE bq.ppbj_item_id = pi.id AND bq.total_penawaran > 0)";
    $sql = "
        SELECT 'PO' AS src, poi.id AS line_id, pi.id AS ppbj_item_id, po.ppbj_id AS ppbj_id,
               pi.kategori_pengadaan AS kategori, poi.nama_barang_jasa AS nama, poi.qty AS qty, poi.satuan AS satuan,
               po.id AS po_id, po.po_no AS po_no, po.order_type AS order_type, po.bid_id AS bid_id,
               po.vendor_name AS vendor_name, po.termin_pembayaran AS termin, po.po_date AS tx_date,
               COALESCE(pi.harga_unit * poi.qty, poi.subtotal) AS budget,
               poi.subtotal AS actual,
               {$quoteSub} AS quotes
        FROM po_items poi
        JOIN purchase_orders po ON po.id = poi.po_id
        LEFT JOIN ppbj_items pi ON pi.id = poi.ppbj_item_id
        WHERE po.status <> 'DRAFT' AND po.po_date BETWEEN ? AND ?
        UNION ALL
        SELECT 'NON_PO', NULL, pi.id, pi.ppbj_id,
               pi.kategori_pengadaan, pi.nama_barang_jasa, pi.jumlah, pi.satuan,
               NULL, NULL, NULL, bs.id,
               bv.vendor_name, bv.termin_pembayaran, bs.bid_date,
               pi.harga_anggaran, bi.total_penawaran,
               {$quoteSub}
        FROM bid_items bi
        JOIN bid_summaries bs ON bs.id = bi.bid_id
        JOIN bid_vendors bv ON bv.id = bi.bid_vendor_id
        JOIN ppbj_items pi ON pi.id = bi.ppbj_item_id
        WHERE bi.is_selected = 1
          AND (bi.jalur_pengadaan = 'NON_PO' OR pi.jalur_pengadaan = 'NON_PO')
          AND bs.status = 'FINAL'
          AND NOT EXISTS (SELECT 1 FROM po_items x WHERE x.ppbj_item_id = pi.id)
          AND bs.bid_date BETWEEN ? AND ?
        ORDER BY tx_date ASC, po_no ASC";
    $st = $pdo->prepare($sql);
    $st->execute([$from, $to, $from, $to]);
    $rows = $st->fetchAll();
    $known = array_flip(report_categories());
    foreach ($rows as &$r) {
        $r['budget'] = (float)$r['budget'];
        $r['actual'] = (float)$r['actual'];
        $r['saving'] = $r['budget'] - $r['actual'];
        $kat = trim((string)($r['kategori'] ?? ''));
        $r['kategori_norm'] = isset($known[$kat]) ? $kat : REPORT_UNCATEGORIZED;
        $r['order_key'] = $r['src'] === 'PO'
            ? 'PO-' . $r['po_id']
            : 'NP-' . $r['bid_id'] . '-' . md5((string)$r['vendor_name']);
        $r['vendor_name'] = (string)($r['vendor_name'] ?? '-');
    }
    unset($r);
    return $rows;
}

/** Kelompokkan baris transaksi menjadi "order" (1 PO = 1 order; Non-PO = per Bid + vendor). */
function report_orders(array $lines): array
{
    $orders = [];
    foreach ($lines as $l) {
        $k = $l['order_key'];
        if (!isset($orders[$k])) {
            $orders[$k] = [
                'key' => $k,
                'src' => $l['src'],
                'po_id' => $l['po_id'],
                'po_no' => $l['po_no'],
                'order_type' => $l['order_type'],
                'bid_id' => $l['bid_id'],
                'vendor_name' => $l['vendor_name'],
                'termin' => (string)($l['termin'] ?? ''),
                'tx_date' => $l['tx_date'],
                'names' => [],
                'actual' => 0.0,
                'budget' => 0.0,
                'saving' => 0.0,
                'quotes' => null,
            ];
        }
        $orders[$k]['names'][] = $l['nama'];
        $orders[$k]['actual'] += $l['actual'];
        $orders[$k]['budget'] += $l['budget'];
        $orders[$k]['saving'] += $l['saving'];
        $q = (int)$l['quotes'];
        $orders[$k]['quotes'] = $orders[$k]['quotes'] === null ? $q : min($orders[$k]['quotes'], $q);
    }
    foreach ($orders as &$o) {
        $o['quotes'] = (int)($o['quotes'] ?? 0);
    }
    unset($o);
    return $orders;
}

/* ------------------------------------------------------------------
 *  Target
 * ------------------------------------------------------------------ */
function report_targets(PDO $pdo, int $year, int $month): array
{
    $st = $pdo->prepare("SELECT periode, kategori, target_amount FROM saving_targets WHERE periode LIKE ?");
    $st->execute([$year . '%']);
    $by = [];
    foreach ($st->fetchAll() as $r) {
        $by[$r['kategori']][$r['periode']] = (float)$r['target_amount'];
    }
    $out = [];
    foreach ($by as $kat => $per) {
        $annual = $per[(string)$year] ?? null;
        if ($month > 0) {
            $key = sprintf('%04d-%02d', $year, $month);
            $out[$kat] = $per[$key] ?? ($annual !== null ? $annual / 12 : 0.0);
        } elseif ($annual !== null) {
            $out[$kat] = $annual;
        } else {
            $out[$kat] = array_sum($per);
        }
    }
    return $out;
}

/** Target persis untuk 1 periode (YYYY atau YYYY-MM) - dipakai halaman pengaturan. */
function report_targets_exact(PDO $pdo, string $periode): array
{
    $st = $pdo->prepare("SELECT kategori, target_amount FROM saving_targets WHERE periode = ?");
    $st->execute([$periode]);
    $out = [];
    foreach ($st->fetchAll() as $r) {
        $out[$r['kategori']] = (float)$r['target_amount'];
    }
    return $out;
}

/* ------------------------------------------------------------------
 *  Cost avoidance (selisih penawaran tertinggi vs pemenang Bid Summary)
 * ------------------------------------------------------------------ */
function report_cost_avoidance(PDO $pdo, string $from, string $to): array
{
    $st = $pdo->prepare(
        "SELECT bs.bid_no, bs.bid_date, pi.nama_barang_jasa, bv.vendor_name,
                bi.total_penawaran AS winner,
                (SELECT MAX(b2.total_penawaran) FROM bid_items b2
                  WHERE b2.bid_id = bi.bid_id AND b2.ppbj_item_id = bi.ppbj_item_id AND b2.total_penawaran > 0) AS highest,
                (SELECT COUNT(*) FROM bid_items b2
                  WHERE b2.bid_id = bi.bid_id AND b2.ppbj_item_id = bi.ppbj_item_id AND b2.total_penawaran > 0) AS n_quotes
         FROM bid_items bi
         JOIN bid_summaries bs ON bs.id = bi.bid_id
         JOIN bid_vendors bv ON bv.id = bi.bid_vendor_id
         JOIN ppbj_items pi ON pi.id = bi.ppbj_item_id
         WHERE bi.is_selected = 1 AND bs.status = 'FINAL' AND bs.bid_date BETWEEN ? AND ?"
    );
    $st->execute([$from, $to]);
    $spent = 0.0;
    $avoid = 0.0;
    $n = 0;
    foreach ($st->fetchAll() as $r) {
        if ((int)$r['n_quotes'] < 2) {
            continue;
        }
        $spent += (float)$r['winner'];
        $avoid += max(0.0, (float)$r['highest'] - (float)$r['winner']);
        $n++;
    }
    return ['spent' => $spent, 'avoidance' => $avoid, 'items' => $n];
}

/* ------------------------------------------------------------------
 *  Order tracking (per baris PO/WO) + penerimaan FTB
 * ------------------------------------------------------------------ */
function report_order_lines(PDO $pdo, string $from, string $to): array
{
    $ftbMatch = "f.po_id = po.id AND (fi.ppbj_item_id = poi.ppbj_item_id
                 OR (poi.ppbj_item_id IS NULL AND fi.perincian = poi.nama_barang_jasa))";
    $sql = "
        SELECT po.id AS po_id, po.po_no, po.order_type, po.po_date, po.vendor_name, po.status AS po_status,
               po.estimasi_kirim, po.lead_time_delivery, po.ppbj_id,
               poi.id AS line_id, poi.item_no, poi.nama_barang_jasa, poi.qty AS ordered, poi.satuan, poi.subtotal,
               COALESCE((SELECT SUM(fi.qty) FROM ftb_items fi JOIN ftb_receipts f ON f.id = fi.ftb_id WHERE {$ftbMatch}), 0) AS received,
               COALESCE((SELECT SUM(fi.qty_accepted) FROM ftb_items fi JOIN ftb_receipts f ON f.id = fi.ftb_id WHERE {$ftbMatch}), 0) AS accepted,
               COALESCE((SELECT SUM(fi.qty_rejected) FROM ftb_items fi JOIN ftb_receipts f ON f.id = fi.ftb_id WHERE {$ftbMatch}), 0) AS rejected
        FROM po_items poi
        JOIN purchase_orders po ON po.id = poi.po_id
        WHERE po.status <> 'DRAFT' AND po.po_date BETWEEN ? AND ?
        ORDER BY po.po_date DESC, po.id DESC, poi.item_no ASC";
    $st = $pdo->prepare($sql);
    $st->execute([$from, $to]);
    $rows = $st->fetchAll();
    foreach ($rows as &$r) {
        $r['ordered'] = (float)$r['ordered'];
        $r['received'] = (float)$r['received'];
        $r['accepted'] = (float)$r['accepted'];
        $r['rejected'] = (float)$r['rejected'];
        $r['subtotal'] = (float)$r['subtotal'];
        if ($r['received'] <= 0) {
            $r['track_status'] = 'BELUM';
        } elseif ($r['rejected'] > 0) {
            $r['track_status'] = 'REJECT';
        } elseif ($r['accepted'] + 0.0001 >= $r['ordered']) {
            $r['track_status'] = 'SELESAI';
        } else {
            $r['track_status'] = 'PARSIAL';
        }
    }
    unset($r);
    return $rows;
}

function report_track_status_meta(string $s): array
{
    return [
        'BELUM' => ['Belum Diterima', 'badge-slate'],
        'PARSIAL' => ['Diterima Sebagian', 'badge-amber'],
        'SELESAI' => ['Diterima Lengkap', 'badge-green'],
        'REJECT' => ['Ada Reject', 'badge-red'],
    ][$s] ?? [$s, 'badge-slate'];
}

/* ------------------------------------------------------------------
 *  Pengiriman per PO: On-Time Delivery
 * ------------------------------------------------------------------ */
function report_lead_days(?string $leadTime): ?int
{
    if ($leadTime === null || !preg_match('/(\d+)/', $leadTime, $m)) {
        return null;
    }
    $n = (int)$m[1];
    if (preg_match('/minggu|week/i', $leadTime)) {
        $n *= 7;
    }
    return $n;
}

function report_po_delivery(PDO $pdo, string $from, string $to): array
{
    $st = $pdo->prepare(
        "SELECT po.id AS po_id, po.po_no, po.order_type, po.po_date, po.estimasi_kirim, po.lead_time_delivery,
                po.vendor_name, po.status, po.subtotal_po, po.ppbj_id,
                p.request_date, p.dir_keu_date,
                (SELECT MAX(f.ftb_date) FROM ftb_receipts f WHERE f.po_id = po.id) AS last_ftb
         FROM purchase_orders po
         LEFT JOIN ppbj_requests p ON p.id = po.ppbj_id
         WHERE po.status <> 'DRAFT' AND po.po_date BETWEEN ? AND ?
         ORDER BY po.po_date ASC, po.id ASC"
    );
    $st->execute([$from, $to]);
    $today = date('Y-m-d');
    $rows = $st->fetchAll();
    foreach ($rows as &$r) {
        $due = $r['estimasi_kirim'];
        if (!$due) {
            $d = report_lead_days($r['lead_time_delivery']);
            $due = $d !== null ? date('Y-m-d', strtotime($r['po_date'] . " +{$d} days")) : null;
        }
        $r['due'] = $due;
        $r['delivery_status'] = 'NA';
        $r['days_late'] = 0;
        if ($due) {
            if ($r['last_ftb']) {
                if ($r['last_ftb'] > $due) {
                    $r['delivery_status'] = 'LATE';
                    $r['days_late'] = (int)round((strtotime($r['last_ftb']) - strtotime($due)) / 86400);
                } else {
                    $r['delivery_status'] = 'ONTIME';
                }
            } elseif ($today > $due) {
                $r['delivery_status'] = 'OVERDUE';
                $r['days_late'] = (int)round((strtotime($today) - strtotime($due)) / 86400);
            } else {
                $r['delivery_status'] = 'PENDING';
            }
        }
    }
    unset($r);
    return $rows;
}

/* ------------------------------------------------------------------
 *  Cost Saving & KPI (laporan #1)
 * ------------------------------------------------------------------ */
function report_cost_saving(PDO $pdo, array $period): array
{
    $from = $period['from'];
    $to = $period['to'];
    $lines = report_lines($pdo, $from, $to);
    $targets = report_targets($pdo, $period['year'], $period['month']);

    $cats = [];
    foreach (array_merge(report_categories(), [REPORT_UNCATEGORIZED]) as $c) {
        $cats[$c] = ['spent' => 0.0, 'saving' => 0.0, 'budget' => 0.0, 'count' => 0];
    }
    $uncat = [];
    foreach ($lines as $l) {
        $c = $l['kategori_norm'];
        $cats[$c]['spent'] += $l['actual'];
        $cats[$c]['saving'] += $l['saving'];
        $cats[$c]['budget'] += $l['budget'];
        $cats[$c]['count']++;
        if ($c === REPORT_UNCATEGORIZED && !empty($l['ppbj_item_id'])) {
            $uncat[(int)$l['ppbj_item_id']] = $l['nama'];
        }
    }

    $totSpent = array_sum(array_column($cats, 'spent'));
    $totSaving = array_sum(array_column($cats, 'saving'));
    $totBudget = array_sum(array_column($cats, 'budget'));
    $totTarget = 0.0;
    foreach (report_categories() as $c) {
        $totTarget += $targets[$c] ?? 0.0;
    }

    $pct = fn(float $a, float $b): ?float => $b > 0 ? $a / $b * 100 : null;

    $rows = [];
    $rows[] = [
        'no' => '1', 'label' => 'Saving cost by Category :', 'bold' => true, 'kind' => 'saving',
        'spent' => $totSpent, 'target' => $totTarget, 'target_fmt' => 'idr', 'ach' => $totSaving,
        'pct' => $pct($totSaving, $totTarget), 'goal' => 100.0,
        'note' => $totBudget > 0 ? 'Saving ' . fmt_pct($totSaving / $totBudget * 100) . ' dari total budget PPBJ ' . fmt_idr($totBudget) . '.' : '',
    ];
    foreach (array_merge(report_categories(), [REPORT_UNCATEGORIZED]) as $c) {
        $d = $cats[$c];
        if ($c === REPORT_UNCATEGORIZED && $d['count'] === 0) {
            continue;
        }
        $t = $targets[$c] ?? 0.0;
        $note = '';
        if ($d['count'] > 0) {
            $note = $d['count'] . ' item';
            if ($d['budget'] > 0) {
                $note .= '; saving ' . fmt_pct($d['saving'] / $d['budget'] * 100) . ' dari budget';
            }
        }
        $rows[] = [
            'no' => '', 'label' => $c, 'bold' => false, 'kind' => 'saving', 'italic' => $c === REPORT_UNCATEGORIZED,
            'spent' => $d['spent'], 'target' => $t, 'target_fmt' => 'idr', 'ach' => $d['saving'],
            'pct' => $pct($d['saving'], $t), 'goal' => 100.0, 'note' => $note,
        ];
    }

    // 2. Cost avoidance
    $ca = report_cost_avoidance($pdo, $from, $to);
    $caTarget = $targets['__COST_AVOIDANCE'] ?? 0.0;
    $rows[] = [
        'no' => '2', 'label' => 'Cost Avoidance', 'bold' => true, 'kind' => 'saving',
        'spent' => $ca['spent'], 'target' => $caTarget, 'target_fmt' => 'idr', 'ach' => $ca['avoidance'],
        'pct' => $pct($ca['avoidance'], $caTarget), 'goal' => 100.0,
        'note' => 'Selisih penawaran tertinggi vs pemenang Bid Summary (' . $ca['items'] . ' item dengan minimal 2 penawaran).',
    ];

    // 3. OTD
    $deliv = report_po_delivery($pdo, $from, $to);
    $otdEval = 0; $otdOk = 0; $otdLate = 0; $otdPending = 0; $otdSpent = 0.0;
    foreach ($deliv as $d) {
        if ($d['delivery_status'] === 'ONTIME') { $otdEval++; $otdOk++; $otdSpent += (float)$d['subtotal_po']; }
        elseif (in_array($d['delivery_status'], ['LATE', 'OVERDUE'], true)) { $otdEval++; $otdLate++; $otdSpent += (float)$d['subtotal_po']; }
        elseif ($d['delivery_status'] === 'PENDING') { $otdPending++; }
    }
    $otdTarget = (float)report_setting($pdo, 'target_otd_pct');
    $otdPct = $otdEval > 0 ? $otdOk / $otdEval * 100 : null;
    $rows[] = [
        'no' => '3', 'label' => 'On-Time Delivery (OTD) Rate', 'bold' => true, 'kind' => 'kpi',
        'spent' => $otdSpent, 'target' => $otdTarget, 'target_fmt' => 'pct', 'ach' => null,
        'pct' => $otdPct, 'goal' => $otdTarget,
        'note' => "{$otdOk} dari {$otdEval} PO/WO tiba sesuai estimasi kirim ({$otdLate} terlambat/melewati jatuh tempo"
            . ($otdPending > 0 ? "; {$otdPending} belum jatuh tempo" : '') . ').',
    ];

    // 4. Order accuracy (per PO)
    $olines = report_order_lines($pdo, $from, $to);
    $byPo = [];
    foreach ($olines as $o) {
        $byPo[$o['po_id']]['status'] = $o['po_status'];
        $byPo[$o['po_id']]['value'] = ($byPo[$o['po_id']]['value'] ?? 0) + $o['subtotal'];
        $byPo[$o['po_id']]['rej'] = ($byPo[$o['po_id']]['rej'] ?? 0) + $o['rejected'];
        $byPo[$o['po_id']]['recv'] = ($byPo[$o['po_id']]['recv'] ?? 0) + $o['received'];
        $byPo[$o['po_id']]['short'] = ($byPo[$o['po_id']]['short'] ?? false) || ($o['accepted'] + 0.0001 < $o['ordered']);
    }
    $accEval = 0; $accOk = 0; $accSpent = 0.0;
    foreach ($byPo as $b) {
        if ($b['recv'] <= 0 && $b['rej'] <= 0) continue;
        if ($b['rej'] > 0) { $accEval++; $accSpent += $b['value']; continue; }
        if ($b['status'] === 'SELESAI_FTB') {
            $accEval++; $accSpent += $b['value'];
            if (!$b['short']) $accOk++;
        }
    }
    $accTarget = (float)report_setting($pdo, 'target_accuracy_pct');
    $accPct = $accEval > 0 ? $accOk / $accEval * 100 : null;
    $rows[] = [
        'no' => '4', 'label' => 'Order Fulfillment Accuracy (Order Accuracy Rate)', 'bold' => true, 'kind' => 'kpi',
        'spent' => $accSpent, 'target' => $accTarget, 'target_fmt' => 'pct', 'ach' => null,
        'pct' => $accPct, 'goal' => $accTarget,
        'note' => 'Mengukur persentase pesanan yang diterima dengan benar (tepat jenis, spesifikasi, dan jumlah) dibandingkan dengan total order yang dirilis. '
            . "{$accOk} dari {$accEval} PO diterima tanpa reject & sesuai jumlah.",
    ];

    // 5. SLA PR -> PO
    $slaDays = (int)report_setting($pdo, 'sla_pr_po_days');
    $basis = (string)report_setting($pdo, 'sla_start_basis');
    $slaEval = 0; $slaOk = 0; $slaSum = 0; $slaSpent = 0.0;
    foreach ($deliv as $d) {
        $start = $basis === 'REQUEST_DATE' ? $d['request_date'] : ($d['dir_keu_date'] ?: $d['request_date']);
        if (!$start) continue;
        $days = max(0, (int)round((strtotime($d['po_date']) - strtotime($start)) / 86400));
        $slaEval++; $slaSum += $days; $slaSpent += (float)$d['subtotal_po'];
        if ($days <= $slaDays) $slaOk++;
    }
    $slaTarget = (float)report_setting($pdo, 'target_sla_pct');
    $slaPct = $slaEval > 0 ? $slaOk / $slaEval * 100 : null;
    $rows[] = [
        'no' => '5', 'label' => 'SLA Lead Time Pengadaan (PR to PO)', 'bold' => true, 'kind' => 'kpi',
        'spent' => $slaSpent, 'target' => $slaTarget, 'target_fmt' => 'pct', 'ach' => null,
        'pct' => $slaPct, 'goal' => $slaTarget,
        'note' => "{$slaOk} dari {$slaEval} PO terbit maksimal {$slaDays} hari kalender sejak "
            . ($basis === 'REQUEST_DATE' ? 'tanggal PPBJ' : 'persetujuan final PPBJ')
            . ($slaEval > 0 ? '; rata-rata ' . number_format($slaSum / $slaEval, 1, ',', '.') . ' hari.' : '.'),
    ];

    return [
        'rows' => $rows,
        'uncategorized' => $uncat,
        'totals' => ['spent' => $totSpent, 'saving' => $totSaving, 'budget' => $totBudget],
        'line_count' => count($lines),
    ];
}

/* ------------------------------------------------------------------
 *  Top 10 transaksi terbesar (laporan #2)
 * ------------------------------------------------------------------ */
function report_top_transactions(PDO $pdo, array $period, int $limit = 10): array
{
    $orders = report_orders(report_lines($pdo, $period['from'], $period['to']));
    $totalSpent = array_sum(array_column($orders, 'actual'));
    $totalSaving = array_sum(array_column($orders, 'saving'));
    usort($orders, fn($a, $b) => $b['actual'] <=> $a['actual']);
    $top = array_slice($orders, 0, $limit);
    foreach ($top as &$o) {
        $names = $o['names'];
        $o['detail'] = implode('; ', array_slice($names, 0, 3)) . (count($names) > 3 ? '; +' . (count($names) - 3) . ' item lainnya' : '');
        $o['pct_spent'] = $totalSpent > 0 ? $o['actual'] / $totalSpent * 100 : null;
        $o['pct_saving'] = $totalSaving > 0 ? $o['saving'] / $totalSaving * 100 : null;
    }
    unset($o);
    return [
        'rows' => $top,
        'total_spent' => $totalSpent,
        'total_saving' => $totalSaving,
        'order_count' => count($orders),
        'top_spent' => array_sum(array_column($top, 'actual')),
    ];
}

/* ------------------------------------------------------------------
 *  Payment term (laporan #3)
 * ------------------------------------------------------------------ */
function report_classify_term(string $term): string
{
    $t = strtolower(trim($term));
    if ($t === '') {
        return 'Lainnya (belum diisi)';
    }
    if (preg_match('/\bcbd\b|cash before|bayar di muka|advance/', $t)) return 'Cash Before Delivery (CBD)';
    if (preg_match('/\bcod\b|cash on delivery/', $t)) return 'Cash On Delivery (COD)';
    if (preg_match('/l\/c|letter of credit/', $t)) return 'Letter of Credit (L/C)';
    if (preg_match('/skbdn/', $t)) return 'SKBDN';
    if (preg_match('/bank guarantee/', $t)) return 'Bank Guarantee';
    if (preg_match('/\bdp\b|down payment|progress|retention|retensi|termin/', $t)) return 'DP / Progress Payment';
    if (preg_match('/(\d+)\s*(hari|days?|hr)\b/', $t, $m) || preg_match('/(?:top|credit|kredit|net|tempo)\D{0,6}(\d+)/', $t, $m)) {
        return 'Credit, ' . (int)$m[1] . ' days';
    }
    return 'Lainnya (etc)';
}

function report_payment_terms(PDO $pdo, array $period): array
{
    $orders = report_orders(report_lines($pdo, $period['from'], $period['to']));
    $groups = [
        'Cash Before Delivery (CBD)' => ['qty' => 0, 'value' => 0.0],
        'Cash On Delivery (COD)' => ['qty' => 0, 'value' => 0.0],
        'Credit, 30 days' => ['qty' => 0, 'value' => 0.0],
    ];
    $extra = [];
    foreach ($orders as $o) {
        $g = report_classify_term($o['termin']);
        if (isset($groups[$g])) {
            $groups[$g]['qty']++;
            $groups[$g]['value'] += $o['actual'];
        } else {
            $extra[$g]['qty'] = ($extra[$g]['qty'] ?? 0) + 1;
            $extra[$g]['value'] = ($extra[$g]['value'] ?? 0.0) + $o['actual'];
        }
    }
    // Baris tambahan: urut berdasar jumlah order, "Lainnya" paling akhir
    uksort($extra, function ($a, $b) use ($extra) {
        $la = str_starts_with($a, 'Lainnya') ? 1 : 0;
        $lb = str_starts_with($b, 'Lainnya') ? 1 : 0;
        if ($la !== $lb) return $la <=> $lb;
        return $extra[$b]['qty'] <=> $extra[$a]['qty'];
    });
    $all = $groups + $extra;
    $totQty = array_sum(array_column($all, 'qty'));
    $totVal = array_sum(array_column($all, 'value'));
    $rows = [];
    $i = 1;
    foreach ($all as $label => $d) {
        $rows[] = [
            'no' => $i++, 'label' => $label, 'qty' => $d['qty'],
            'qty_pct' => $totQty > 0 ? $d['qty'] / $totQty * 100 : null,
            'value' => $d['value'],
            'value_pct' => $totVal > 0 ? $d['value'] / $totVal * 100 : null,
        ];
    }
    return ['rows' => $rows, 'total_qty' => $totQty, 'total_value' => $totVal];
}

/* ------------------------------------------------------------------
 *  Vendor performance & compliance (laporan #5)
 * ------------------------------------------------------------------ */
function report_incidents(PDO $pdo, string $from, string $to): array
{
    $st = $pdo->prepare("SELECT * FROM vendor_incidents WHERE incident_date BETWEEN ? AND ? ORDER BY incident_date DESC, id DESC");
    $st->execute([$from, $to]);
    return $st->fetchAll();
}

function report_vendor_performance(PDO $pdo, array $period): array
{
    $from = $period['from'];
    $to = $period['to'];
    $lines = report_lines($pdo, $from, $to);
    $orders = report_orders($lines);
    $deliv = report_po_delivery($pdo, $from, $to);
    $olines = report_order_lines($pdo, $from, $to);
    $incidents = report_incidents($pdo, $from, $to);

    $topMin = (float)report_setting($pdo, 'top_vendor_min_otd');
    $watchBelow = (float)report_setting($pdo, 'watch_otd_below');
    $threshold = (float)report_setting($pdo, 'compliance_threshold');
    $minQuotes = (int)report_setting($pdo, 'compliance_min_quotes');

    $v = [];
    $blank = fn() => [
        'orders' => 0, 'spent' => 0.0, 'eval' => 0, 'ontime' => 0, 'late' => 0, 'max_late' => 0,
        'recv' => 0.0, 'rej' => 0.0, 'inc' => [], 'inc_k3' => 0,
    ];
    foreach ($orders as $o) {
        $n = $o['vendor_name'];
        $v[$n] ??= $blank();
        $v[$n]['orders']++;
        $v[$n]['spent'] += $o['actual'];
    }
    foreach ($deliv as $d) {
        $n = $d['vendor_name'];
        $v[$n] ??= $blank();
        if ($d['delivery_status'] === 'ONTIME') { $v[$n]['eval']++; $v[$n]['ontime']++; }
        elseif (in_array($d['delivery_status'], ['LATE', 'OVERDUE'], true)) {
            $v[$n]['eval']++; $v[$n]['late']++;
            $v[$n]['max_late'] = max($v[$n]['max_late'], (int)$d['days_late']);
        }
    }
    foreach ($olines as $ol) {
        $n = $ol['vendor_name'];
        $v[$n] ??= $blank();
        $v[$n]['recv'] += $ol['received'];
        $v[$n]['rej'] += $ol['rejected'];
    }
    foreach ($incidents as $inc) {
        $n = $inc['vendor_name'];
        $v[$n] ??= $blank();
        $v[$n]['inc'][] = $inc;
        if (in_array($inc['jenis'], ['INSIDEN_K3', 'PELANGGARAN_KEPATUHAN'], true)) {
            $v[$n]['inc_k3']++;
        }
    }

    $rows = [];
    foreach ($v as $name => $d) {
        $otd = $d['eval'] > 0 ? $d['ontime'] / $d['eval'] * 100 : null;
        $rejPct = $d['recv'] > 0 ? $d['rej'] / $d['recv'] * 100 : null;
        $reasons = [];
        if ($otd !== null && $otd < $watchBelow) {
            $reasons[] = "keterlambatan pengiriman ({$d['late']} dari {$d['eval']} PO, OTD " . fmt_pct($otd, 0) . ')';
        }
        foreach ($d['inc'] as $inc) {
            if ($inc['jenis'] === 'SURAT_PERINGATAN') {
                $reasons[] = 'surat peringatan' . ($inc['po_no'] ? " ({$inc['po_no']})" : '');
            } elseif ($inc['jenis'] === 'PENALTI_KETERLAMBATAN') {
                $reasons[] = 'penalti keterlambatan' . ($inc['po_no'] ? " ({$inc['po_no']})" : '');
            } elseif ($inc['jenis'] === 'INSIDEN_K3') {
                $reasons[] = 'insiden K3';
            } else {
                $reasons[] = 'pelanggaran kepatuhan';
            }
        }
        $status = 'NORMAL';
        if ($reasons) {
            $status = 'WATCH';
        } elseif ($otd !== null && $otd >= $topMin && $d['rej'] <= 0 && $d['eval'] >= 1) {
            $status = 'TOP';
        }
        $rows[] = [
            'vendor' => $name, 'orders' => $d['orders'], 'spent' => $d['spent'],
            'eval' => $d['eval'], 'ontime' => $d['ontime'], 'late' => $d['late'], 'max_late' => $d['max_late'],
            'otd' => $otd, 'recv' => $d['recv'], 'rej' => $d['rej'], 'rej_pct' => $rejPct,
            'incidents' => count($d['inc']), 'status' => $status, 'reasons' => array_values(array_unique($reasons)),
        ];
    }
    usort($rows, fn($a, $b) => $b['spent'] <=> $a['spent']);

    // Governance: transaksi di atas ambang harus punya >= N penawaran
    $gov = ['eligible' => 0, 'compliant' => 0, 'rows' => []];
    foreach ($orders as $o) {
        if ($o['actual'] <= $threshold) continue;
        $gov['eligible']++;
        $ok = $o['quotes'] >= $minQuotes;
        if ($ok) $gov['compliant']++;
        $gov['rows'][] = [
            'po_no' => $o['po_no'] ?: ('Non-PO (Bid #' . $o['bid_id'] . ')'),
            'vendor' => $o['vendor_name'], 'value' => $o['actual'], 'quotes' => $o['quotes'], 'ok' => $ok,
        ];
    }
    usort($gov['rows'], fn($a, $b) => $b['value'] <=> $a['value']);
    $gov['pct'] = $gov['eligible'] > 0 ? $gov['compliant'] / $gov['eligible'] * 100 : null;

    return [
        'vendors' => $rows, 'incidents' => $incidents, 'governance' => $gov,
        'params' => ['top_min' => $topMin, 'watch_below' => $watchBelow, 'threshold' => $threshold, 'min_quotes' => $minQuotes],
    ];
}

/** Kalimat highlight seperti pada template (3 baris). */
function report_vendor_highlights(array $perf): array
{
    $top = [];
    $watch = [];
    foreach ($perf['vendors'] as $r) {
        if ($r['status'] === 'TOP') {
            $top[] = $r['vendor'];
        } elseif ($r['status'] === 'WATCH') {
            $watch[] = $r['vendor'] . ' – ' . implode('; ', $r['reasons']);
        }
    }
    $p = $perf['params'];
    $g = $perf['governance'];

    $l1 = 'Top Performing Vendors: ' . ($top
        ? implode(', ', $top) . ' (Skor SLA ≥ ' . fmt_pct($p['top_min'], 0) . ', nol reject, nol insiden K3/kepatuhan).'
        : 'belum ada vendor yang memenuhi kriteria (Skor SLA ≥ ' . fmt_pct($p['top_min'], 0) . ', nol reject, nol insiden K3/kepatuhan) pada periode ini.');
    $l2 = 'Vendor Under Watch (Dalam Pengawasan): ' . ($watch
        ? implode(' | ', $watch) . '.'
        : 'tidak ada vendor dalam pengawasan pada periode ini.');
    if ($g['eligible'] > 0) {
        $l3 = 'Kepatuhan & Tata Kelola (Governance): ' . fmt_pct($g['pct'], 0) . " ({$g['compliant']} dari {$g['eligible']}) transaksi di atas "
            . rupiah($p['threshold']) . " telah melalui proses komparasi minimal {$p['min_quotes']} penawaran.";
    } else {
        $l3 = 'Kepatuhan & Tata Kelola (Governance): tidak ada transaksi di atas ' . rupiah($p['threshold']) . ' pada periode ini.';
    }
    return [$l1, $l2, $l3];
}

/* ------------------------------------------------------------------
 *  Komponen UI bersama
 * ------------------------------------------------------------------ */
function report_nav_tabs(string $active): void
{
    $tabs = [
        'cost_saving' => 'Cost Saving & KPI',
        'top_transactions' => 'Top 10 Transaksi',
        'payment_terms' => 'Payment Term',
        'order_tracking' => 'Order Tracking',
        'vendor_compliance' => 'Vendor & Compliance',
    ];
    $qs = '';
    foreach (['tahun', 'bulan'] as $k) {
        if (isset($_GET[$k])) {
            $qs .= '&' . $k . '=' . urlencode((string)$_GET[$k]);
        }
    }
    echo '<div class="rpt-tabs no-print">';
    foreach ($tabs as $id => $label) {
        echo '<a href="index.php?page=' . h($id) . $qs . '" class="rpt-tab ' . ($active === $id ? 'active' : '') . '">' . h($label) . '</a>';
    }
    echo '</div>';
}

function report_filter_bar(string $page, array $period, array $extra = []): void
{
    $names = report_month_names();
    $cur = (int)date('Y');
    ?>
    <form method="get" class="rpt-filter no-print">
      <input type="hidden" name="page" value="<?= h($page) ?>">
      <span class="rpt-filter-label">Periode:</span>
      <select name="bulan" class="form-control" style="max-width:170px;">
        <option value="" <?= $period['month'] === 0 ? 'selected' : '' ?>>Semua Bulan (Setahun)</option>
        <?php foreach ($names as $n => $nm): ?>
          <option value="<?= $n ?>" <?= $period['month'] === $n ? 'selected' : '' ?>><?= h($nm) ?></option>
        <?php endforeach; ?>
      </select>
      <select name="tahun" class="form-control" style="max-width:110px;">
        <?php for ($y = $cur + 1; $y >= $cur - 5; $y--): ?>
          <option value="<?= $y ?>" <?= $period['year'] === $y ? 'selected' : '' ?>><?= $y ?></option>
        <?php endfor; ?>
      </select>
      <?php foreach ($extra as $name => $html): echo $html; endforeach; ?>
      <button type="submit" class="btn btn-primary btn-sm">Terapkan</button>
    </form>
    <?php
}

function report_head_actions(string $reportKey, array $user, bool $withSettings = true): void
{
    $qs = http_build_query(array_intersect_key($_GET, array_flip(['tahun', 'bulan', 'q', 'status'])));
    ?>
    <div class="no-print" style="display:flex;gap:8px;flex-wrap:wrap;">
      <a href="index.php?page=export_report&report=<?= h($reportKey) ?><?= $qs ? '&' . h($qs) : '' ?>" class="btn btn-outline btn-sm">Export (.CSV)</a>
      <button type="button" class="btn btn-primary btn-sm" onclick="window.print()">Cetak</button>
      <?php if ($withSettings && report_can_edit($user)): ?>
        <a href="index.php?page=report_settings" class="btn btn-outline btn-sm">Atur Target &amp; Parameter</a>
      <?php endif; ?>
    </div>
    <?php
}
