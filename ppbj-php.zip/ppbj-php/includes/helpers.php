<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

const PPBJ_REQUEST_TYPES = [
    '1. Bahan baku' => 'Raw material',
    '2. Alat Produksi' => 'Production tools/machine',
    '3. Kendaraan' => 'Vehicle',
    '4. Suku cadang' => 'Spare parts',
    '5. Bahan bakar/Pelumas' => 'Fuel/Lubricant',
    '6. Lain-lain' => 'Others',
];

const ROLE_LABELS = [
    'PEMOHON' => 'User / Pemohon PPBJ',
    'MANAGER' => 'Atasan / Manager',
    'DIREKTUR_OPS' => 'Direktur Operasional',
    'DIREKTUR_KEUANGAN' => 'Direktur Keuangan',
    'PROCUREMENT' => 'Procurement & Gudang (PO/FTB)',
    'ADMIN' => 'Super Admin',
];

function h(?string $val): string
{
    return htmlspecialchars((string)($val ?? ''), ENT_QUOTES, 'UTF-8');
}

function logo_src(): string
{
    static $uri = null;
    if ($uri !== null) {
        return $uri;
    }
    $path = __DIR__ . '/../assets/logo-pbs.jpg';
    if (is_file($path)) {
        $data = file_get_contents($path);
        if ($data !== false) {
            $uri = 'data:image/jpeg;base64,' . base64_encode($data);
            return $uri;
        }
    }
    $uri = 'assets/logo-pbs.jpg';
    return $uri;
}

function rupiah(float|int|string|null $amount): string
{
    return 'Rp ' . number_format((float)($amount ?? 0), 0, ',', '.');
}

function tgl_indo(?string $dateStr): string
{
    if (!$dateStr) {
        return '-';
    }
    $ts = strtotime($dateStr);
    if ($ts === false) {
        return h($dateStr);
    }
    $bulan = [
        1 => 'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun',
        'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'
    ];
    return date('d', $ts) . ' ' . ($bulan[(int)date('n', $ts)] ?? date('m', $ts)) . ' ' . date('Y', $ts);
}

function roman_month(int $month): string
{
    $romans = [1 => 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII'];
    return $romans[$month] ?? 'XI';
}

function current_user(): ?array
{
    return $_SESSION['user'] ?? null;
}

function require_login(): array
{
    $user = current_user();
    if (!$user) {
        header('Location: login.php');
        exit;
    }
    return $user;
}

function refresh_user_from_db(PDO $pdo, array $user): array
{
    $st = $pdo->prepare(
        "SELECT u.*, d.kode_divisi AS division_code, d.nama_divisi AS division_name
         FROM users u
         LEFT JOIN divisions d ON u.division_id = d.id
         WHERE u.id = ? AND u.aktif = 1 LIMIT 1"
    );
    $st->execute([(int)$user['id']]);
    $fresh = $st->fetch();
    if (!$fresh) {
        unset($_SESSION['user']);
        set_flash('Akun Anda dinonaktifkan atau tidak ditemukan.', 'error');
        header('Location: login.php');
        exit;
    }
    unset($fresh['password_hash']);
    $_SESSION['user'] = $fresh;
    return $fresh;
}

function role_label(string $role): string
{
    return ROLE_LABELS[$role] ?? $role;
}

function set_flash(string $msg, string $type = 'success'): void
{
    $_SESSION['flash'] = ['msg' => $msg, 'type' => $type];
}

function redirect_to(string $url): never
{
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    if (!headers_sent()) {
        header('Location: ' . $url);
    } else {
        echo '<script>window.location.href=' . json_encode($url) . ';</script>';
    }
    exit;
}

function get_flash(): ?array
{
    if (!isset($_SESSION['flash'])) {
        return null;
    }
    $f = $_SESSION['flash'];
    unset($_SESSION['flash']);
    return $f;
}

function status_meta(string $status): array
{
    $map = [
        'DRAFT' => ['Draft', 'badge-slate'],
        'MENUNGGU_MANAGER' => ['Menunggu Approval Manager', 'badge-amber'],
        'MENUNGGU_DIR_OPS' => ['Menunggu Approval Dir. Operasional', 'badge-sky'],
        'MENUNGGU_DIR_KEU' => ['Menunggu Approval Dir. Keuangan', 'badge-purple'],
        'SIAP_BID' => ['Disetujui Final (Siap Bid Summary)', 'badge-teal'],
        'PO_TERBIT' => ['PO Terbit (Menunggu FTB)', 'badge-blue'],
        'NON_PO' => ['Non PO (Langsung ke FTB)', 'badge-purple'],
        'SELESAI_FTB' => ['Selesai (FTB Diterima)', 'badge-green'],
        'REVISI' => ['Perlu Revisi', 'badge-orange'],
        'DITOLAK' => ['Ditolak', 'badge-red'],
    ];
    return $map[$status] ?? [$status, 'badge-slate'];
}

function po_status_meta(string $status): array
{
    $map = [
        'DRAFT' => ['Draft PO', 'badge-slate'],
        'TERBIT' => ['PO Terbit', 'badge-blue'],
        'DALAM_PENGIRIMAN' => ['Dalam Pengiriman', 'badge-amber'],
        'SELESAI_FTB' => ['Selesai (FTB)', 'badge-green'],
    ];
    return $map[$status] ?? [$status, 'badge-slate'];
}

function next_bid_no(PDO $pdo): string
{
    $count = (int)$pdo->query("SELECT COUNT(*) FROM bid_summaries")->fetchColumn();
    $n = $count + 1;
    $rom = roman_month((int)date('n'));
    $yr = date('Y');
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM bid_summaries WHERE bid_no = ?");
    while (true) {
        $seq = str_pad((string)$n, 3, '0', STR_PAD_LEFT);
        $candidate = "{$seq}/BID/{$rom}-{$yr}/PBS";
        $stmt->execute([$candidate]);
        if ((int)$stmt->fetchColumn() === 0) {
            return $candidate;
        }
        $n++;
    }
}

function normalize_div_code(string $divCode): string
{
    $code = strtoupper(trim($divCode));
    if (str_starts_with($code, 'PBS-')) {
        $code = substr($code, 4);
    }
    $code = preg_replace('/[^A-Z0-9_-]/', '', $code) ?? '';
    return $code !== '' ? $code : 'OIT';
}

function next_ppbj_no(PDO $pdo, string $divCode = 'OIT'): string
{
    $code = normalize_div_code($divCode);
    $stmt = $pdo->prepare("SELECT request_no FROM ppbj_requests WHERE division_code = ? OR request_no LIKE ?");
    $stmt->execute([$code, '%/PBS-' . $code]);
    $maxSeq = 0;
    foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $reqNo) {
        if (preg_match('/^(\d+)\//', (string)$reqNo, $m)) {
            $num = (int)$m[1];
            if ($num > $maxSeq) {
                $maxSeq = $num;
            }
        }
    }

    $n = $maxSeq + 1;
    $rom = roman_month((int)date('n'));
    $yr = date('Y');
    $chk = $pdo->prepare("SELECT COUNT(*) FROM ppbj_requests WHERE request_no = ?");
    while (true) {
        $seq = str_pad((string)$n, 3, '0', STR_PAD_LEFT);
        $candidate = "{$seq}/PPBJ/{$rom}-{$yr}/PBS-{$code}";
        $chk->execute([$candidate]);
        if ((int)$chk->fetchColumn() === 0) {
            return $candidate;
        }
        $n++;
    }
}

function next_po_no(PDO $pdo): string
{
    $count = (int)$pdo->query("SELECT COUNT(*) FROM purchase_orders")->fetchColumn();
    $n = $count + 1;
    $rom = roman_month((int)date('n'));
    $yr = date('Y');
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM purchase_orders WHERE po_no = ?");
    while (true) {
        $seq = str_pad((string)$n, 3, '0', STR_PAD_LEFT);
        $candidate = "{$seq}/PO/{$rom}-{$yr}/PBS";
        $stmt->execute([$candidate]);
        if ((int)$stmt->fetchColumn() === 0) {
            return $candidate;
        }
        $n++;
    }
}

function next_ftb_no(PDO $pdo): string
{
    $count = (int)$pdo->query("SELECT COUNT(*) FROM ftb_receipts")->fetchColumn();
    $n = $count + 1;
    $rom = roman_month((int)date('n'));
    $yr = date('Y');
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM ftb_receipts WHERE ftb_no = ?");
    while (true) {
        $seq = str_pad((string)$n, 3, '0', STR_PAD_LEFT);
        $candidate = "{$seq}/FTB/{$rom}-{$yr}/PBS";
        $stmt->execute([$candidate]);
        if ((int)$stmt->fetchColumn() === 0) {
            return $candidate;
        }
        $n++;
    }
}

function clean_vendor_cell(string $val): string
{
    $s = str_replace(["\xC2\xA0", "\t", "\r"], [' ', ' ', ''], $val);
    $s = preg_replace('/\s*\n\s*/', ' | ', trim($s));
    $s = preg_replace('/ {2,}/', ' ', (string)$s);
    return trim((string)$s, " |");
}

function infer_vendor_jenis(string $item): string
{
    $low = strtolower($item);
    foreach (['contractor', 'supplier', 'pengerjaan', 'aplikator'] as $kw) {
        if (strpos($low, $kw) !== false) return 'Barang & Jasa';
    }
    foreach (['jasa', 'pelatihan', 'sertifikasi', 'kalibrasi', 'pengujian', 'uji riksa', 'logistik', 'rental', 'slf', 'software', 'studio foto', 'percetakan'] as $kw) {
        if (strpos($low, $kw) !== false) return 'Jasa';
    }
    return 'Barang';
}

function infer_vendor_kota(string $addr): string
{
    $cities = [
        'Jakarta Pusat', 'Jakarta Barat', 'Jakarta Selatan', 'Jakarta Timur', 'Jakarta',
        'Tangerang Selatan', 'Tangerang', 'Bekasi', 'Depok', 'Bogor', 'Klaten', 'Padang',
        'Medan', 'Deli Serdang', 'Banda Aceh', 'Aceh Barat', 'Meulaboh', 'Nagan Raya',
        'Aceh Jaya', 'Aceh Besar', 'Lampung'
    ];
    foreach ($cities as $c) {
        if (stripos($addr, $c) !== false) return $c;
    }
    return 'Indonesia';
}

function infer_vendor_pic(string $telp): string
{
    if (preg_match('/^([A-Za-z.\s,]{2,40})\s*\(/', trim($telp), $m)) {
        $name = trim($m[1]);
        $low = strtolower($name);
        if (strpos($low, 'telp') !== 0 && strpos($low, 'hp') !== 0) {
            return $name;
        }
    }
    return '-';
}

function read_zip_entries_pure(string $path, array $wanted): array
{
    $out = [];
    if (class_exists('ZipArchive')) {
        $zip = new ZipArchive();
        if ($zip->open($path) === true) {
            foreach ($wanted as $name) {
                $content = $zip->getFromName($name);
                if ($content !== false) {
                    $out[$name] = $content;
                }
            }
            $zip->close();
            return $out;
        }
    }

    $data = @file_get_contents($path);
    if ($data === false || strlen($data) < 22) {
        return $out;
    }
    $eocdPos = strrpos($data, "\x50\x4b\x05\x06");
    if ($eocdPos === false) {
        return $out;
    }
    $eocd = unpack('vdisk/vcdDisk/vdiskEntries/vtotalEntries/VcdSize/VcdOffset/vcommentLen', substr($data, $eocdPos + 4, 18));
    if (!$eocd) {
        return $out;
    }
    $pos = $eocd['cdOffset'];
    $wantedSet = array_flip($wanted);

    for ($i = 0; $i < $eocd['totalEntries']; $i++) {
        if (substr($data, $pos, 4) !== "\x50\x4b\x01\x02") break;
        $hdr = unpack('vverMade/vverNeed/vflag/vmethod/vmtime/vmdate/Vcrc/VcompSize/VuncompSize/vnameLen/vextraLen/vcommentLen/vdiskStart/vintAttr/VextAttr/VlocalOffset', substr($data, $pos + 4, 42));
        $name = substr($data, $pos + 46, $hdr['nameLen']);
        $pos += 46 + $hdr['nameLen'] + $hdr['extraLen'] + $hdr['commentLen'];

        if (!isset($wantedSet[$name])) continue;
        $lOff = $hdr['localOffset'];
        if (substr($data, $lOff, 4) !== "\x50\x4b\x03\x04") continue;
        $lHdr = unpack('vver/vflag/vmethod/vmtime/vmdate/Vcrc/VcompSize/VuncompSize/vnameLen/vextraLen', substr($data, $lOff + 4, 26));
        $dataStart = $lOff + 30 + $lHdr['nameLen'] + $lHdr['extraLen'];
        $compData = substr($data, $dataStart, $hdr['compSize']);
        if ($hdr['method'] === 0) {
            $out[$name] = $compData;
        } elseif ($hdr['method'] === 8 && function_exists('gzinflate')) {
            $raw = @gzinflate($compData);
            if ($raw !== false) {
                $out[$name] = $raw;
            }
        }
    }
    return $out;
}

function xlsx_col_to_index(string $ref): int
{
    if (!preg_match('/^([A-Z]+)/i', $ref, $m)) return 0;
    $letters = strtoupper($m[1]);
    $idx = 0;
    for ($i = 0; $i < strlen($letters); $i++) {
        $idx = $idx * 26 + (ord($letters[$i]) - 64);
    }
    return $idx - 1;
}

function parse_xlsx_rows(string $path): array
{
    $entries = read_zip_entries_pure($path, ['xl/sharedStrings.xml', 'xl/worksheets/sheet1.xml']);
    if (empty($entries['xl/worksheets/sheet1.xml'])) {
        return [];
    }
    $shared = [];
    if (!empty($entries['xl/sharedStrings.xml'])) {
        if (preg_match_all('/<si\b[^>]*>(.*?)<\/si>/s', $entries['xl/sharedStrings.xml'], $siMatches)) {
            foreach ($siMatches[1] as $siXml) {
                $text = '';
                if (preg_match_all('/<t(?:\s+[^>]*)?>(.*?)<\/t>/s', $siXml, $tMatches)) {
                    foreach ($tMatches[1] as $t) {
                        $text .= html_entity_decode($t, ENT_QUOTES | ENT_XML1, 'UTF-8');
                    }
                }
                $shared[] = $text;
            }
        }
    }

    $rows = [];
    $sheetXml = $entries['xl/worksheets/sheet1.xml'];
    if (preg_match_all('/<row\b[^>]*>(.*?)<\/row>/s', $sheetXml, $rowMatches)) {
        foreach ($rowMatches[1] as $rowXml) {
            $rowArr = [];
            if (preg_match_all('/<c\b([^>]*)(?:\/>|>(.*?)<\/c>)/s', $rowXml, $cellMatches, PREG_SET_ORDER)) {
                foreach ($cellMatches as $cm) {
                    $attrs = $cm[1];
                    $inner = $cm[2] ?? '';
                    $ref = '';
                    $type = '';
                    if (preg_match('/\br="([^"]+)"/', $attrs, $rm)) $ref = $rm[1];
                    if (preg_match('/\bt="([^"]+)"/', $attrs, $tm)) $type = $tm[1];
                    $colIdx = xlsx_col_to_index($ref);

                    $val = '';
                    if ($type === 'inlineStr') {
                        if (preg_match_all('/<t(?:\s+[^>]*)?>(.*?)<\/t>/s', $inner, $it)) {
                            foreach ($it[1] as $p) {
                                $val .= html_entity_decode($p, ENT_QUOTES | ENT_XML1, 'UTF-8');
                            }
                        }
                    } elseif (preg_match('/<v>(.*?)<\/v>/s', $inner, $vm)) {
                        $rawV = html_entity_decode($vm[1], ENT_QUOTES | ENT_XML1, 'UTF-8');
                        if ($type === 's') {
                            $val = $shared[(int)$rawV] ?? '';
                        } else {
                            $val = $rawV;
                        }
                    }
                    $rowArr[$colIdx] = $val;
                }
            }
            if (!empty($rowArr)) {
                $maxC = max(array_keys($rowArr));
                $dense = [];
                for ($c = 0; $c <= $maxC; $c++) {
                    $dense[] = $rowArr[$c] ?? '';
                }
                $rows[] = $dense;
            }
        }
    }
    return $rows;
}

function parse_csv_rows(string $path): array
{
    $raw = @file_get_contents($path);
    if ($raw === false) return [];
    if (substr($raw, 0, 3) === "\xEF\xBB\xBF") {
        $raw = substr($raw, 3);
    }
    $firstLine = strtok($raw, "\r\n") ?: '';
    $delim = ',';
    $counts = [',' => substr_count($firstLine, ','), ';' => substr_count($firstLine, ';'), "\t" => substr_count($firstLine, "\t")];
    arsort($counts);
    $topDelim = array_key_first($counts);
    if ($counts[$topDelim] > 0) $delim = $topDelim;

    $rows = [];
    $fp = fopen('php://temp', 'r+');
    fwrite($fp, $raw);
    rewind($fp);
    while (($line = fgetcsv($fp, 0, $delim)) !== false) {
        $rows[] = $line;
    }
    fclose($fp);
    return $rows;
}

function extract_vendors_from_rows(array $rows): array
{
    $headerIdx = -1;
    $colMap = [];
    foreach ($rows as $rIdx => $row) {
        $norm = array_map(fn($x) => strtoupper(trim(preg_replace('/\s+/', ' ', (string)$x))), $row);
        foreach ($norm as $cIdx => $cell) {
            if (strpos($cell, 'NAMA PENYEDIA') !== false || $cell === 'NAMA VENDOR' || $cell === 'NAMA_VENDOR' || $cell === 'NAMA PERUSAHAAN') {
                $headerIdx = $rIdx;
                break;
            }
        }
        if ($headerIdx >= 0) {
            foreach ($norm as $cIdx => $h) {
                if (strpos($h, 'NAMA PENYEDIA') !== false || $h === 'NAMA VENDOR' || $h === 'NAMA_VENDOR' || $h === 'NAMA PERUSAHAAN') $colMap['nama'] = $cIdx;
                elseif (strpos($h, 'NO. REKENING') !== false || strpos($h, 'NO REKENING') !== false || $h === 'NO_REKENING') $colMap['no_rekening'] = $cIdx;
                elseif (strpos($h, 'AN. REKENING') !== false || strpos($h, 'A.N') !== false || $h === 'AN_REKENING') $colMap['an_rekening'] = $cIdx;
                elseif (strpos($h, 'NAMA BANK') !== false || $h === 'BANK' || $h === 'NAMA_BANK') $colMap['nama_bank'] = $cIdx;
                elseif (strpos($h, 'ALAMAT') !== false) $colMap['alamat'] = $cIdx;
                elseif (strpos($h, 'TELP') !== false || strpos($h, 'TELEPON') !== false || strpos($h, 'HP') !== false) $colMap['telepon'] = $cIdx;
                elseif (strpos($h, 'ITEM') !== false || strpos($h, 'KATEGORI') !== false) $colMap['item'] = $cIdx;
                elseif (strpos($h, 'JENIS') !== false) $colMap['jenis'] = $cIdx;
                elseif ($h === 'PIC' || strpos($h, 'NAMA PIC') !== false) $colMap['pic'] = $cIdx;
                elseif ($h === 'EMAIL') $colMap['email'] = $cIdx;
                elseif ($h === 'NPWP') $colMap['npwp'] = $cIdx;
                elseif ($h === 'KOTA') $colMap['kota'] = $cIdx;
            }
            break;
        }
    }

    if ($headerIdx < 0) {
        $colMap = ['nama' => 1, 'no_rekening' => 2, 'an_rekening' => 3, 'nama_bank' => 4, 'alamat' => 5, 'telepon' => 6, 'item' => 8];
        $startRow = 0;
    } else {
        $startRow = $headerIdx + 1;
    }

    $vendors = [];
    for ($i = $startRow; $i < count($rows); $i++) {
        $r = $rows[$i];
        $nama = clean_vendor_cell((string)($r[$colMap['nama'] ?? 1] ?? ''));
        if ($nama === '' || stripos($nama, 'PENYEDIA EKSTERNAL') !== false || stripos($nama, 'NAMA VENDOR') !== false) {
            continue;
        }
        $noRek = clean_vendor_cell((string)($r[$colMap['no_rekening'] ?? 2] ?? '')) ?: '-';
        $anRek = clean_vendor_cell((string)($r[$colMap['an_rekening'] ?? 3] ?? '')) ?: '-';
        $bank = clean_vendor_cell((string)($r[$colMap['nama_bank'] ?? 4] ?? '')) ?: '-';
        $alamat = clean_vendor_cell((string)($r[$colMap['alamat'] ?? 5] ?? '')) ?: '-';
        $telp = clean_vendor_cell((string)($r[$colMap['telepon'] ?? 6] ?? '')) ?: '-';
        $item = clean_vendor_cell((string)($r[$colMap['item'] ?? 8] ?? '')) ?: 'Umum';

        $jenis = isset($colMap['jenis']) ? clean_vendor_cell((string)($r[$colMap['jenis']] ?? '')) : '';
        if (!in_array($jenis, ['Barang', 'Jasa', 'Barang & Jasa'], true)) {
            $jenis = infer_vendor_jenis($item);
        }
        $pic = isset($colMap['pic']) ? clean_vendor_cell((string)($r[$colMap['pic']] ?? '')) : '';
        if ($pic === '' || $pic === '-') $pic = infer_vendor_pic($telp);
        $email = isset($colMap['email']) ? (clean_vendor_cell((string)($r[$colMap['email']] ?? '')) ?: '-') : '-';
        $npwp = isset($colMap['npwp']) ? (clean_vendor_cell((string)($r[$colMap['npwp']] ?? '')) ?: '-') : '-';
        $kota = isset($colMap['kota']) ? clean_vendor_cell((string)($r[$colMap['kota']] ?? '')) : '';
        if ($kota === '' || $kota === '-') $kota = infer_vendor_kota($alamat);

        $vendors[] = [
            'nama_vendor' => $nama,
            'jenis_penyedia' => $jenis,
            'kategori' => mb_substr($item, 0, 240),
            'item_dijual' => $item,
            'no_rekening' => $noRek,
            'an_rekening' => $anRek,
            'nama_bank' => $bank,
            'alamat' => $alamat,
            'telepon' => $telp,
            'pic' => $pic,
            'email' => $email,
            'npwp' => $npwp,
            'kota' => $kota,
        ];
    }
    return $vendors;
}

function fetch_logbook_rows(PDO $pdo, array $user, array $filters = []): array
{
    $q = trim((string)($filters['q'] ?? ''));
    $divFilter = trim((string)($filters['divisi'] ?? ''));
    $statusFilter = trim((string)($filters['status'] ?? ''));
    $jalurFilter = trim((string)($filters['jalur'] ?? ''));
    $dateFrom = trim((string)($filters['date_from'] ?? ''));
    $dateTo = trim((string)($filters['date_to'] ?? ''));

    $sql = "SELECT
                pi.id AS ppbj_item_id,
                pi.item_no,
                pi.jumlah,
                pi.satuan,
                pi.no_anggaran,
                pi.nama_barang_jasa,
                pi.peruntukan,
                pi.harga_unit,
                pi.harga_anggaran,
                pi.jalur_pengadaan,
                p.id AS ppbj_id,
                p.request_no,
                p.request_date,
                p.received_date,
                p.division_code,
                p.division_subdivision,
                p.delivery_location,
                p.applied_by_name,
                p.applied_by_date,
                p.manager_name,
                p.manager_date,
                p.dir_ops_name,
                p.dir_ops_date,
                p.dir_keu_name,
                p.dir_keu_date,
                p.status AS ppbj_status,
                b.id AS bid_id,
                b.bid_no,
                b.bid_date,
                po.id AS po_id,
                po.po_no,
                po.po_date,
                po.vendor_name AS po_vendor_name,
                po.status AS po_status,
                poi.harga_satuan AS po_harga_satuan,
                poi.subtotal AS po_subtotal,
                (SELECT bv.vendor_name
                 FROM bid_items bi
                 JOIN bid_vendors bv ON bi.bid_vendor_id = bv.id
                 WHERE bi.ppbj_item_id = pi.id AND bi.is_selected = 1
                 ORDER BY bi.id DESC LIMIT 1) AS bid_winner_vendor,
                (SELECT bi.total_penawaran
                 FROM bid_items bi
                 WHERE bi.ppbj_item_id = pi.id AND bi.is_selected = 1
                 ORDER BY bi.id DESC LIMIT 1) AS bid_winner_total,
                f.id AS ftb_id,
                f.ftb_no,
                f.ftb_date,
                f.sj_do_no,
                fi.qty_accepted,
                fi.qty_rejected,
                fi.status_penerimaan
            FROM ppbj_items pi
            JOIN ppbj_requests p ON pi.ppbj_id = p.id
            LEFT JOIN bid_summaries b ON b.id = (
                SELECT MAX(bs.id) FROM bid_summaries bs WHERE bs.ppbj_id = p.id
            )
            LEFT JOIN po_items poi ON poi.id = (
                SELECT MAX(px.id) FROM po_items px WHERE px.ppbj_item_id = pi.id
            )
            LEFT JOIN purchase_orders po ON poi.po_id = po.id
            LEFT JOIN ftb_items fi ON fi.id = (
                SELECT MAX(fx.id) FROM ftb_items fx WHERE fx.ppbj_item_id = pi.id
            )
            LEFT JOIN ftb_receipts f ON fi.ftb_id = f.id
            WHERE 1=1";

    $params = [];
    if (($user['role'] ?? '') === 'PEMOHON') {
        $sql .= " AND p.user_id = ?";
        $params[] = (int)$user['id'];
    }
    if ($divFilter !== '') {
        $sql .= " AND p.division_code = ?";
        $params[] = $divFilter;
    }
    if ($statusFilter !== '') {
        $sql .= " AND p.status = ?";
        $params[] = $statusFilter;
    }
    if ($jalurFilter === 'PO' || $jalurFilter === 'NON_PO') {
        $sql .= " AND pi.jalur_pengadaan = ?";
        $params[] = $jalurFilter;
    }
    if ($dateFrom !== '') {
        $sql .= " AND p.request_date >= ?";
        $params[] = $dateFrom;
    }
    if ($dateTo !== '') {
        $sql .= " AND p.request_date <= ?";
        $params[] = $dateTo;
    }
    if ($q !== '') {
        $like = "%{$q}%";
        $sql .= " AND (
            p.request_no LIKE ? OR pi.nama_barang_jasa LIKE ? OR pi.peruntukan LIKE ?
            OR p.applied_by_name LIKE ? OR b.bid_no LIKE ? OR po.po_no LIKE ?
            OR po.vendor_name LIKE ? OR f.ftb_no LIKE ? OR p.division_subdivision LIKE ?
        )";
        $params = array_merge($params, array_fill(0, 9, $like));
    }

    $sql .= " ORDER BY p.request_date DESC, p.id DESC, pi.item_no ASC";
    $st = $pdo->prepare($sql);
    $st->execute($params);
    return $st->fetchAll();
}

function po_payment_terms_options(): array
{
    return [
        'Cash Before Delivery (CBD), transfer bank',
        'Cash On Delivery (COD)',
        'Credit, 30 days after receipt of the invoice and BAST / Delivery Note',
        'Credit, 45 days after receipt of the invoice and BAST / Delivery Note',
        '25% DP, progress payment, 5% retention 30 days after receipt of BAST / Delivery Note',
        '25% DP, progress payment, 10% retention 30 days after receipt of BAST / Delivery Note',
        '25% DP, progress payment, 15% retention 30 days after receipt of BAST / Delivery Note',
        '50% DP, remain balance after receipt BAST / Delivery Note',
        'Letter of Credit (L/C)',
        'Bank Guarantee',
        'SKBDN (Surat Kredit Berdokumen Dalam Negeri)',
    ];
}

function po_pph_options(): array
{
    return [
        [
            'code' => 'NONE',
            'label' => 'Tanpa PPh / Tidak Berlaku (0%)',
            'jenis_pajak' => '-',
            'rate' => 0.0,
            'rate_text' => '0%',
            'keterangan' => 'Pembelian barang non-jasa / tanpa potongan PPh',
        ],
        [
            'code' => 'PPH42_175',
            'label' => 'Kontraktor Konstruksi — PPh 4(2) Final Tax (1,75%) — Badan/Perorangan dengan sertifikasi',
            'jenis_pajak' => 'PPh 4(2) Final Tax',
            'rate' => 1.75,
            'rate_text' => '1,75%',
            'keterangan' => 'Kontraktor Konstruksi (Badan/Perorangan dengan sertifikasi)',
        ],
        [
            'code' => 'PPH42_400',
            'label' => 'Kontraktor Konstruksi, termasuk konstruksi terintegrasi — PPh 4(2) Final Tax (4%) — Badan/Perorangan tanpa sertifikasi',
            'jenis_pajak' => 'PPh 4(2) Final Tax',
            'rate' => 4.0,
            'rate_text' => '4%',
            'keterangan' => 'Kontraktor Konstruksi, termasuk konstruksi terintegrasi (tanpa sertifikasi)',
        ],
        [
            'code' => 'PPH42_265',
            'label' => 'Kontraktor Konstruksi, termasuk konstruksi terintegrasi — PPh 4(2) Final Tax (2,65%) — Badan Kualifikasi menengah/besar',
            'jenis_pajak' => 'PPh 4(2) Final Tax',
            'rate' => 2.65,
            'rate_text' => '2,65%',
            'keterangan' => 'Kontraktor Konstruksi, termasuk konstruksi terintegrasi (Badan Kualifikasi menengah/besar)',
        ],
        [
            'code' => 'PPH42_350',
            'label' => 'Jasa Konsultasi Konstruksi — PPh 4(2) Final Tax (3,50%) — Badan/Perorangan dengan sertifikasi',
            'jenis_pajak' => 'PPh 4(2) Final Tax',
            'rate' => 3.5,
            'rate_text' => '3,50%',
            'keterangan' => 'Jasa Konsultasi Konstruksi (Badan/Perorangan dengan sertifikasi)',
        ],
        [
            'code' => 'PPH42_500',
            'label' => 'Jasa Konsultasi Konstruksi — PPh 4(2) Final Tax (5%) — Badan/Perorangan tanpa sertifikasi',
            'jenis_pajak' => 'PPh 4(2) Final Tax',
            'rate' => 5.0,
            'rate_text' => '5%',
            'keterangan' => 'Jasa Konsultasi Konstruksi (Badan/Perorangan tanpa sertifikasi)',
        ],
        [
            'code' => 'PPH23_SEWA',
            'label' => 'Sewa asset — PPh 23 (2%) — Badan/Perorangan',
            'jenis_pajak' => 'PPh 23',
            'rate' => 2.0,
            'rate_text' => '2%',
            'keterangan' => 'Sewa asset (Badan/Perorangan)',
        ],
        [
            'code' => 'PPH23_JASA',
            'label' => 'Jasa Non-Konstruksi — PPh 23 (2%) — Badan',
            'jenis_pajak' => 'PPh 23',
            'rate' => 2.0,
            'rate_text' => '2%',
            'keterangan' => 'Jasa Non-Konstruksi (Badan)',
        ],
        [
            'code' => 'PPH21_PROG',
            'label' => 'Jasa Non-Konstruksi — PPh 21 (Progresif) — Perorangan',
            'jenis_pajak' => 'PPh 21',
            'rate' => 0.0,
            'rate_text' => 'Progresif',
            'keterangan' => 'Jasa Non-Konstruksi (Perorangan - Tarif Progresif)',
        ],
    ];
}
