<?php
function render_header(string $activePage, string $pageTitle, PDO $pdo, array $user): void
{
    $flash = get_flash();
    $logo = logo_src();
    $role = $user['role'];

    $pendingByRole = 0;
    if ($role === 'MANAGER') {
        $pendingByRole = (int)$pdo->query("SELECT COUNT(*) FROM ppbj_requests WHERE status = 'MENUNGGU_MANAGER'")->fetchColumn();
    } elseif ($role === 'DIREKTUR_OPS') {
        $pendingByRole = (int)$pdo->query("SELECT COUNT(*) FROM ppbj_requests WHERE status = 'MENUNGGU_DIR_OPS'")->fetchColumn();
    } elseif ($role === 'DIREKTUR_KEUANGAN') {
        $pendingByRole = (int)$pdo->query("SELECT COUNT(*) FROM ppbj_requests WHERE status = 'MENUNGGU_DIR_KEU'")->fetchColumn();
    } elseif ($role === 'PROCUREMENT') {
        $pendingByRole = (int)$pdo->query("SELECT COUNT(*) FROM ppbj_requests WHERE status IN ('SIAP_BID','PO_TERBIT','NON_PO')")->fetchColumn();
    } elseif ($role === 'PEMOHON') {
        $stCnt = $pdo->prepare("SELECT COUNT(*) FROM ppbj_requests WHERE user_id = ? AND status NOT IN ('SELESAI_FTB','DITOLAK')");
        $stCnt->execute([(int)$user['id']]);
        $pendingByRole = (int)$stCnt->fetchColumn();
    } else {
        $pendingByRole = (int)$pdo->query("SELECT COUNT(*) FROM ppbj_requests WHERE status IN ('MENUNGGU_MANAGER','MENUNGGU_DIR_OPS','MENUNGGU_DIR_KEU','SIAP_BID')")->fetchColumn();
    }

    if ($role === 'PEMOHON') {
        $nav = [
            ['dashboard', 'Dashboard & Alur', null],
            ['ppbj_list', 'PPBJ Saya (FRM.APR.01.00)', $pendingByRole ?: null],
            ['ppbj_form', '+ Ajukan PPBJ Baru', null],
            ['ftb_list', 'Form Terima Barang (FTB)', null],
            ['divisions', 'Daftar Divisi', null],
        ];
    } else {
        $readyBidCount = (int)$pdo->query("SELECT COUNT(*) FROM ppbj_requests WHERE status = 'SIAP_BID'")->fetchColumn();
        $activePoCount = (int)$pdo->query("SELECT COUNT(*) FROM purchase_orders WHERE status != 'SELESAI_FTB'")->fetchColumn();
        $waitingFtb = (int)$pdo->query("SELECT COUNT(*) FROM purchase_orders WHERE status IN ('TERBIT','DALAM_PENGIRIMAN')")->fetchColumn()
                    + (int)$pdo->query("SELECT COUNT(*) FROM ppbj_requests WHERE status = 'NON_PO'")->fetchColumn();

        $nav = [
            ['dashboard', 'Dashboard & Alur', null],
            ['ppbj_list', 'Daftar PPBJ (FRM.APR.01.00)', $pendingByRole ?: null],
            ['ppbj_form', '+ Ajukan PPBJ Baru', null],
            ['bid_summary_list', 'Bid Summary (Banding Vendor)', $readyBidCount ?: null],
            ['po_list', 'Purchase Order (PO)', $activePoCount ?: null],
            ['ftb_list', 'Form Terima Barang (FTB)', $waitingFtb ?: null],
            ['logbook', 'Logbook Procurement', null],
            ['vendors', 'Master Vendor Rekanan', null],
            ['cost_saving', 'Cost Saving & KPI', null],
            ['top_transactions', 'Top 10 Transaksi Terbesar', null],
            ['payment_terms', 'Payment Term', null],
            ['order_tracking', 'Order Tracking', null],
            ['vendor_compliance', 'Vendor Performance & Compliance', null],
        ];
        if ($role === 'ADMIN') {
            $nav[] = ['divisions', 'Master Divisi (Super Admin)', null];
            $nav[] = ['users', 'Kelola Akun User', null];
        }
    }

    $cssFile = __DIR__ . '/../assets/style.css';
    $inlineCss = is_file($cssFile) ? file_get_contents($cssFile) : '';
    ?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= h($pageTitle) ?> — Sistem Informasi PPBJ &amp; FTB | PT. Potensi Bumi Sakti</title>
  <link rel="icon" type="image/jpeg" href="<?= h($logo) ?>">
  <style><?= $inlineCss ?></style>
</head>
<body>
<div class="app-shell">
  <aside class="sidebar no-print">
    <div class="brand-box">
      <div class="brand-row">
        <img src="<?= h($logo) ?>" alt="Logo PT Potensi Bumi Sakti" class="brand-logo">
        <div>
          <div class="brand-sub">PT. Potensi Bumi Sakti</div>
          <div class="brand-title">Sistem PPBJ &amp; FTB</div>
        </div>
      </div>
      <p class="brand-caption">Sistem Informasi Permintaan Pembelian Barang dan Jasa</p>
    </div>

    <nav class="nav-list">
      <?php foreach ($nav as [$id, $label, $badge]): ?>
        <a href="index.php?page=<?= h($id) ?>" class="nav-item <?= $activePage === $id ? 'active' : '' ?>">
          <span><?= h($label) ?></span>
          <?php if ($badge !== null): ?>
            <span class="nav-badge"><?= $badge ?></span>
          <?php endif; ?>
        </a>
      <?php endforeach; ?>
      <a href="index.php?page=export_csv" class="nav-item">
        <span>Export Rekap PPBJ (.CSV)</span>
      </a>
    </nav>

    <div class="sidebar-footer">
      <div class="role-card">
        <strong><?= h($user['nama_lengkap']) ?></strong>
        <span><?= h(role_label($role)) ?></span>
        <div style="color:#64748b;margin-top:4px;"><?= h($user['jabatan']) ?></div>
        <div style="color:#94a3b8;font-size:11px;margin-top:2px;"><?= h($user['divisi']) ?></div>
        <a href="index.php?page=logout" class="btn btn-outline btn-sm" style="width:100%;margin-top:10px;">
          Logout / Ganti Akun
        </a>
      </div>
    </div>
  </aside>

  <div class="main-col">
    <header class="topbar no-print">
      <div style="display:flex;align-items:center;gap:12px;">
        <img src="<?= h($logo) ?>" alt="Logo PBS" style="width:36px;height:36px;object-fit:contain;border-radius:8px;border:1px solid #e2e8f0;padding:2px;background:#fff;">
        <div>
          <div class="topbar-title">Sistem Informasi Permintaan Pembelian Barang dan Jasa</div>
          <div class="topbar-sub">Pemohon &rarr; Manager &rarr; Dir. Ops &rarr; Dir. Keuangan &rarr; Bid Summary &rarr; PO &rarr; FTB</div>
        </div>
      </div>
      <div class="topbar-actions">
        <div class="role-switcher" style="background:#f0f9ff;border-color:#bae6fd;">
          <span style="color:#0369a1;font-weight:700;"><?= h($user['nama_lengkap']) ?></span>
          <span style="color:#64748b;">(<?= h(role_label($role)) ?>)</span>
        </div>
        <a href="index.php?page=ppbj_form" class="btn btn-primary btn-sm">+ Ajukan PPBJ</a>
        <a href="index.php?page=ftb_form" class="btn btn-green btn-sm">+ Isi FTB</a>
        <a href="index.php?page=logout" class="btn btn-outline btn-sm">Logout</a>
      </div>
    </header>

    <main class="content">
      <?php if ($flash): ?>
        <div class="flash <?= $flash['type'] === 'error' ? 'flash-error' : 'flash-success' ?>">
          <?= h($flash['msg']) ?>
        </div>
      <?php endif; ?>
    <?php
}

function render_footer(): void
{
    ?>
    </main>
  </div>
</div>
</body>
</html>
    <?php
}
