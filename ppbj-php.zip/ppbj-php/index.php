<?php
ob_start();
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/layout.php';
require_once __DIR__ . '/includes/reports.php';

$pdo = get_db();
$page = $_GET['page'] ?? 'dashboard';

if ($page === 'logout') {
    unset($_SESSION['user']);
    set_flash('Anda telah logout.');
    header('Location: login.php');
    exit;
}

$user = refresh_user_from_db($pdo, require_login());
report_ensure_schema($pdo);

if ($page === 'export_csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="Rekap-PPBJ-PotensiBumiSakti-' . date('Y-m-d') . '.csv"');
    $out = fopen('php://output', 'w');
    fprintf($out, chr(0xEF) . chr(0xBB) . chr(0xBF));
    fputcsv($out, [
        'No. PPBJ', 'Tgl Request', 'Tgl Terima', 'Divisi & Sub Divisi', 'Lokasi Pengiriman',
        'Jenis Permintaan', 'Pemohon', 'Manager', 'Direktur Operasional',
        'Direktur Keuangan', 'No. PO', 'Vendor', 'Total Anggaran (Rp)', 'Status'
    ]);
    if ($user['role'] === 'PEMOHON') {
        $stCsv = $pdo->prepare(
            "SELECT p.*, COALESCE(SUM(i.harga_anggaran),0) AS total_anggaran
             FROM ppbj_requests p
             LEFT JOIN ppbj_items i ON i.ppbj_id = p.id
             WHERE p.user_id = ?
             GROUP BY p.id ORDER BY p.id DESC"
        );
        $stCsv->execute([(int)$user['id']]);
        $rows = $stCsv->fetchAll();
    } else {
        $rows = $pdo->query(
            "SELECT p.*, COALESCE(SUM(i.harga_anggaran),0) AS total_anggaran
             FROM ppbj_requests p
             LEFT JOIN ppbj_items i ON i.ppbj_id = p.id
             GROUP BY p.id ORDER BY p.id DESC"
        )->fetchAll();
    }
    foreach ($rows as $r) {
        [$sLabel] = status_meta($r['status']);
        fputcsv($out, [
            $r['request_no'], $r['request_date'], $r['received_date'], $r['division_subdivision'],
            $r['delivery_location'], $r['request_types'], $r['applied_by_name'], $r['manager_name'],
            $r['dir_ops_name'], $r['dir_keu_name'],
            $r['po_no'], $r['vendor_name'], $r['total_anggaran'], $sLabel
        ]);
    }
    fclose($out);
    exit;
}

if ($page === 'export_vendors_csv' || $page === 'vendor_template_csv') {
    $isTemplate = ($page === 'vendor_template_csv');
    $fname = $isTemplate
        ? 'Template-Import-Penyedia-Eksternal-PBS.csv'
        : 'Daftar-Penyedia-Eksternal-Terpilih-PBS-' . date('Y-m-d') . '.csv';
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $fname . '"');
    $out = fopen('php://output', 'w');
    fprintf($out, chr(0xEF) . chr(0xBB) . chr(0xBF));
    fputcsv($out, [
        'NO', 'NAMA PENYEDIA EKSTERNAL', 'NO. REKENING', 'AN. REKENING BANK',
        'NAMA BANK', 'ALAMAT TOKO', 'NO. TELP PENYEDIA EKSTERNAL',
        'ITEM YANG DIJUAL', 'JENIS PENYEDIA', 'PIC', 'EMAIL', 'NPWP', 'KOTA'
    ]);
    if ($isTemplate) {
        fputcsv($out, [
            1, 'PT Contoh Penyedia Abadi', '1234567890', 'PT Contoh Penyedia Abadi',
            'Bank Mandiri', 'Jl. Merdeka No. 10, Meulaboh, Aceh Barat', 'Budi (0812-3456-7890)',
            'Bahan Kimia, Perlengkapan Safety', 'Barang', 'Budi', 'sales@contoh.co.id', '-', 'Meulaboh'
        ]);
    } else {
        $vRows = $pdo->query("SELECT * FROM vendors ORDER BY id ASC")->fetchAll();
        foreach ($vRows as $idx => $v) {
            fputcsv($out, [
                $idx + 1,
                $v['nama_vendor'],
                $v['no_rekening'] ?? '-',
                $v['an_rekening'] ?? '-',
                $v['nama_bank'] ?? '-',
                $v['alamat'] ?? '-',
                $v['telepon'] ?? '-',
                $v['item_dijual'] ?: ($v['kategori'] ?? '-'),
                $v['jenis_penyedia'] ?? 'Barang',
                $v['pic'] ?? '-',
                $v['email'] ?? '-',
                $v['npwp'] ?? '-',
                $v['kota'] ?? '-',
            ]);
        }
    }
    fclose($out);
    exit;
}

if ($page === 'print_ppbj') {
    require __DIR__ . '/pages/print_ppbj.php';
    exit;
}
if ($page === 'print_po') {
    require __DIR__ . '/pages/print_po.php';
    exit;
}
if ($page === 'print_ftb') {
    require __DIR__ . '/pages/print_ftb.php';
    exit;
}
if ($page === 'print_vendors') {
    require __DIR__ . '/pages/print_vendors.php';
    exit;
}
if ($page === 'print_logbook') {
    require __DIR__ . '/pages/print_logbook.php';
    exit;
}
if ($page === 'export_report') {
    require __DIR__ . '/pages/export_report.php';
    exit;
}
if ($page === 'export_logbook_csv') {
    require __DIR__ . '/pages/export_logbook_csv.php';
    exit;
}

$titles = [
    'dashboard' => 'Dashboard',
    'ppbj_list' => 'Daftar PPBJ',
    'ppbj_form' => 'Ajukan Form PPBJ',
    'ppbj_detail' => 'Detail & Approval PPBJ',
    'bid_summary_list' => 'Bid Summary (Perbandingan Harga)',
    'bid_summary_form' => 'Form Bid Summary & Pilih Vendor',
    'po_list' => 'Daftar Purchase Order (PO)',
    'po_form' => 'Buat / Edit Purchase Order (PO)',
    'ftb_list' => 'Daftar Form Terima Barang (FTB)',
    'ftb_form' => 'Form Terima Barang/Jasa (FTB)',
    'logbook' => 'Logbook Procurement',
    'divisions' => 'Master Divisi (Super Admin)',
    'users' => 'Kelola Akun User (Super Admin)',
    'vendors' => 'Master Vendor',
    'cost_saving' => 'Cost Saving & KPI Procurement',
    'top_transactions' => 'Top 10 The Biggest Transaction',
    'payment_terms' => 'Payment Term',
    'order_tracking' => 'Order Tracking',
    'vendor_compliance' => 'Vendor Performance & Compliance',
    'report_settings' => 'Target & Parameter Laporan',
];

$validPages = array_keys($titles);
if (!in_array($page, $validPages, true)) {
    $page = 'dashboard';
}

render_header($page, $titles[$page], $pdo, $user);
require __DIR__ . "/pages/{$page}.php";
render_footer();
if (ob_get_level() > 0) {
    ob_end_flush();
}
