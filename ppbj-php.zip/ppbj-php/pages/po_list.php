<?php
$role = $user['role'];
$canManagePo = in_array($role, ['PROCUREMENT', 'ADMIN'], true);
$bidFilter = isset($_GET['bid_id']) ? (int)$_GET['bid_id'] : 0;
$statusFilter = trim($_GET['status'] ?? '');

$sql = "SELECT po.*, p.request_no, p.division_subdivision, b.bid_no,
               (SELECT COUNT(*) FROM po_items pi WHERE pi.po_id = po.id) AS jml_item
        FROM purchase_orders po
        JOIN ppbj_requests p ON po.ppbj_id = p.id
        LEFT JOIN bid_summaries b ON po.bid_id = b.id
        WHERE 1=1 ";
$params = [];

if ($bidFilter > 0) {
    $sql .= " AND po.bid_id = ? ";
    $params[] = $bidFilter;
}
if ($statusFilter !== '') {
    $sql .= " AND po.status = ? ";
    $params[] = $statusFilter;
}
$sql .= " ORDER BY po.id DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

// Bid Summary yang sudah ada untuk dibuatkan PO tambahan / dipilih langsung
$bidReady = $pdo->query(
    "SELECT b.id, b.bid_no, b.judul, p.request_no
     FROM bid_summaries b
     JOIN ppbj_requests p ON b.ppbj_id = p.id
     ORDER BY b.id DESC"
)->fetchAll();
?>

<div class="card">
  <div class="card-header">
    <div>
      <h1 class="card-title" style="font-size:18px;">Daftar Purchase Order (PO)</h1>
      <div style="font-size:12px;color:#64748b;">PO dapat digenerate dari Bid Summary, diedit oleh Procurement, dicetak, dan ditutup dengan FTB.</div>
    </div>
    <?php if ($canManagePo): ?>
      <div style="display:flex;gap:8px;flex-wrap:wrap;">
        <a href="index.php?page=bid_summary_list" class="btn btn-outline btn-sm">Lihat Bid Summary</a>
        <a href="index.php?page=po_form" class="btn btn-primary btn-sm">+ Buat PO (Pilih dari Bid/PPBJ)</a>
      </div>
    <?php endif; ?>
  </div>

  <form method="get" action="index.php" style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:16px;">
    <input type="hidden" name="page" value="po_list">
    <select name="bid_id" class="form-control" style="width:auto;min-width:250px;">
      <option value="">-- Semua Bid Summary --</option>
      <?php foreach ($bidReady as $b): ?>
        <option value="<?= (int)$b['id'] ?>" <?= $bidFilter === (int)$b['id'] ? 'selected' : '' ?>>
          <?= h($b['bid_no']) ?> (<?= h($b['request_no']) ?>)
        </option>
      <?php endforeach; ?>
    </select>
    <select name="status" class="form-control" style="width:auto;min-width:190px;">
      <option value="">Semua Status PO</option>
      <option value="DRAFT" <?= $statusFilter === 'DRAFT' ? 'selected' : '' ?>>Draft PO</option>
      <option value="TERBIT" <?= $statusFilter === 'TERBIT' ? 'selected' : '' ?>>PO Terbit</option>
      <option value="DALAM_PENGIRIMAN" <?= $statusFilter === 'DALAM_PENGIRIMAN' ? 'selected' : '' ?>>Dalam Pengiriman</option>
      <option value="SELESAI_FTB" <?= $statusFilter === 'SELESAI_FTB' ? 'selected' : '' ?>>Selesai (FTB)</option>
    </select>
    <button type="submit" class="btn btn-primary btn-sm">Filter</button>
    <?php if ($bidFilter > 0 || $statusFilter !== ''): ?>
      <a href="index.php?page=po_list" class="btn btn-outline btn-sm">Reset</a>
    <?php endif; ?>
  </form>

  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th>No. PO &amp; Tanggal</th>
          <th>Referensi PPBJ &amp; Bid Summary</th>
          <th>Vendor / Seller</th>
          <th>Item</th>
          <th style="text-align:right;">Total PO</th>
          <th>Status PO</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($rows)): ?>
          <tr><td colspan="7" style="text-align:center;padding:30px;color:#64748b;">Belum ada Purchase Order.</td></tr>
        <?php else: foreach ($rows as $r): [$pLbl, $pCls] = po_status_meta($r['status']); ?>
          <tr>
            <td>
              <strong><?= h($r['po_no']) ?></strong>
              <div style="font-size:11.5px;color:#64748b;"><?= tgl_indo($r['po_date']) ?></div>
              <div style="font-size:11px;color:#64748b;">Est. Kirim: <?= tgl_indo($r['estimasi_kirim']) ?></div>
            </td>
            <td style="font-size:12px;">
              <div>PPBJ: <a href="index.php?page=ppbj_detail&id=<?= (int)$r['ppbj_id'] ?>" style="font-weight:700;color:#007AB3;"><?= h($r['request_no']) ?></a></div>
              <?php if ($r['bid_no']): ?>
                <div>Bid: <a href="index.php?page=bid_summary_form&id=<?= (int)$r['bid_id'] ?>" style="color:#008A3B;font-weight:600;"><?= h($r['bid_no']) ?></a></div>
              <?php endif; ?>
              <div style="color:#64748b;"><?= h($r['division_subdivision']) ?></div>
            </td>
            <td>
              <strong><?= h($r['vendor_name']) ?></strong>
              <div style="font-size:11.5px;color:#64748b;"><?= h($r['termin_pembayaran']) ?></div>
            </td>
            <td style="text-align:center;font-weight:700;"><?= (int)$r['jml_item'] ?></td>
            <td style="text-align:right;font-weight:700;white-space:nowrap;color:#007AB3;"><?= rupiah($r['total_po']) ?></td>
            <td><span class="badge <?= h($pCls) ?>"><?= h($pLbl) ?></span></td>
            <td style="white-space:nowrap;">
              <?php if ($canManagePo): ?>
                <a href="index.php?page=po_form&id=<?= (int)$r['id'] ?>" class="btn btn-primary btn-sm">Edit PO</a>
              <?php endif; ?>
              <a href="index.php?page=print_po&id=<?= (int)$r['id'] ?>" target="_blank" class="btn btn-outline btn-sm">Cetak PO</a>
              <?php if ($r['status'] !== 'SELESAI_FTB'): ?>
                <a href="index.php?page=ftb_form&po_id=<?= (int)$r['id'] ?>" class="btn btn-green btn-sm">Isi FTB</a>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>
