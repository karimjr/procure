<?php
report_guard($user);
$period = report_period();
$data = report_payment_terms($pdo, $period);
$rows = $data['rows'];
?>
<div class="card">
  <div class="card-header">
    <div>
      <h1 class="card-title" style="font-size:18px;">Payment Term</h1>
      <div style="font-size:12px;color:#64748b;">
        Periode <strong><?= h($period['label']) ?></strong> &middot; Termin pembayaran diambil dari PO/WO (Non-PO dari penawaran vendor pemenang).
      </div>
    </div>
    <?php report_head_actions('payment_terms', $user, false); ?>
  </div>

  <?php report_nav_tabs('payment_terms'); ?>
  <?php report_filter_bar('payment_terms', $period); ?>

  <div class="table-wrap">
    <table class="rpt-table">
      <thead>
        <tr>
          <th rowspan="2" style="width:44px;">No</th>
          <th rowspan="2" style="min-width:260px;">Payment term</th>
          <th colspan="2">Number of order</th>
          <th colspan="2">Total Value</th>
        </tr>
        <tr>
          <th style="min-width:90px;">Qty</th>
          <th style="min-width:90px;">in %</th>
          <th style="min-width:140px;">in IDR</th>
          <th style="min-width:90px;">in %</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($rows as $r): ?>
          <tr>
            <td style="text-align:center;"><?= (int)$r['no'] ?></td>
            <td><?= h($r['label']) ?></td>
            <td class="num"><?= (int)$r['qty'] ?></td>
            <td class="num"><?= fmt_pct($r['qty_pct']) ?></td>
            <td class="num"><?= fmt_idr($r['value']) ?></td>
            <td class="num"><?= fmt_pct($r['value_pct']) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
      <tfoot>
        <tr class="rpt-group">
          <td></td><td style="font-weight:700;">Total</td>
          <td class="num"><?= (int)$data['total_qty'] ?></td>
          <td class="num"><?= $data['total_qty'] > 0 ? '100,0%' : '-' ?></td>
          <td class="num"><?= fmt_idr($data['total_value']) ?></td>
          <td class="num"><?= $data['total_value'] > 0 ? '100,0%' : '-' ?></td>
        </tr>
      </tfoot>
    </table>
  </div>
  <div class="rpt-foot">
    Teks termin pada PO dikelompokkan otomatis (CBD, COD, Credit N days, DP/Progress Payment, L/C, dll). Termin yang tidak dikenali masuk baris <em>Lainnya</em>.
  </div>
</div>
