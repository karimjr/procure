<?php
$role = $user['role'];
$canManageBid = in_array($role, ['PROCUREMENT', 'ADMIN'], true);

$bidId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$prePpbjId = isset($_GET['ppbj_id']) ? (int)$_GET['ppbj_id'] : 0;

$existingBid = null;
$bidVendors = [];
$bidQuotes = []; // [ppbj_item_id][bid_vendor_index] => ['harga' => ..., 'selected' => ...]

if ($bidId > 0) {
    $st = $pdo->prepare("SELECT * FROM bid_summaries WHERE id = ?");
    $st->execute([$bidId]);
    $existingBid = $st->fetch();
    if ($existingBid) {
        $prePpbjId = (int)$existingBid['ppbj_id'];
        $bvSt = $pdo->prepare("SELECT * FROM bid_vendors WHERE bid_id = ? ORDER BY id ASC");
        $bvSt->execute([$bidId]);
        $bidVendors = $bvSt->fetchAll();

        $biSt = $pdo->prepare("SELECT * FROM bid_items WHERE bid_id = ?");
        $biSt->execute([$bidId]);
        $bvIndexMap = [];
        foreach ($bidVendors as $idx => $bv) {
            $bvIndexMap[(int)$bv['id']] = $idx;
        }
        foreach ($biSt->fetchAll() as $bi) {
            $vIdx = $bvIndexMap[(int)$bi['bid_vendor_id']] ?? null;
            if ($vIdx !== null) {
                $bidQuotes[(int)$bi['ppbj_item_id']][$vIdx] = [
                    'harga' => (float)$bi['harga_penawaran'],
                    'selected' => (int)$bi['is_selected'],
                    'jalur' => $bi['jalur_pengadaan'] ?? 'PO',
                ];
            }
        }
    }
}

$ppbjList = $pdo->query(
    "SELECT id, request_no, division_subdivision, delivery_location, status
     FROM ppbj_requests
     WHERE status IN ('SIAP_BID', 'PO_TERBIT', 'NON_PO', 'SELESAI_FTB')
     ORDER BY id DESC"
)->fetchAll();

if ($prePpbjId === 0 && !empty($ppbjList)) {
    foreach ($ppbjList as $pItem) {
        if ($pItem['status'] === 'SIAP_BID') {
            $prePpbjId = (int)$pItem['id'];
            break;
        }
    }
    if ($prePpbjId === 0) {
        $prePpbjId = (int)$ppbjList[0]['id'];
    }
}

$selectedPpbj = null;
$ppbjItems = [];
if ($prePpbjId > 0) {
    $pSt = $pdo->prepare("SELECT * FROM ppbj_requests WHERE id = ?");
    $pSt->execute([$prePpbjId]);
    $selectedPpbj = $pSt->fetch();
    if ($selectedPpbj) {
        $itSt = $pdo->prepare("SELECT * FROM ppbj_items WHERE ppbj_id = ? ORDER BY item_no ASC");
        $itSt->execute([$prePpbjId]);
        $ppbjItems = $itSt->fetchAll();
    }
}

$allVendors = $pdo->query("SELECT * FROM vendors WHERE aktif = 1 ORDER BY nama_vendor ASC")->fetchAll();
$vendorById = [];
foreach ($allVendors as $av) {
    $vendorById[(int)$av['id']] = $av;
}

if (empty($bidVendors)) {
    $bidVendors = [
        [
            'vendor_id' => $allVendors[0]['id'] ?? 0,
            'vendor_name' => $allVendors[0]['nama_vendor'] ?? '',
            'termin_pembayaran' => 'TOP 30 Hari setelah FTB',
            'estimasi_kirim' => '5 Hari Kerja',
        ],
        [
            'vendor_id' => $allVendors[1]['id'] ?? ($allVendors[0]['id'] ?? 0),
            'vendor_name' => $allVendors[1]['nama_vendor'] ?? '',
            'termin_pembayaran' => 'TOP 14 Hari setelah FTB',
            'estimasi_kirim' => '7 Hari Kerja',
        ],
    ];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$canManageBid) {
        set_flash('Hanya akun Procurement / Admin yang dapat menyimpan Bid Summary atau Generate PO.', 'error');
        redirect_to('index.php?page=bid_summary_list');
    }

    $postPpbjId = (int)($_POST['ppbj_id'] ?? 0);
    $bidNo = trim($_POST['bid_no'] ?? next_bid_no($pdo));
    $bidDate = $_POST['bid_date'] ?: date('Y-m-d');
    $judul = trim($_POST['judul'] ?? 'Bid Summary Perbandingan Vendor');
    $catatan = trim($_POST['catatan_rekomendasi'] ?? '');
    $actionMode = $_POST['action_mode'] ?? 'save'; // save | generate_po

    $vIds = $_POST['bv_vendor_id'] ?? [];
    $vTermins = $_POST['bv_termin'] ?? [];
    $vEsts = $_POST['bv_estimasi'] ?? [];

    $quotesPost = $_POST['quote'] ?? []; // quote[ppbj_item_id][vIdx]
    $winnerPost = $_POST['winner'] ?? []; // winner[ppbj_item_id] = vIdx
    $jalurPost = $_POST['item_jalur'] ?? []; // item_jalur[ppbj_item_id] = PO | NON_PO

    try {
        if ($postPpbjId <= 0) {
            throw new RuntimeException('Pilih PPBJ terlebih dahulu.');
        }

        $pSt = $pdo->prepare("SELECT * FROM ppbj_requests WHERE id = ?");
        $pSt->execute([$postPpbjId]);
        $targetPpbj = $pSt->fetch();
        if (!$targetPpbj) {
            throw new RuntimeException('PPBJ tidak ditemukan.');
        }

        $itSt = $pdo->prepare("SELECT * FROM ppbj_items WHERE ppbj_id = ? ORDER BY item_no ASC");
        $itSt->execute([$postPpbjId]);
        $targetItems = $itSt->fetchAll();

        $cleanVendors = [];
        for ($i = 0; $i < count($vIds); $i++) {
            $vid = (int)$vIds[$i];
            if ($vid > 0 && isset($vendorById[$vid])) {
                $cleanVendors[$i] = [
                    'vendor_id' => $vid,
                    'vendor_name' => $vendorById[$vid]['nama_vendor'],
                    'termin' => trim($vTermins[$i] ?? 'TOP 30 Hari setelah FTB'),
                    'estimasi' => trim($vEsts[$i] ?? '7 Hari Kerja'),
                ];
            }
        }

        if (count($cleanVendors) < 1) {
            throw new RuntimeException('Minimal pilih 1 vendor pembanding.');
        }

        // Tentukan proses_mode ringkasan bid (PO jika ada item PO, NON_PO jika semua item Non-PO)
        $hasPoItem = false;
        $hasNonPoItem = false;
        foreach ($targetItems as $it) {
            $jVal = ($jalurPost[(int)$it['id']] ?? 'PO') === 'NON_PO' ? 'NON_PO' : 'PO';
            if ($jVal === 'NON_PO') $hasNonPoItem = true;
            else $hasPoItem = true;
        }
        $prosesMode = (!$hasPoItem && $hasNonPoItem) ? 'NON_PO' : 'PO';

        $pdo->beginTransaction();

        if ($bidId > 0 && $existingBid) {
            $pdo->prepare(
                "UPDATE bid_summaries SET bid_no = ?, bid_date = ?, ppbj_id = ?, judul = ?, proses_mode = ?, catatan_rekomendasi = ?, status = 'FINAL' WHERE id = ?"
            )->execute([$bidNo, $bidDate, $postPpbjId, $judul, $prosesMode, $catatan, $bidId]);
            $pdo->prepare("DELETE FROM bid_items WHERE bid_id = ?")->execute([$bidId]);
            $pdo->prepare("DELETE FROM bid_vendors WHERE bid_id = ?")->execute([$bidId]);
            $savedBidId = $bidId;
        } else {
            $pdo->prepare(
                "INSERT INTO bid_summaries (bid_no, bid_date, ppbj_id, judul, proses_mode, catatan_rekomendasi, dibuat_oleh, status)
                 VALUES (?, ?, ?, ?, ?, ?, ?, 'FINAL')"
            )->execute([$bidNo, $bidDate, $postPpbjId, $judul, $prosesMode, $catatan, $user['nama_lengkap']]);
            $savedBidId = (int)$pdo->lastInsertId();
        }

        $insBv = $pdo->prepare(
            "INSERT INTO bid_vendors (bid_id, vendor_id, vendor_name, termin_pembayaran, estimasi_kirim) VALUES (?, ?, ?, ?, ?)"
        );
        $bvDbIds = [];
        foreach ($cleanVendors as $idx => $cv) {
            $insBv->execute([$savedBidId, $cv['vendor_id'], $cv['vendor_name'], $cv['termin'], $cv['estimasi']]);
            $bvDbIds[$idx] = [
                'db_id' => (int)$pdo->lastInsertId(),
                'vendor_id' => $cv['vendor_id'],
                'vendor_name' => $cv['vendor_name'],
                'termin' => $cv['termin'],
            ];
        }

        $insBi = $pdo->prepare(
            "INSERT INTO bid_items (bid_id, ppbj_item_id, bid_vendor_id, harga_penawaran, total_penawaran, jalur_pengadaan, is_selected)
             VALUES (?, ?, ?, ?, ?, ?, ?)"
        );
        $updPpbjItemJalur = $pdo->prepare("UPDATE ppbj_items SET jalur_pengadaan = ? WHERE id = ?");

        // Kelompokkan item pemenang yang berjalur PO per vendor untuk generate PO otomatis
        $winningPoByVendor = []; // [vIdx] => [items...]
        $nonPoItems = []; // item yang ditandai NON_PO (tidak dibuatkan PO, langsung ke FTB)

        foreach ($targetItems as $it) {
            $itemId = (int)$it['id'];
            $jalurItem = ($jalurPost[$itemId] ?? 'PO') === 'NON_PO' ? 'NON_PO' : 'PO';
            $updPpbjItemJalur->execute([$jalurItem, $itemId]);

            $winIdx = isset($winnerPost[$itemId]) ? (int)$winnerPost[$itemId] : (int)array_key_first($bvDbIds);
            if (!isset($bvDbIds[$winIdx])) {
                $winIdx = (int)array_key_first($bvDbIds);
            }

            foreach ($bvDbIds as $vIdx => $bvMeta) {
                $harga = max(0, (float)($quotesPost[$itemId][$vIdx] ?? $it['harga_unit']));
                $tot = $harga * (float)$it['jumlah'];
                $isSelected = ($vIdx === $winIdx) ? 1 : 0;
                $insBi->execute([$savedBidId, $itemId, $bvMeta['db_id'], $harga, $tot, $jalurItem, $isSelected]);

                if ($isSelected === 1) {
                    if ($jalurItem === 'PO') {
                        $winningPoByVendor[$vIdx][] = [
                            'ppbj_item_id' => $itemId,
                            'nama_barang_jasa' => $it['nama_barang_jasa'],
                            'qty' => (float)$it['jumlah'],
                            'satuan' => $it['satuan'],
                            'harga_satuan' => $harga,
                            'subtotal' => $tot,
                        ];
                    } else {
                        $nonPoItems[] = [
                            'ppbj_item_id' => $itemId,
                            'nama_barang_jasa' => $it['nama_barang_jasa'],
                            'vendor_name' => $bvMeta['vendor_name'],
                            'subtotal' => $tot,
                        ];
                    }
                }
            }
        }

        $createdPoNos = [];
        $createdVendorNames = [];

        if ($actionMode === 'generate_po') {
            $today = date('Y-m-d');
            if (!empty($winningPoByVendor)) {
                $insPo = $pdo->prepare(
                    "INSERT INTO purchase_orders (
                        order_type, po_no, po_date, ppbj_id, bid_id, vendor_id, vendor_name,
                        seller_address, seller_contact, seller_email,
                        termin_pembayaran, terms_of_delivery, lead_time_delivery, quotation_ref,
                        estimasi_kirim, delivery_location, delivery_contact,
                        purchase_reference, division_dept,
                        subtotal_po, delivery_fee, discount_amount, vat_percent, vat_amount, withholding_tax_pct,
                        catatan, total_po, pbs_signer_name, status, dibuat_oleh
                     ) VALUES (
                        'PURCHASE ORDER', ?, ?, ?, ?, ?, ?,
                        ?, ?, ?,
                        ?, 'Franco PBS Site', ?, '-',
                        ?, ?, 'T Safril Nizam TM (082213151408)',
                        ?, ?,
                        ?, 0, 0, 0, 0, 0,
                        ?, ?, ?, 'TERBIT', ?
                     )"
                );
                $insPoItem = $pdo->prepare(
                    "INSERT INTO po_items (po_id, ppbj_item_id, item_no, nama_barang_jasa, qty, satuan, harga_satuan, subtotal)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
                );

                foreach ($winningPoByVendor as $vIdx => $winItems) {
                    $bvMeta = $bvDbIds[$vIdx];
                    $vDetail = $vendorById[$bvMeta['vendor_id']] ?? [];
                    $sellerAddr = trim(($vDetail['alamat'] ?? '') . (!empty($vDetail['kota']) ? ', ' . $vDetail['kota'] : ''), ', ');
                    $sellerContact = trim(($vDetail['pic'] ?? '-') . (!empty($vDetail['telepon']) ? ' (' . $vDetail['telepon'] . ')' : ''));
                    $sellerEmail = $vDetail['email'] ?? '-';
                    $poNo = next_po_no($pdo);
                    $totalPo = array_sum(array_column($winItems, 'subtotal'));

                    $insPo->execute([
                        $poNo,
                        $today,
                        $postPpbjId,
                        $savedBidId,
                        $bvMeta['vendor_id'],
                        $bvMeta['vendor_name'],
                        $sellerAddr ?: '-',
                        $sellerContact ?: '-',
                        $sellerEmail,
                        $bvMeta['termin'],
                        $cleanVendors[$vIdx]['estimasi'] ?? '14 Days',
                        $targetPpbj['received_date'] ?: date('Y-m-d', strtotime('+7 days')),
                        $targetPpbj['delivery_location'],
                        $targetPpbj['request_no'],
                        $targetPpbj['division_code'] ?: $targetPpbj['division_subdivision'],
                        $totalPo,
                        "Generate otomatis dari Bid Summary {$bidNo}",
                        $totalPo,
                        $user['nama_lengkap'],
                        $user['nama_lengkap'],
                    ]);
                    $newPoId = (int)$pdo->lastInsertId();

                    foreach ($winItems as $idxItem => $wi) {
                        $insPoItem->execute([
                            $newPoId,
                            $wi['ppbj_item_id'],
                            $idxItem + 1,
                            $wi['nama_barang_jasa'],
                            $wi['qty'],
                            $wi['satuan'],
                            $wi['harga_satuan'],
                            $wi['subtotal'],
                        ]);
                    }

                    $createdPoNos[] = $poNo;
                    $createdVendorNames[] = $bvMeta['vendor_name'];
                }
            }

            // Sinkronkan status PPBJ (PO_TERBIT jika ada PO, NON_PO jika seluruh item Non-PO)
            $allPoForPpbj = $pdo->prepare("SELECT po_no, vendor_name FROM purchase_orders WHERE ppbj_id = ? ORDER BY id ASC");
            $allPoForPpbj->execute([$postPpbjId]);
            $poRows = $allPoForPpbj->fetchAll();

            $nonPoVendors = array_column($nonPoItems, 'vendor_name');
            $allVendorsSummary = array_unique(array_merge(array_column($poRows, 'vendor_name'), $nonPoVendors));
            $vendorSummary = implode(', ', array_filter($allVendorsSummary));

            if (!empty($poRows)) {
                $poNoSummary = implode(', ', array_column($poRows, 'po_no'));
                if (!empty($nonPoItems)) {
                    $poNoSummary .= ' (+ ' . count($nonPoItems) . ' item Non-PO)';
                }
                $newPpbjStatus = 'PO_TERBIT';
            } else {
                $poNoSummary = 'NON-PO (' . $bidNo . ')';
                $newPpbjStatus = 'NON_PO';
            }

            $pdo->prepare("UPDATE ppbj_requests SET status = ?, po_no = ?, po_date = ?, vendor_name = ? WHERE id = ?")
                ->execute([$newPpbjStatus, $poNoSummary, $today, $vendorSummary, $postPpbjId]);

            $logDesc = [];
            if (!empty($createdPoNos)) $logDesc[] = 'PO Terbit: ' . implode(', ', $createdPoNos);
            if (!empty($nonPoItems)) $logDesc[] = count($nonPoItems) . ' barang jalur Non-PO langsung ke FTB';
            $pdo->prepare("INSERT INTO ppbj_logs (ppbj_id, actor_name, actor_role, aksi, catatan) VALUES (?, ?, ?, ?, ?)")
                ->execute([
                    $postPpbjId,
                    $user['nama_lengkap'],
                    'Procurement',
                    'Bid Summary Diproses (' . count($createdPoNos) . ' PO, ' . count($nonPoItems) . ' Non-PO)',
                    implode(' | ', $logDesc),
                ]);
        } else {
            $pdo->prepare("INSERT INTO ppbj_logs (ppbj_id, actor_name, actor_role, aksi, catatan) VALUES (?, ?, ?, ?, ?)")
                ->execute([
                    $postPpbjId,
                    $user['nama_lengkap'],
                    'Procurement',
                    "Bid Summary Disimpan ({$bidNo})",
                    'Perbandingan ' . count($bvDbIds) . ' vendor disimpan.',
                ]);
        }

        $pdo->commit();

        if ($actionMode === 'generate_po') {
            if (!empty($createdPoNos) && !empty($nonPoItems)) {
                set_flash(count($createdPoNos) . ' PO berhasil dibuat (' . implode(', ', $createdPoNos) . '), dan ' . count($nonPoItems) . ' barang ditandai Non-PO (langsung ke FTB).');
                redirect_to("index.php?page=bid_summary_form&id={$savedBidId}");
            } elseif (!empty($createdPoNos)) {
                set_flash(count($createdPoNos) . ' Purchase Order berhasil dibuat otomatis dari Bid Summary: ' . implode(', ', $createdPoNos));
                redirect_to("index.php?page=po_list&bid_id={$savedBidId}");
            } else {
                set_flash(count($nonPoItems) . ' barang diproses sebagai Non-PO (tanpa PO) dan langsung siap dibuatkan Form Terima Barang (FTB).');
                redirect_to("index.php?page=ftb_form&nonpo_ppbj_id={$postPpbjId}");
            }
        } else {
            set_flash("Bid Summary {$bidNo} berhasil disimpan.");
            redirect_to("index.php?page=bid_summary_form&id={$savedBidId}");
        }
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        set_flash('Gagal memproses Bid Summary: ' . $e->getMessage(), 'error');
    }
}

$defaultBidNo = $existingBid['bid_no'] ?? next_bid_no($pdo);
$defaultBidDate = $existingBid['bid_date'] ?? date('Y-m-d');
$defaultJudul = $existingBid['judul'] ?? ($selectedPpbj ? 'Bid Summary — ' . $selectedPpbj['division_subdivision'] : 'Bid Summary Perbandingan Vendor');

// PO yang sudah pernah digenerate dari Bid Summary ini
$existingBidPos = [];
if ($bidId > 0) {
    $epSt = $pdo->prepare("SELECT * FROM purchase_orders WHERE bid_id = ? ORDER BY id ASC");
    $epSt->execute([$bidId]);
    $existingBidPos = $epSt->fetchAll();
}
?>

<form method="post" id="bidForm">
  <div class="card">
    <div class="card-header">
      <div>
        <h1 class="card-title" style="font-size:18px;">
          <?= $bidId > 0 ? 'Bid Summary: ' . h($defaultBidNo) : 'Buat Bid Summary (Perbandingan Harga Beberapa Vendor)' ?>
        </h1>
        <div style="font-size:12px;color:#64748b;">
          Pilih PPBJ &rarr; Pilih Vendor Pembanding &rarr; Pilih Pemenang per Item &rarr; Generate 1 atau Beberapa PO otomatis tanpa ketik ulang.
        </div>
      </div>
      <a href="index.php?page=bid_summary_list" class="btn btn-outline btn-sm">&larr; Daftar Bid Summary</a>
    </div>

    <div class="grid-3">
      <div class="form-group">
        <label class="form-label">Pilih Referensi PPBJ *</label>
        <select name="ppbj_id" class="form-control" required onchange="if(this.value && <?= $bidId === 0 ? 'true' : 'false' ?>){window.location='index.php?page=bid_summary_form&ppbj_id='+this.value;}">
          <?php if (empty($ppbjList)): ?>
            <option value="">-- Belum ada PPBJ berstatus Siap Bid Summary --</option>
          <?php else: foreach ($ppbjList as $pOpt): ?>
            <option value="<?= (int)$pOpt['id'] ?>" <?= $prePpbjId === (int)$pOpt['id'] ? 'selected' : '' ?>>
              <?= h($pOpt['request_no']) ?> — <?= h($pOpt['division_subdivision']) ?> (<?= h($pOpt['status']) ?>)
            </option>
          <?php endforeach; endif; ?>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Nomor Bid Summary *</label>
        <input type="text" name="bid_no" class="form-control" required value="<?= h($defaultBidNo) ?>">
      </div>
      <div class="form-group">
        <label class="form-label">Tanggal Bid Summary *</label>
        <input type="date" name="bid_date" class="form-control" required value="<?= h($defaultBidDate) ?>">
      </div>
    </div>

    <div class="grid-2">
      <div class="form-group">
        <label class="form-label">Judul Bid Summary *</label>
        <input type="text" name="judul" class="form-control" required value="<?= h($defaultJudul) ?>">
      </div>
      <div class="form-group">
        <label class="form-label">Catatan Rekomendasi Pemilihan Vendor</label>
        <input type="text" name="catatan_rekomendasi" class="form-control" value="<?= h($existingBid['catatan_rekomendasi'] ?? '') ?>" placeholder="Alasan memilih pemenang (harga terbaik, garansi, ketersediaan stok)...">
      </div>
    </div>
  </div>

  <!-- Daftar Vendor Pembanding (2..4 Vendor) -->
  <div class="card">
    <div class="card-header">
      <div>
        <h2 class="card-title">1. Vendor Pembanding (Tinggal Pilih dari Master Vendor)</h2>
        <div style="font-size:12px;color:#64748b;">Anda dapat membandingkan 2, 3, atau 4 vendor sekaligus.</div>
      </div>
      <button type="button" onclick="addVendorColumn()" class="btn btn-outline btn-sm">+ Tambah Vendor Pembanding</button>
    </div>

    <div class="grid-2" id="vendorCardsWrap">
      <?php foreach ($bidVendors as $vIdx => $bv): ?>
        <div class="disp-box vendor-card" data-vidx="<?= $vIdx ?>">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
            <h4 style="margin:0;">Vendor Pembanding #<?= $vIdx + 1 ?></h4>
            <?php if ($vIdx >= 2): ?>
              <button type="button" onclick="removeVendorCol(<?= $vIdx ?>)" class="btn btn-outline btn-sm" style="color:#dc2626;">Hapus</button>
            <?php endif; ?>
          </div>
          <div class="form-group">
            <label class="form-label">Pilih Vendor *</label>
            <select name="bv_vendor_id[<?= $vIdx ?>]" class="form-control vendor-select" onchange="updateVendorLabels()">
              <?php foreach ($allVendors as $av): ?>
                <option value="<?= (int)$av['id'] ?>" <?= (int)($bv['vendor_id'] ?? 0) === (int)$av['id'] ? 'selected' : '' ?>>
                  <?= h($av['nama_vendor']) ?> (<?= h($av['kategori']) ?>)
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="grid-2" style="margin-bottom:0;">
            <div>
              <label class="form-label">Termin Pembayaran</label>
              <input type="text" name="bv_termin[<?= $vIdx ?>]" list="paymentTermsList" class="form-control" value="<?= h($bv['termin_pembayaran'] ?? 'Credit, 30 days after receipt of the invoice and BAST / Delivery Note') ?>">
            </div>
            <div>
              <label class="form-label">Estimasi Kirim</label>
              <input type="text" name="bv_estimasi[<?= $vIdx ?>]" class="form-control" value="<?= h($bv['estimasi_kirim'] ?? '7 Hari Kerja') ?>">
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Matriks Perbandingan Harga per Item -->
  <div class="card">
    <div class="card-header">
      <div>
        <h2 class="card-title">2. Matriks Perbandingan Harga, Jalur Barang (PO / Non PO) &amp; Pemilihan Pemenang</h2>
        <div style="font-size:12px;color:#64748b;">Pilih <strong>PO</strong> atau <strong>Non PO (Opsional)</strong> pada masing-masing barang. Barang berjalur <strong>PO</strong> dipecah jadi PO per vendor pemenang, sedangkan barang <strong>Non PO</strong> langsung ke FTB!</div>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;">
        <button type="button" onclick="autoPickCheapest()" class="btn btn-green btn-sm">Pilih Harga Termurah Otomatis</button>
      </div>
    </div>

    <?php if (empty($ppbjItems)): ?>
      <p style="color:#64748b;font-size:13px;">Pilih PPBJ yang memiliki daftar item di atas.</p>
    <?php else: ?>
      <div class="table-wrap">
        <table class="data-table" id="bidMatrixTable">
          <thead>
            <tr>
              <th>No</th>
              <th style="min-width:200px;">Nama Barang / Jasa (PPBJ)</th>
              <th>Qty</th>
              <th style="text-align:right;">Harga Budget</th>
              <th style="min-width:155px;background:#faf5ff;color:#5b21b6;">Jalur Barang</th>
              <?php foreach ($bidVendors as $vIdx => $bv): ?>
                <th class="vcol-head" data-vidx="<?= $vIdx ?>" style="min-width:210px;background:#f0f9ff;">
                  <div style="color:#0369a1;">Vendor #<?= $vIdx + 1 ?>: <span class="v-label-<?= $vIdx ?>"><?= h($bv['vendor_name'] ?: 'Pilih Vendor') ?></span></div>
                  <button type="button" onclick="pickAllForVendor(<?= $vIdx ?>)" class="btn btn-outline btn-sm" style="margin-top:4px;font-size:10.5px;padding:3px 7px;">Pilih Semua Item</button>
                </th>
              <?php endforeach; ?>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($ppbjItems as $it):
              $itemId = (int)$it['id'];
              // tentukan pemenang default & jalur default
              $selectedIdx = 0;
              $jalurItem = $it['jalur_pengadaan'] ?? 'PO';
              foreach ($bidVendors as $vIdx => $_) {
                  if (!empty($bidQuotes[$itemId][$vIdx]['selected'])) {
                      $selectedIdx = $vIdx;
                      $jalurItem = $bidQuotes[$itemId][$vIdx]['jalur'] ?? $jalurItem;
                  }
              }
            ?>
              <tr class="bid-item-row" data-itemid="<?= $itemId ?>" data-qty="<?= (float)$it['jumlah'] ?>">
                <td><?= (int)$it['item_no'] ?></td>
                <td>
                  <strong><?= h($it['nama_barang_jasa']) ?></strong>
                  <div style="font-size:11px;color:#64748b;"><?= h($it['peruntukan']) ?></div>
                </td>
                <td style="white-space:nowrap;"><strong><?= rtrim(rtrim((string)$it['jumlah'], '0'), '.') ?></strong> <?= h($it['satuan']) ?></td>
                <td style="text-align:right;white-space:nowrap;color:#64748b;"><?= rupiah($it['harga_unit']) ?></td>
                <td style="background:#faf5ff;">
                  <select name="item_jalur[<?= $itemId ?>]" class="form-control item-jalur-sel" onchange="recalcBidTotals()" style="font-weight:700;font-size:12px;">
                    <option value="PO" <?= $jalurItem === 'PO' ? 'selected' : '' ?>>Via PO</option>
                    <option value="NON_PO" <?= $jalurItem === 'NON_PO' ? 'selected' : '' ?>>Non PO (Langsung FTB)</option>
                  </select>
                </td>
                <?php foreach ($bidVendors as $vIdx => $bv):
                  $qPrice = $bidQuotes[$itemId][$vIdx]['harga'] ?? (float)$it['harga_unit'];
                ?>
                  <td class="vcol-cell" data-vidx="<?= $vIdx ?>">
                    <div style="display:flex;flex-direction:column;gap:5px;">
                      <input type="number" step="100" min="0"
                        name="quote[<?= $itemId ?>][<?= $vIdx ?>]"
                        value="<?= h((string)$qPrice) ?>"
                        class="form-control quote-input"
                        data-vidx="<?= $vIdx ?>"
                        oninput="recalcBidTotals()">
                      <div style="display:flex;align-items:center;justify-content:space-between;font-size:11.5px;">
                        <span class="quote-sub-<?= $itemId ?>-<?= $vIdx ?>" style="font-weight:700;color:#334155;">
                          <?= rupiah($qPrice * (float)$it['jumlah']) ?>
                        </span>
                        <label style="display:inline-flex;align-items:center;gap:4px;font-weight:700;color:#008A3B;cursor:pointer;">
                          <input type="radio" name="winner[<?= $itemId ?>]" value="<?= $vIdx ?>" <?= $selectedIdx === $vIdx ? 'checked' : '' ?> onchange="recalcBidTotals()">
                          Pemenang
                        </label>
                      </div>
                    </div>
                  </td>
                <?php endforeach; ?>
              </tr>
            <?php endforeach; ?>
          </tbody>
          <tfoot>
            <tr style="background:#f8fafc;">
              <td colspan="5" style="text-align:right;font-weight:800;">Total Penawaran Vendor</td>
              <?php foreach ($bidVendors as $vIdx => $_): ?>
                <td style="font-weight:800;color:#007AB3;" id="vendorTotal_<?= $vIdx ?>">Rp 0</td>
              <?php endforeach; ?>
            </tr>
            <tr style="background:#ecfdf5;">
              <td colspan="5" style="text-align:right;font-weight:800;color:#166534;">Total Item Dimenangkan (Akan Jadi PO)</td>
              <?php foreach ($bidVendors as $vIdx => $_): ?>
                <td style="font-weight:800;color:#166534;" id="vendorWonTotal_<?= $vIdx ?>">Rp 0 (0 item PO)</td>
              <?php endforeach; ?>
            </tr>
          </tfoot>
        </table>
      </div>
      <div id="nonPoInfoBanner" style="display:none;margin-top:10px;padding:10px 14px;border-radius:10px;background:#f5f3ff;border:1px solid #ddd6fe;color:#5b21b6;font-size:12.5px;font-weight:600;"></div>
    <?php endif; ?>

    <?php if ($canManageBid && !empty($ppbjItems)): ?>
      <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:18px;flex-wrap:wrap;">
        <button type="submit" name="action_mode" value="save" class="btn btn-outline">Simpan Bid Summary Saja</button>
        <button type="submit" name="action_mode" value="generate_po" class="btn btn-green">Simpan Bid Summary &amp; Proses (PO / Non PO) &rarr;</button>
      </div>
    <?php elseif (!$canManageBid): ?>
      <div class="flash flash-error" style="margin-top:16px;margin-bottom:0;">
        Mode Baca Saja: Hanya akun <strong>Procurement</strong> (<code>noviani</code> / <code>safril</code> / <code>ichsan</code>) yang dapat menyimpan Bid Summary dan menerbitkan PO.
      </div>
    <?php endif; ?>
  </div>
</form>

<datalist id="paymentTermsList">
  <?php foreach (po_payment_terms_options() as $ptOpt): ?>
    <option value="<?= h($ptOpt) ?>">
  <?php endforeach; ?>
</datalist>

<?php
$nonPoSavedItems = array_filter($ppbjItems, fn($x) => ($x['jalur_pengadaan'] ?? 'PO') === 'NON_PO');
if ($bidId > 0 && !empty($nonPoSavedItems)):
?>
<div class="card" style="border-color:#c4b5fd;background:#f5f3ff;">
  <div class="card-header" style="border-bottom-color:#ddd6fe;">
    <div>
      <h2 class="card-title" style="color:#5b21b6;">Barang Jalur Non PO (<?= count($nonPoSavedItems) ?> Item — Langsung ke FTB)</h2>
      <div style="font-size:12.5px;color:#6d28d9;">Barang berikut ditandai <strong>Non PO</strong> sehingga tidak diterbitkan PO dan langsung masuk antrean Form Terima Barang (FTB).</div>
    </div>
    <a href="index.php?page=ftb_form&nonpo_ppbj_id=<?= (int)$prePpbjId ?>" class="btn btn-green">Isi Form FTB (Item Non PO) &rarr;</a>
  </div>
  <ul style="margin:0;padding-left:20px;font-size:13px;color:#3b0764;">
    <?php foreach ($nonPoSavedItems as $npi): ?>
      <li><strong><?= h($npi['nama_barang_jasa']) ?></strong> — <?= rtrim(rtrim((string)$npi['jumlah'], '0'), '.') ?> <?= h($npi['satuan']) ?></li>
    <?php endforeach; ?>
  </ul>
</div>
<?php endif; ?>

<?php if (!empty($existingBidPos)): ?>
<div class="card" style="border-color:#93c5fd;">
  <div class="card-header">
    <h2 class="card-title" style="color:#1e40af;">Purchase Order yang Dihasilkan dari Bid Summary Ini</h2>
  </div>
  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr><th>No. PO</th><th>Vendor</th><th>Total PO</th><th>Status</th><th>Aksi</th></tr>
      </thead>
      <tbody>
        <?php foreach ($existingBidPos as $ep): [$pLbl, $pCls] = po_status_meta($ep['status']); ?>
          <tr>
            <td><strong><?= h($ep['po_no']) ?></strong></td>
            <td><?= h($ep['vendor_name']) ?></td>
            <td style="font-weight:700;"><?= rupiah($ep['total_po']) ?></td>
            <td><span class="badge <?= h($pCls) ?>"><?= h($pLbl) ?></span></td>
            <td>
              <a href="index.php?page=po_form&id=<?= (int)$ep['id'] ?>" class="btn btn-primary btn-sm">Edit PO</a>
              <a href="index.php?page=print_po&id=<?= (int)$ep['id'] ?>" target="_blank" class="btn btn-outline btn-sm">Cetak PO</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<script>
const allVendorsData = <?= json_encode(array_map(fn($v) => ['id' => (int)$v['id'], 'name' => $v['nama_vendor'], 'kat' => $v['kategori']], $allVendors)) ?>;
let vendorColCount = <?= count($bidVendors) ?>;

function fmtRp(n) {
  return 'Rp ' + Math.round(n).toLocaleString('id-ID');
}

function updateVendorLabels() {
  document.querySelectorAll('.vendor-select').forEach((sel, idx) => {
    const vIdx = sel.closest('.vendor-card').dataset.vidx;
    const lbl = document.querySelector('.v-label-' + vIdx);
    if (lbl) {
      lbl.textContent = sel.options[sel.selectedIndex]?.text.split(' (')[0] || 'Pilih Vendor';
    }
  });
}

function recalcBidTotals() {
  const vTotals = {};
  const vWonTotals = {};
  const vWonCounts = {};
  let nonPoCount = 0;
  let nonPoTotal = 0;

  document.querySelectorAll('.vendor-card').forEach(c => {
    const vIdx = c.dataset.vidx;
    vTotals[vIdx] = 0;
    vWonTotals[vIdx] = 0;
    vWonCounts[vIdx] = 0;
  });

  document.querySelectorAll('.bid-item-row').forEach(row => {
    const itemId = row.dataset.itemid;
    const qty = parseFloat(row.dataset.qty || 1);
    const checked = row.querySelector(`input[name="winner[${itemId}]"]:checked`);
    const winIdx = checked ? checked.value : null;
    const jalurSel = row.querySelector('.item-jalur-sel');
    const isNonPo = jalurSel && jalurSel.value === 'NON_PO';

    if (jalurSel) {
      jalurSel.style.borderColor = isNonPo ? '#7c3aed' : '#cbd5e1';
      jalurSel.style.color = isNonPo ? '#6d28d9' : '#0f172a';
    }

    row.querySelectorAll('.quote-input').forEach(inp => {
      const vIdx = inp.dataset.vidx;
      const price = parseFloat(inp.value || 0);
      const sub = price * qty;
      const subEl = row.querySelector(`.quote-sub-${itemId}-${vIdx}`);
      if (subEl) subEl.textContent = fmtRp(sub);
      vTotals[vIdx] = (vTotals[vIdx] || 0) + sub;

      const cell = inp.closest('td');
      if (winIdx === vIdx) {
        if (isNonPo) {
          nonPoCount++;
          nonPoTotal += sub;
          cell.style.background = '#f5f3ff';
        } else {
          vWonTotals[vIdx] = (vWonTotals[vIdx] || 0) + sub;
          vWonCounts[vIdx] = (vWonCounts[vIdx] || 0) + 1;
          cell.style.background = '#ecfdf5';
        }
      } else {
        cell.style.background = '';
      }
    });
  });

  Object.keys(vTotals).forEach(vIdx => {
    const tEl = document.getElementById('vendorTotal_' + vIdx);
    const wEl = document.getElementById('vendorWonTotal_' + vIdx);
    if (tEl) tEl.textContent = fmtRp(vTotals[vIdx]);
    if (wEl) wEl.textContent = `${fmtRp(vWonTotals[vIdx])} (${vWonCounts[vIdx]} item PO)`;
  });

  const npBanner = document.getElementById('nonPoInfoBanner');
  if (npBanner) {
    if (nonPoCount > 0) {
      npBanner.style.display = 'block';
      npBanner.textContent = `Terdapat ${nonPoCount} barang jalur Non PO (total estimasi ${fmtRp(nonPoTotal)}) — barang ini tidak dibuatkan PO dan langsung diteruskan ke Form Terima Barang (FTB).`;
    } else {
      npBanner.style.display = 'none';
    }
  }
}

function pickAllForVendor(vIdx) {
  document.querySelectorAll('.bid-item-row').forEach(row => {
    const itemId = row.dataset.itemid;
    const radio = row.querySelector(`input[name="winner[${itemId}]"][value="${vIdx}"]`);
    if (radio) radio.checked = true;
  });
  recalcBidTotals();
}

function autoPickCheapest() {
  document.querySelectorAll('.bid-item-row').forEach(row => {
    const itemId = row.dataset.itemid;
    let bestIdx = null;
    let bestVal = Infinity;
    row.querySelectorAll('.quote-input').forEach(inp => {
      const val = parseFloat(inp.value || 0);
      if (val > 0 && val < bestVal) {
        bestVal = val;
        bestIdx = inp.dataset.vidx;
      }
    });
    if (bestIdx !== null) {
      const radio = row.querySelector(`input[name="winner[${itemId}]"][value="${bestIdx}"]`);
      if (radio) radio.checked = true;
    }
  });
  recalcBidTotals();
}

function addVendorColumn() {
  if (document.querySelectorAll('.vendor-card').length >= 4) {
    alert('Maksimal 4 vendor pembanding dalam 1 Bid Summary.');
    return;
  }
  const vIdx = vendorColCount++;
  const optionsHtml = allVendorsData.map(v => `<option value="${v.id}">${v.name} (${v.kat})</option>`).join('');

  const card = document.createElement('div');
  card.className = 'disp-box vendor-card';
  card.dataset.vidx = vIdx;
  card.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
      <h4 style="margin:0;">Vendor Pembanding #${vIdx + 1}</h4>
      <button type="button" onclick="removeVendorCol(${vIdx})" class="btn btn-outline btn-sm" style="color:#dc2626;">Hapus</button>
    </div>
    <div class="form-group">
      <label class="form-label">Pilih Vendor *</label>
      <select name="bv_vendor_id[${vIdx}]" class="form-control vendor-select" onchange="updateVendorLabels()">${optionsHtml}</select>
    </div>
    <div class="grid-2" style="margin-bottom:0;">
      <div><label class="form-label">Termin Pembayaran</label><input type="text" name="bv_termin[${vIdx}]" list="paymentTermsList" class="form-control" value="Credit, 30 days after receipt of the invoice and BAST / Delivery Note"></div>
      <div><label class="form-label">Estimasi Kirim</label><input type="text" name="bv_estimasi[${vIdx}]" class="form-control" value="7 Hari Kerja"></div>
    </div>
  `;
  document.getElementById('vendorCardsWrap').appendChild(card);

  // Tambahkan kolom pada header, tiap baris item, dan footer
  const theadRow = document.querySelector('#bidMatrixTable thead tr');
  const th = document.createElement('th');
  th.className = 'vcol-head';
  th.dataset.vidx = vIdx;
  th.style.cssText = 'min-width:210px;background:#f0f9ff;';
  th.innerHTML = `<div style="color:#0369a1;">Vendor #${vIdx + 1}: <span class="v-label-${vIdx}"></span></div>
    <button type="button" onclick="pickAllForVendor(${vIdx})" class="btn btn-outline btn-sm" style="margin-top:4px;font-size:10.5px;padding:3px 7px;">Pilih Semua Item</button>`;
  theadRow.appendChild(th);

  document.querySelectorAll('.bid-item-row').forEach(row => {
    const itemId = row.dataset.itemid;
    const firstInput = row.querySelector('.quote-input');
    const defVal = firstInput ? firstInput.value : 0;
    const td = document.createElement('td');
    td.className = 'vcol-cell';
    td.dataset.vidx = vIdx;
    td.innerHTML = `
      <div style="display:flex;flex-direction:column;gap:5px;">
        <input type="number" step="100" min="0" name="quote[${itemId}][${vIdx}]" value="${defVal}" class="form-control quote-input" data-vidx="${vIdx}" oninput="recalcBidTotals()">
        <div style="display:flex;align-items:center;justify-content:space-between;font-size:11.5px;">
          <span class="quote-sub-${itemId}-${vIdx}" style="font-weight:700;color:#334155;">Rp 0</span>
          <label style="display:inline-flex;align-items:center;gap:4px;font-weight:700;color:#008A3B;cursor:pointer;">
            <input type="radio" name="winner[${itemId}]" value="${vIdx}" onchange="recalcBidTotals()"> Pemenang
          </label>
        </div>
      </div>`;
    row.appendChild(td);
  });

  const tfootRows = document.querySelectorAll('#bidMatrixTable tfoot tr');
  const tdTot = document.createElement('td');
  tdTot.dataset.vidx = vIdx;
  tdTot.style.cssText = 'font-weight:800;color:#007AB3;';
  tdTot.id = 'vendorTotal_' + vIdx;
  tfootRows[0].appendChild(tdTot);

  const tdWon = document.createElement('td');
  tdWon.dataset.vidx = vIdx;
  tdWon.style.cssText = 'font-weight:800;color:#166534;';
  tdWon.id = 'vendorWonTotal_' + vIdx;
  tfootRows[1].appendChild(tdWon);

  updateVendorLabels();
  recalcBidTotals();
}

function removeVendorCol(vIdx) {
  document.querySelector(`.vendor-card[data-vidx="${vIdx}"]`)?.remove();
  document.querySelectorAll(`[data-vidx="${vIdx}"]`).forEach(el => el.remove());
  recalcBidTotals();
}

updateVendorLabels();
recalcBidTotals();
</script>
