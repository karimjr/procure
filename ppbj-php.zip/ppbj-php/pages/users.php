<?php
$canManageUsers = ($user['role'] === 'ADMIN');
if (!$canManageUsers) {
    echo '<div class="card"><div class="flash flash-error">Akses Ditolak: Pembuatan akun dan penetapan divisi pengguna hanya dikelola oleh <strong>Super Admin</strong>.</div><a href="index.php" class="btn btn-outline btn-sm">&larr; Kembali ke Dashboard</a></div>';
    return;
}

$divisions = $pdo->query("SELECT * FROM divisions WHERE aktif = 1 ORDER BY kode_divisi ASC")->fetchAll();
$divById = [];
foreach ($divisions as $d) {
    $divById[(int)$d['id']] = $d;
}

$editUserId = isset($_GET['edit']) ? (int)$_GET['edit'] : 0;
$editUser = null;
if ($editUserId > 0) {
    $stE = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stE->execute([$editUserId]);
    $editUser = $stE->fetch();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['save_user'])) {
        $uid = (int)($_POST['user_id'] ?? 0);
        $username = strtolower(trim($_POST['username'] ?? ''));
        $nama = trim($_POST['nama_lengkap'] ?? '');
        $jabatan = trim($_POST['jabatan'] ?? '');
        $roleVal = $_POST['role'] ?? 'PEMOHON';
        $validRoles = ['PEMOHON', 'MANAGER', 'DIREKTUR_OPS', 'DIREKTUR_KEUANGAN', 'PROCUREMENT', 'ADMIN'];
        if (!in_array($roleVal, $validRoles, true)) $roleVal = 'PEMOHON';
        $divId = (int)($_POST['division_id'] ?? 0);
        $password = (string)($_POST['password'] ?? '');

        if ($username === '' || $nama === '' || $jabatan === '') {
            set_flash('Username, Nama Lengkap, dan Jabatan wajib diisi.', 'error');
            redirect_to('index.php?page=users' . ($uid > 0 ? '&edit=' . $uid : ''));
        }
        if ($roleVal === 'PEMOHON' && ($divId <= 0 || !isset($divById[$divId]))) {
            set_flash('Untuk akun Pemohon, Divisi Tetap wajib dipilih agar pengajuan PPBJ terkunci di divisinya.', 'error');
            redirect_to('index.php?page=users' . ($uid > 0 ? '&edit=' . $uid : ''));
        }
        if ($uid === 0 && strlen($password) < 4) {
            set_flash('Password awal minimal 4 karakter untuk akun baru.', 'error');
            redirect_to('index.php?page=users');
        }

        $divIdDb = ($divId > 0 && isset($divById[$divId])) ? $divId : null;
        $divName = $divIdDb ? $divById[$divIdDb]['nama_divisi'] : (trim($_POST['divisi_label'] ?? '') ?: 'Manajemen / Procurement');

        try {
            if ($uid > 0) {
                if ($password !== '') {
                    $hash = password_hash($password, PASSWORD_BCRYPT);
                    $upd = $pdo->prepare(
                        "UPDATE users SET username = ?, password_hash = ?, nama_lengkap = ?, jabatan = ?, division_id = ?, divisi = ?, role = ? WHERE id = ?"
                    );
                    $upd->execute([$username, $hash, $nama, $jabatan, $divIdDb, $divName, $roleVal, $uid]);
                } else {
                    $upd = $pdo->prepare(
                        "UPDATE users SET username = ?, nama_lengkap = ?, jabatan = ?, division_id = ?, divisi = ?, role = ? WHERE id = ?"
                    );
                    $upd->execute([$username, $nama, $jabatan, $divIdDb, $divName, $roleVal, $uid]);
                }
                set_flash("Akun {$nama} ({$username}) berhasil diperbarui" . ($divIdDb ? " — Divisi: {$divById[$divIdDb]['kode_divisi']}" : '') . ".");
            } else {
                $hash = password_hash($password, PASSWORD_BCRYPT);
                $ins = $pdo->prepare(
                    "INSERT INTO users (username, password_hash, nama_lengkap, jabatan, division_id, divisi, role, aktif)
                     VALUES (?, ?, ?, ?, ?, ?, ?, 1)"
                );
                $ins->execute([$username, $hash, $nama, $jabatan, $divIdDb, $divName, $roleVal]);
                set_flash("Akun baru {$nama} (username: {$username}) berhasil dibuat" . ($divIdDb ? " untuk divisi {$divById[$divIdDb]['nama_divisi']}" : '') . ".");
            }
        } catch (Throwable $e) {
            set_flash('Gagal menyimpan akun (pastikan username belum dipakai): ' . $e->getMessage(), 'error');
        }
        redirect_to('index.php?page=users');
    } elseif (isset($_POST['toggle_user'])) {
        $uid = (int)$_POST['user_id'];
        $newState = (int)$_POST['new_state'];
        if ($uid === (int)$user['id'] && $newState === 0) {
            set_flash('Anda tidak dapat menonaktifkan akun yang sedang dipakai login.', 'error');
        } else {
            $pdo->prepare("UPDATE users SET aktif = ? WHERE id = ?")->execute([$newState, $uid]);
            set_flash('Status aktif akun berhasil diperbarui.');
        }
        redirect_to('index.php?page=users');
    }
}

$usersList = $pdo->query(
    "SELECT u.*, d.kode_divisi, d.nama_divisi,
            (SELECT COUNT(*) FROM ppbj_requests p WHERE p.user_id = u.id) AS jml_ppbj
     FROM users u
     LEFT JOIN divisions d ON u.division_id = d.id
     ORDER BY u.id ASC"
)->fetchAll();
?>

<div class="card">
  <div class="card-header">
    <div>
      <h1 class="card-title" style="font-size:18px;">Kelola Akun User &amp; Penetapan Divisi (Super Admin)</h1>
      <div style="font-size:12px;color:#64748b;">
        Hanya <strong>Super Admin</strong> yang membuat akun dan menetapkan divisi masing-masing user. Akun <strong>Pemohon</strong> hanya dapat mengajukan PPBJ di divisi yang telah ditetapkan.
      </div>
    </div>
    <a href="index.php?page=divisions" class="btn btn-outline btn-sm">Kelola Master Divisi &rarr;</a>
  </div>

  <form method="post" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;padding:16px;margin-bottom:18px;">
    <input type="hidden" name="save_user" value="1">
    <input type="hidden" name="user_id" value="<?= (int)($editUser['id'] ?? 0) ?>">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
      <div style="font-weight:700;font-size:13.5px;color:#007AB3;">
        <?= $editUser ? 'Edit Akun User: ' . h($editUser['nama_lengkap']) . ' (' . h($editUser['username']) . ')' : '+ Buat Akun User Baru' ?>
      </div>
      <?php if ($editUser): ?>
        <a href="index.php?page=users" class="btn btn-outline btn-sm">Batal Edit</a>
      <?php endif; ?>
    </div>

    <div class="grid-3" style="margin-bottom:10px;">
      <div class="form-group" style="margin-bottom:0;">
        <label style="font-size:11.5px;">Username Login *</label>
        <input type="text" name="username" class="form-control" required placeholder="Contoh: desrika" value="<?= h($editUser['username'] ?? '') ?>">
      </div>
      <div class="form-group" style="margin-bottom:0;">
        <label style="font-size:11.5px;">Nama Lengkap *</label>
        <input type="text" name="nama_lengkap" class="form-control" required placeholder="Contoh: Desrika" value="<?= h($editUser['nama_lengkap'] ?? '') ?>">
      </div>
      <div class="form-group" style="margin-bottom:0;">
        <label style="font-size:11.5px;">Jabatan *</label>
        <input type="text" name="jabatan" class="form-control" required placeholder="Contoh: Staff Workshop & Mekanik" value="<?= h($editUser['jabatan'] ?? '') ?>">
      </div>
    </div>

    <div class="grid-3" style="margin-bottom:12px;">
      <div class="form-group" style="margin-bottom:0;">
        <label style="font-size:11.5px;">Role / Peran *</label>
        <select name="role" class="form-control" required>
          <?php $curRole = $editUser['role'] ?? 'PEMOHON'; ?>
          <option value="PEMOHON" <?= $curRole === 'PEMOHON' ? 'selected' : '' ?>>User / Pemohon (Divisi Terkunci)</option>
          <option value="MANAGER" <?= $curRole === 'MANAGER' ? 'selected' : '' ?>>Atasan / Manager</option>
          <option value="DIREKTUR_OPS" <?= $curRole === 'DIREKTUR_OPS' ? 'selected' : '' ?>>Direktur Operasional</option>
          <option value="DIREKTUR_KEUANGAN" <?= $curRole === 'DIREKTUR_KEUANGAN' ? 'selected' : '' ?>>Direktur Keuangan</option>
          <option value="PROCUREMENT" <?= $curRole === 'PROCUREMENT' ? 'selected' : '' ?>>Procurement &amp; Gudang</option>
          <option value="ADMIN" <?= $curRole === 'ADMIN' ? 'selected' : '' ?>>Super Admin</option>
        </select>
      </div>
      <div class="form-group" style="margin-bottom:0;">
        <label style="font-size:11.5px;">Divisi Tetap (Wajib untuk Pemohon)</label>
        <select name="division_id" class="form-control">
          <option value="0">-- Lintas Divisi / Non-Divisi Spesifik --</option>
          <?php $curDivId = (int)($editUser['division_id'] ?? 0); ?>
          <?php foreach ($divisions as $d): ?>
            <option value="<?= (int)$d['id'] ?>" <?= $curDivId === (int)$d['id'] ? 'selected' : '' ?>>
              <?= h($d['kode_divisi']) ?> — <?= h($d['nama_divisi']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group" style="margin-bottom:0;">
        <label style="font-size:11.5px;"><?= $editUser ? 'Password Baru (Kosongkan jika tidak ganti)' : 'Password Awal *' ?></label>
        <input type="password" name="password" class="form-control" <?= $editUser ? '' : 'required' ?> placeholder="<?= $editUser ? 'Isi hanya jika reset password' : 'Minimal 4 karakter (mis. 123456)' ?>">
      </div>
    </div>

    <button type="submit" class="btn btn-primary btn-sm">
      <?= $editUser ? 'Simpan Perubahan Akun' : 'Buat Akun User' ?>
    </button>
  </form>

  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th>ID</th>
          <th>Username</th>
          <th>Nama &amp; Jabatan</th>
          <th>Role</th>
          <th>Divisi Tetap (PPBJ)</th>
          <th>Total PPBJ</th>
          <th>Status</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($usersList as $u): ?>
          <tr>
            <td><?= (int)$u['id'] ?></td>
            <td><code><?= h($u['username']) ?></code></td>
            <td>
              <strong><?= h($u['nama_lengkap']) ?></strong>
              <div style="font-size:11.5px;color:#64748b;"><?= h($u['jabatan']) ?></div>
            </td>
            <td><span class="badge badge-blue"><?= h(role_label($u['role'])) ?></span></td>
            <td>
              <?php if (!empty($u['kode_divisi'])): ?>
                <span class="badge badge-sky"><?= h($u['kode_divisi']) ?></span>
                <div style="font-size:11.5px;color:#334155;margin-top:2px;"><?= h($u['nama_divisi']) ?></div>
              <?php else: ?>
                <span style="font-size:12px;color:#64748b;"><?= h($u['divisi']) ?> (Lintas Divisi)</span>
              <?php endif; ?>
            </td>
            <td style="text-align:center;font-weight:700;"><?= (int)$u['jml_ppbj'] ?></td>
            <td>
              <?php if ($u['aktif']): ?>
                <span class="badge badge-green">Aktif</span>
              <?php else: ?>
                <span class="badge badge-slate">Nonaktif</span>
              <?php endif; ?>
            </td>
            <td style="white-space:nowrap;">
              <a href="index.php?page=users&edit=<?= (int)$u['id'] ?>" class="btn btn-outline btn-sm">Edit / Pindah Divisi</a>
              <form method="post" style="display:inline;">
                <input type="hidden" name="toggle_user" value="1">
                <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
                <input type="hidden" name="new_state" value="<?= $u['aktif'] ? 0 : 1 ?>">
                <button type="submit" class="btn btn-outline btn-sm">
                  <?= $u['aktif'] ? 'Nonaktifkan' : 'Aktifkan' ?>
                </button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
