<?php
if ($user['role'] === 'PEMOHON') {
    die('Akses Ditolak.');
}

$filters = [
    'date_from' => trim($_GET['date_from'] ?? ''),
    'date_to' => trim($_GET['date_to'] ?? ''),
    'divisi' => trim($_GET['divisi'] ?? ''),
    'target_saving_pct' => $_GET['target_saving_pct'] ?? 5,
    'target_otd_pct' => $_GET['target_otd_pct'] ?? 95,
    'target_acc_pct' => $_GET['target_acc_pct'] ?? 98,
    'target_sla_days' => $_GET['target_sla_days'] ?? 7,
    'gov_threshold' => $_GET['gov_threshold'] ?? 10000000,
];

$rep = build_procurement_report_data($pdo, $filters);
$f = $rep['filters'];
$logoData = logo_src();

$totalCatSpent = array_sum(array_column($rep['catStats'], 'spent'));
$totalCatBudget = array_sum(array_column($rep['catStats'], 'budget'));
$totalCatSaving = array_sum(array_column($rep['catStats'], 'saving'));
$totalCatTargetSavingIdr = $totalCatBudget * ($f['target_saving_pct'] / 100);
$totalCatSavingPct = $totalCatBudget > 0 ? ($totalCatSaving / $totalCatBudget) * 100 : 0;

$totalPayQty = array_sum(array_column($rep['payTerms'], 'qty'));
$totalPayVal = array_sum(array_column($rep['payTerms'], 'value'));
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Laporan &amp; KPI Procurement - PT. Potensi Bumi Sakti</title>
<style>
  @page { size: A4 landscape; margin: 10mm; }
  * { box-sizing: border-box; }
  body { font-family: Arial, Helvetica, sans-serif; color: #111; font-size: 9.5px; margin: 0; padding: 14px; background: #f1f5f9; }
  .toolbar { max-width: 1180px; margin: 0 auto 10px; display: flex; justify-content: space-between; align-items: center; }
  .btn { padding: 7px 14px; border-radius: 6px; border: 1px solid #cbd5e1; background: #fff; font-weight: 700; font-size: 12px; cursor: pointer; text-decoration: none; color: #0f172a; }
  .btn-print { background: #16365C; color: #fff; border-color: #16365C; }
  .sheet { max-width: 1180px; margin: 0 auto; background: #fff; padding: 14px; border: 1px solid #cbd5e1; }
  table.hdr { width: 100%; border-collapse: collapse; margin-bottom: 10px; }
  table.hdr td { border: 1px solid #000; padding: 4px 8px; }
  h3 { margin: 12px 0 5px; font-size: 11px; color: #16365C; }
  table.kpi { width: 100%; border-collapse: collapse; margin-bottom: 8px; }
  table.kpi th, table.kpi td { border: 1px solid #334155; padding: 3.5px 6px; vertical-align: middle; }
  table.kpi thead th { background: #16365C; color: #fff; text-align: center; font-weight: 700; }
  .num { text-align: right; white-space: nowrap; }
  .ctr { text-align: center; white-space: nowrap; }
  .hl { background: #eff6ff; font-weight: 700; }
  @media print {
    body { background: #fff; padding: 0; }
    .toolbar { display: none; }
    .sheet { border: none; padding: 0; max-width: none; }
  }
</style>
</head>
<body>
<div class="toolbar">
  <a href="index.php?page=procurement_report" class="btn">&larr; Kembali ke Laporan Procurement</a>
  <button onclick="window.print()" class="btn btn-print">Cetak / Simpan PDF</button>
</div>
<div class="sheet">
  <table class="hdr">
    <tr>
      <td rowspan="2" style="width:15%;text-align:center;">
        <?php if ($logoData): ?><img src="<?= h($logoData) ?>" alt="PBS" style="max-height:44px;"><?php endif; ?>
      </td>
      <td style="text-align:center;font-weight:700;font-size:13px;">PT. POTENSI BUMI SAKTI — PROCUREMENT KPI &amp; PERFORMANCE REPORT</td>
      <td style="width:12%;font-weight:700;">Tanggal Cetak</td>
      <td style="width:14%;"><?= h(tgl_indo(date('Y-m-d'))) ?></td>
    </tr>
    <tr>
      <td style="text-align:center;font-size:10px;">
        Periode: <?= h($f['date_from'] ?: 'Semua') ?> s/d <?= h($f['date_to'] ?: 'Sekarang') ?>
        | Divisi: <?= h($f['divisi'] ?: 'Semua') ?>
      </td>
      <td style="font-weight:700;">Dicetak Oleh</td>
      <td><?= h($user['nama_lengkap']) ?></td>
    </tr>
  </table>

  <h3>1. Key Highlight — Cost Saving &amp; KPI Pengadaan</h3>
  <table class="kpi">
    <thead>
      <tr>
        <th rowspan="2" style="width:28px;">No</th>
        <th rowspan="2">Key highlight</th>
        <th rowspan="2">Total spent</th>
        <th rowspan="2">Target</th>
        <th colspan="2">Achievement</th>
        <th rowspan="2">Note</th>
      </tr>
      <tr><th>in IDR</th><th>in %</th></tr>
    </thead>
    <tbody>
      <tr class="hl">
        <td class="ctr">1</td><td>Saving cost by Category :</td>
        <td class="num"><?= rupiah($totalCatSpent) ?></td>
        <td class="num"><?= rupiah($totalCatTargetSavingIdr) ?></td>
        <td class="num"><?= rupiah($totalCatSaving) ?></td>
        <td class="ctr"><?= number_format($totalCatSavingPct, 2, ',', '.') ?>%</td>
        <td>Budget <?= rupiah($totalCatBudget) ?> vs Realisasi PO</td>
      </tr>
      <?php foreach ($rep['catStats'] as $catName => $cs):
        $cTarget = $cs['budget'] * ($f['target_saving_pct'] / 100);
        $cPct = $cs['budget'] > 0 ? ($cs['saving'] / $cs['budget']) * 100 : 0;
      ?>
      <tr>
        <td></td><td style="padding-left:14px;"><?= h($catName) ?></td>
        <td class="num"><?= $cs['spent'] > 0 ? rupiah($cs['spent']) : '' ?></td>
        <td class="num"><?= $cs['budget'] > 0 ? rupiah($cTarget) : '' ?></td>
        <td class="num"><?= $cs['items'] > 0 ? rupiah($cs['saving']) : '' ?></td>
        <td class="ctr"><?= $cs['budget'] > 0 ? number_format($cPct, 2, ',', '.') . '%' : '' ?></td>
        <td><?= $cs['items'] > 0 ? $cs['items'] . ' item' : '' ?></td>
      </tr>
      <?php endforeach; ?>
      <tr class="hl">
        <td class="ctr">2</td><td>Cost Avoidance</td>
        <td class="num"><?= rupiah($rep['costAvoidance']['spent']) ?></td>
        <td class="num"><?= rupiah($rep['costAvoidance']['target']) ?></td>
        <td class="num"><?= rupiah($rep['costAvoidance']['idr']) ?></td>
        <td class="ctr"><?= number_format($rep['costAvoidance']['pct'], 2, ',', '.') ?>%</td>
        <td>Penawaran tertinggi Bid minus pemenang</td>
      </tr>
      <tr>
        <td class="ctr">3</td><td><strong>On-Time Delivery (OTD) Rate</strong></td>
        <td class="ctr"><?= (int)$rep['otd']['ontime'] ?> / <?= (int)$rep['otd']['received'] ?> PO</td>
        <td class="ctr"><?= number_format($rep['otd']['target_pct'], 0) ?>%</td>
        <td class="ctr"><?= (int)$rep['otd']['ontime'] ?> PO</td>
        <td class="ctr"><strong><?= number_format($rep['otd']['pct'], 1, ',', '.') ?>%</strong></td>
        <td>FTB &le; Estimasi Tiba</td>
      </tr>
      <tr>
        <td class="ctr">4</td><td><strong>Order Fulfillment Accuracy (Order Accuracy Rate)</strong></td>
        <td class="ctr"><?= rtrim(rtrim((string)$rep['accuracy']['recv_qty'], '0'), '.') ?: '0' ?> / <?= rtrim(rtrim((string)$rep['accuracy']['order_qty'], '0'), '.') ?: '0' ?></td>
        <td class="ctr"><?= number_format($rep['accuracy']['target_pct'], 0) ?>%</td>
        <td class="ctr"><?= rtrim(rtrim((string)$rep['accuracy']['recv_qty'], '0'), '.') ?: '0' ?> unit</td>
        <td class="ctr"><strong><?= number_format($rep['accuracy']['pct'], 1, ',', '.') ?>%</strong></td>
        <td>Mengukur persentase pesanan yang diterima dengan benar dibandingkan total order yang dirilis.</td>
      </tr>
      <tr>
        <td class="ctr">5</td><td><strong>SLA Lead Time Pengadaan (PR to PO)</strong></td>
        <td class="ctr"><?= number_format($rep['sla']['avg_days'], 1, ',', '.') ?> hari</td>
        <td class="ctr">&le; <?= (int)$rep['sla']['target_days'] ?> hari</td>
        <td class="ctr"><?= (int)$rep['sla']['met_count'] ?> / <?= (int)$rep['sla']['total_po'] ?> PO</td>
        <td class="ctr"><strong><?= number_format($rep['sla']['pct'], 1, ',', '.') ?>%</strong></td>
        <td>PPBJ ke Terbit PO</td>
      </tr>
    </tbody>
  </table>

  <h3>2. Top 10 The Biggest Transaction</h3>
  <table class="kpi">
    <thead>
      <tr><th>No</th><th>Vendor name</th><th>Detail items</th><th>Value in IDR</th><th>% From Total Spent</th><th>Saving Cost</th><th>% From Total Saving</th></tr>
    </thead>
    <tbody>
      <?php for ($i = 0; $i < 10; $i++):
        $row = $rep['top10'][$i] ?? null;
        $pctSpent = ($row && $rep['totalAllPoSpent'] > 0) ? ((float)$row['total_po'] / $rep['totalAllPoSpent']) * 100 : 0;
        $pctSav = ($row && $rep['totalAllSaving'] != 0) ? ((float)$row['saving_idr'] / $rep['totalAllSaving']) * 100 : 0;
      ?>
      <tr>
        <td class="ctr"><?= $i + 1 ?></td>
        <td><?= $row ? h($row['vendor_name']) : '' ?></td>
        <td><?= $row ? h($row['detail_items'] ?: '') : '' ?></td>
        <td class="num"><?= $row ? rupiah($row['total_po']) : '' ?></td>
        <td class="ctr"><?= $row ? number_format($pctSpent, 2, ',', '.') . '%' : '' ?></td>
        <td class="num"><?= $row ? rupiah($row['saving_idr']) : '' ?></td>
        <td class="ctr"><?= ($row && $rep['totalAllSaving'] != 0) ? number_format($pctSav, 2, ',', '.') . '%' : '' ?></td>
      </tr>
      <?php endfor; ?>
    </tbody>
  </table>

  <h3>3. PAYMENT TERM</h3>
  <table class="kpi">
    <thead>
      <tr><th rowspan="2">No</th><th rowspan="2">Payment term</th><th colspan="2">Number of order</th><th colspan="2">Total Value</th></tr>
      <tr><th>Qty</th><th>in %</th><th>in IDR</th><th>in %</th></tr>
    </thead>
    <tbody>
      <?php $ptNo = 1; foreach ($rep['payTerms'] as $pt):
        $qtyPct = $totalPayQty > 0 ? ($pt['qty'] / $totalPayQty) * 100 : 0;
        $valPct = $totalPayVal > 0 ? ($pt['value'] / $totalPayVal) * 100 : 0;
      ?>
      <tr>
        <td class="ctr"><?= $pt['label'] === 'etc' ? '' : $ptNo++ ?></td>
        <td><?= h($pt['label']) ?></td>
        <td class="ctr"><?= (int)$pt['qty'] ?></td>
        <td class="ctr"><?= number_format($qtyPct, 1, ',', '.') ?>%</td>
        <td class="num"><?= rupiah($pt['value']) ?></td>
        <td class="ctr"><?= number_format($valPct, 1, ',', '.') ?>%</td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <h3>4. ORDER TRACKING</h3>
  <table class="kpi">
    <thead>
      <tr><th>No</th><th>PO / WO number</th><th>Vendor name</th><th>Detail Items/Services</th><th>Order Qty</th><th>Total Value</th><th>Received Qty</th><th>Reject Qty</th></tr>
    </thead>
    <tbody>
      <?php foreach ($rep['orderTracking'] as $idx => $ot): ?>
      <tr>
        <td class="ctr"><?= $idx + 1 ?></td>
        <td><?= h($ot['po_no']) ?></td>
        <td><?= h($ot['vendor_name']) ?></td>
        <td><?= h($ot['detail_items'] ?: '-') ?></td>
        <td class="ctr"><?= rtrim(rtrim((string)$ot['order_qty'], '0'), '.') ?></td>
        <td class="num"><?= rupiah($ot['total_po']) ?></td>
        <td class="ctr"><?= rtrim(rtrim((string)$ot['received_qty'], '0'), '.') ?: '0' ?></td>
        <td class="ctr"><?= rtrim(rtrim((string)$ot['reject_qty'], '0'), '.') ?: '0' ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <h3>5. Vendor Performance &amp; Compliance Highlights</h3>
  <table class="kpi">
    <tr><td><strong>Top Performing Vendors:</strong> <?= !empty($rep['topVendors']) ? h(implode('; ', array_map(fn($v) => $v['vendor_name'] . ' (Skor SLA ' . number_format($v['sla_score'], 1, ',', '.') . '%, 0 reject)', $rep['topVendors']))) : 'Belum ada data FTB selesai.' ?></td></tr>
    <tr><td><strong>Vendor Under Watch (Dalam Pengawasan):</strong> <?= !empty($rep['watchVendors']) ? h(implode('; ', array_map(fn($v) => $v['vendor_name'] . ' - ' . $v['watch_reason'], $rep['watchVendors']))) : 'Tidak ada vendor dalam pengawasan.' ?></td></tr>
    <tr><td><strong>Kepatuhan &amp; Tata Kelola (Governance):</strong> <?= number_format($rep['governance']['pct'], 1, ',', '.') ?>% transaksi di atas <?= rupiah($rep['governance']['threshold']) ?> (<?= (int)$rep['governance']['compliant'] ?> dari <?= (int)$rep['governance']['eligible'] ?> PO) telah melalui proses komparasi minimal 3 penawaran.</td></tr>
  </table>
</div>
</body>
</html>
