<?php
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare(
    "SELECT po.*, p.request_no, p.division_code, p.division_subdivision, b.bid_no,
            v.pic AS vendor_pic, v.telepon AS vendor_tel, v.email AS vendor_email, v.alamat AS vendor_alamat, v.kota AS vendor_kota
     FROM purchase_orders po
     JOIN ppbj_requests p ON po.ppbj_id = p.id
     LEFT JOIN bid_summaries b ON po.bid_id = b.id
     LEFT JOIN vendors v ON po.vendor_id = v.id
     WHERE po.id = ?"
);
$stmt->execute([$id]);
$po = $stmt->fetch();
if (!$po) { die('Data PO tidak ditemukan.'); }

$itSt = $pdo->prepare("SELECT * FROM po_items WHERE po_id = ? ORDER BY item_no ASC");
$itSt->execute([$id]);
$items = $itSt->fetchAll();

$logo = logo_src();
$orderTitle = $po['order_type'] ?: 'PURCHASE ORDER';
$sellerAddr = $po['seller_address'] && $po['seller_address'] !== '-'
    ? $po['seller_address']
    : trim(($po['vendor_alamat'] ?? '') . (!empty($po['vendor_kota']) ? ', ' . $po['vendor_kota'] : ''), ', ');
$sellerContact = $po['seller_contact'] && $po['seller_contact'] !== '-'
    ? $po['seller_contact']
    : trim(($po['vendor_pic'] ?? '-') . (!empty($po['vendor_tel']) ? ' (' . $po['vendor_tel'] . ')' : ''));
$sellerEmail = $po['seller_email'] && $po['seller_email'] !== '-'
    ? $po['seller_email']
    : ($po['vendor_email'] ?? '');

$subTotal = (float)$po['subtotal_po'] > 0 ? (float)$po['subtotal_po'] : array_sum(array_column($items, 'subtotal'));
$deliveryFee = (float)($po['delivery_fee'] ?? 0);
$discountAmt = (float)($po['discount_amount'] ?? 0);
$vatPct = (float)($po['vat_percent'] ?? 0);
$vatAmt = (float)($po['vat_amount'] ?? 0);
$whtPct = (float)($po['withholding_tax_pct'] ?? 0);
$whtLabel = trim((string)($po['withholding_tax_label'] ?? ''));
$whtAmt = $whtPct > 0 ? round($subTotal * ($whtPct / 100), 2) : 0;
$isPphProgresif = (stripos($whtLabel, 'Progresif') !== false || stripos($whtLabel, 'PPh 21') !== false) && $whtPct <= 0;
$grandTotal = (float)$po['total_po'];
$purchaseRef = $po['purchase_reference'] ?: $po['request_no'];
$divDept = $po['division_dept'] ?: ($po['division_code'] ?: $po['division_subdivision']);
$pbsSigner = $po['pbs_signer_name'] ?: $po['dibuat_oleh'];

function tgl_po_long(?string $dateStr): string {
    if (!$dateStr) return '-';
    $ts = strtotime($dateStr);
    if ($ts === false) return h($dateStr);
    $bulan = [
        1 => 'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'
    ];
    return date('d', $ts) . ' ' . ($bulan[(int)date('n', $ts)] ?? date('m', $ts)) . ' ' . date('Y', $ts);
}
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <title><?= h($orderTitle) ?> <?= h($po['po_no']) ?></title>
  <style>
    * { box-sizing: border-box; }
    body { font-family: Arial, Helvetica, sans-serif; color: #000; margin: 18px; font-size: 11px; line-height: 1.32; background: #f8fafc; }
    .toolbar { max-width: 800px; margin: 0 auto 14px auto; display: flex; gap: 8px; }
    .btn { padding: 8px 14px; border-radius: 6px; border: 1px solid #cbd5e1; background: #fff; cursor: pointer; font-weight: 700; text-decoration: none; color: #111; font-size: 12px; }
    .btn-blue { background: #009ADE; color: #fff; border-color: #009ADE; }

    /* Bingkai luar persis PO1.pdf */
    .po-frame { max-width: 800px; margin: 0 auto; background: #fff; border: 2px solid #000; }

    /* Kop Logo + PT POTENSI BUMI SAKTI */
    .po-header { display: flex; align-items: center; gap: 18px; padding: 6px 14px; border-bottom: 2px solid #000; }
    .po-header img { height: 56px; width: auto; object-fit: contain; }
    .po-company { font-family: Georgia, "Times New Roman", serif; font-size: 18px; font-weight: 700; letter-spacing: 0.4px; color: #111; }

    /* Judul PURCHASE ORDER */
    .po-title { text-align: center; font-size: 16px; font-weight: 800; letter-spacing: 0.5px; padding: 6px 0 4px 0; }
    .po-meta-bar { display: flex; justify-content: space-between; padding: 2px 6px 5px 4px; font-size: 11px; border-bottom: 1.5px solid #000; }

    /* Grid Seller & Consignee persis PO1.pdf */
    .party-table { width: 100%; border-collapse: collapse; table-layout: fixed; }
    .party-table td { vertical-align: top; padding: 3px 6px; font-size: 10.5px; }
    .party-left { width: 50%; border-right: 1.5px solid #000; }
    .party-right { width: 50%; }
    .bt { border-top: 1px solid #000; }
    .bb { border-bottom: 1px solid #000; }
    .kv { display: flex; }
    .kv-lbl { width: 112px; flex-shrink: 0; }
    .kv-val { flex: 1; }

    /* Tabel Item persis PO1.pdf (garis vertikal antar kolom tanpa garis horizontal antar baris item) */
    .items-table { width: 100%; border-collapse: collapse; border-top: 1.5px solid #000; }
    .items-table th { border-bottom: 1.5px solid #000; border-right: 1px solid #000; padding: 4px 6px; text-align: center; font-weight: 700; font-size: 10.5px; }
    .items-table th:last-child { border-right: none; }
    .items-table td { border-right: 1px solid #000; padding: 2.5px 6px; font-size: 10.5px; vertical-align: top; }
    .items-table td:last-child { border-right: none; }
    .items-table tr.spacer-row td { height: 14px; }
    .items-table tr.sum-row td { border-top: none; border-bottom: none; padding: 2px 6px; }
    .items-table tr.grand-row td { border-top: 1px solid #000; border-bottom: 1px solid #000; font-weight: 800; font-size: 12px; padding: 3px 6px; }
    .items-table tr.wht-row td { border-bottom: 1.5px solid #000; padding: 2px 6px; font-style: italic; font-size: 10px; }

    .c { text-align: center; }
    .r { text-align: right; white-space: nowrap; }

    /* Referensi, Note, CATATAN, Tanda tangan */
    .ref-block { padding: 4px 6px 6px 6px; font-size: 10.5px; }
    .note-strip { border-top: 1.5px solid #000; border-bottom: 1.5px solid #000; padding: 3px 6px; font-size: 9.5px; }
    .catatan-strip { border-bottom: 1.5px solid #000; padding: 4px 6px 6px 6px; font-size: 9.5px; line-height: 1.38; }
    .catatan-strip .c-item { font-style: italic; }

    .sig-area { display: flex; justify-content: space-between; padding: 14px 42px 14px 42px; font-size: 10.5px; }
    .sig-col { width: 44%; }
    .sig-space { height: 56px; }

    @media print {
      .toolbar { display: none; }
      body { margin: 0; background: #fff; }
      .po-frame { max-width: 100%; }
    }
  </style>
</head>
<body>
<div class="toolbar">
  <button onclick="window.print()" class="btn btn-blue">Cetak <?= h($orderTitle) ?> / Simpan PDF</button>
  <?php if (in_array($user['role'] ?? '', ['PROCUREMENT', 'ADMIN'], true)): ?>
    <a href="index.php?page=po_form&id=<?= (int)$po['id'] ?>" class="btn">Edit PO Ini</a>
  <?php endif; ?>
  <a href="index.php?page=po_list" class="btn">&larr; Kembali ke Daftar PO</a>
</div>

<div class="po-frame">
  <!-- Header Logo + PT POTENSI BUMI SAKTI -->
  <div class="po-header">
    <img src="<?= h($logo) ?>" alt="Logo PBS">
    <div class="po-company">PT POTENSI BUMI SAKTI</div>
  </div>

  <!-- Title & Order No / Date -->
  <div class="po-title"><?= h($orderTitle) ?></div>
  <div class="po-meta-bar">
    <div><strong>PBS Order No: <?= h($po['po_no']) ?></strong></div>
    <div>Date : <?= h(tgl_po_long($po['po_date'])) ?></div>
  </div>

  <!-- Grid Seller & Consignee / Delivery Address -->
  <table class="party-table">
    <tr>
      <td class="party-left bb" style="padding-bottom:6px;">
        <div>Seller :</div>
        <div style="font-weight:700;"><?= h($po['vendor_name']) ?></div>
        <div style="min-height:36px;"><?= h($sellerAddr ?: '-') ?></div>
        <div class="kv"><span class="kv-lbl">Contact person</span><span class="kv-val">: <?= h($sellerContact ?: '-') ?></span></div>
        <div class="kv"><span class="kv-lbl">Email</span><span class="kv-val">: <?= h($sellerEmail !== '-' ? $sellerEmail : '') ?></span></div>
      </td>
      <td class="party-right bb" style="padding-bottom:6px;">
        <div>Consignee :</div>
        <div style="font-weight:700;">PT. POTENSI BUMI SAKTI</div>
        <div>Sahid Sudirman Center 50th Floor Jl. Jend. Sudirman Kav 86,</div>
        <div>Kel. Karet Tengsin Kec. Tanah Abang, Jakarta Pusat 10220</div>
        <div>Phone no. &nbsp;: +62 21 5790 5519 / 5790 5520</div>
        <div>NPWP &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: 02.398.925.4-022.000</div>
      </td>
    </tr>
    <tr>
      <td class="party-left bb">
        <div class="kv"><span class="kv-lbl">Terms of Payment</span><span class="kv-val">: <?= h($po['termin_pembayaran'] ?: '-') ?></span></div>
      </td>
      <td class="party-right bb" rowspan="3">
        <div>Delivery address :</div>
        <div style="font-weight:700;">PT. POTENSI BUMI SAKTI</div>
        <div style="min-height:30px;"><?= h($po['delivery_location']) ?></div>
        <div style="margin-top:6px;">Contact Person : <?= h($po['delivery_contact'] ?: 'T Safril Nizam TM  (082213151408)') ?></div>
      </td>
    </tr>
    <tr>
      <td class="party-left bb">
        <div class="kv"><span class="kv-lbl">Terms of Delivery</span><span class="kv-val">: <?= h($po['terms_of_delivery'] ?: 'Franco PBS Site') ?></span></div>
      </td>
    </tr>
    <tr>
      <td class="party-left bb">
        <div class="kv"><span class="kv-lbl">Lead time delivery</span><span class="kv-val">: <?= h($po['lead_time_delivery'] ?: '-') ?></span></div>
      </td>
    </tr>
    <tr>
      <td class="party-left" style="padding-top:4px;padding-bottom:4px;">
        <div>Quotation reference: <?= h($po['quotation_ref'] !== '-' ? $po['quotation_ref'] : '') ?></div>
      </td>
      <td class="party-right"></td>
    </tr>
  </table>

  <!-- Tabel Item + Sub Total / Discount / VAT 11% / Grand Total / Withholding Tax -->
  <table class="items-table">
    <thead>
      <tr>
        <th style="width:34px;">No</th>
        <th>Description</th>
        <th style="width:52px;">Qty</th>
        <th style="width:58px;">Unit</th>
        <th style="width:105px;">Price<br><span style="font-weight:400;font-size:9.5px;">( in Rp / <del>US$</del> )</span></th>
        <th style="width:112px;">Amount<br><span style="font-weight:400;font-size:9.5px;">( in Rp / <del>US$</del> )</span></th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($items as $it): ?>
        <tr>
          <td class="c"><?= (int)$it['item_no'] ?></td>
          <td><?= h($it['nama_barang_jasa']) ?></td>
          <td class="c"><?= rtrim(rtrim((string)$it['qty'], '0'), '.') ?></td>
          <td class="c"><?= h($it['satuan']) ?></td>
          <td class="r"><?= number_format((float)$it['harga_satuan'], 0, ',', '.') ?></td>
          <td class="r"><?= number_format((float)$it['subtotal'], 0, ',', '.') ?></td>
        </tr>
      <?php endforeach; ?>
      <tr class="spacer-row">
        <td></td><td></td><td></td><td></td><td></td><td></td>
      </tr>
      <tr class="sum-row">
        <td></td>
        <td class="r">Sub Total</td>
        <td></td><td></td><td></td>
        <td class="r"><?= number_format($subTotal, 0, ',', '.') ?></td>
      </tr>
      <?php if ($deliveryFee > 0): ?>
      <tr class="sum-row">
        <td></td>
        <td class="r">Delivery Fee</td>
        <td></td><td></td><td></td>
        <td class="r"><?= number_format($deliveryFee, 0, ',', '.') ?></td>
      </tr>
      <?php endif; ?>
      <tr class="sum-row">
        <td></td>
        <td class="r">Discount</td>
        <td></td><td></td><td></td>
        <td class="r"><?= $discountAmt > 0 ? number_format($discountAmt, 0, ',', '.') : '0' ?></td>
      </tr>
      <tr class="sum-row">
        <td></td>
        <td class="r">VAT <?= $vatPct > 0 ? rtrim(rtrim((string)$vatPct, '0'), '.') . '%' : '11%' ?></td>
        <td></td><td></td><td></td>
        <td class="r"><?= $vatAmt > 0 ? number_format($vatAmt, 0, ',', '.') : '0' ?></td>
      </tr>
      <tr class="grand-row">
        <td colspan="5" class="r" style="border-right:1px solid #000;">Grand Total</td>
        <td class="r"><?= number_format($grandTotal, 0, ',', '.') ?></td>
      </tr>
      <tr class="wht-row">
        <td></td>
        <td class="r">
          Estimated Withholding Tax<?= $whtLabel !== '' ? ' (' . h($whtLabel) . ')' : '' ?>
        </td>
        <td></td>
        <td class="c"><?= $isPphProgresif ? 'Progresif' : ($whtPct > 0 ? str_replace('.', ',', rtrim(rtrim((string)$whtPct, '0'), '.')) . '%' : '%') ?></td>
        <td></td>
        <td class="r"><?= $whtAmt > 0 ? number_format($whtAmt, 0, ',', '.') : '' ?></td>
      </tr>
    </tbody>
  </table>

  <!-- Purchase reference & Division/Department -->
  <div class="ref-block">
    <div>Purchase reference: <?= h($purchaseRef) ?></div>
    <div style="margin-top:10px;">Division/Department : <?= h($divDept) ?></div>
  </div>

  <!-- Note & CATATAN -->
  <div class="note-strip">
    Note: &nbsp;Goods to be delivered / presented in good condition and are in accordance with the above specification, approved sample and terms &amp; conditions herein.
  </div>
  <div class="catatan-strip">
    <div style="font-weight:700;">CATATAN:</div>
    <div class="c-item">- PT. Potensi Bumi Sakti is committed to good governance and enviromental protection by prioritizing Business Partners and Customers' satisfactions,<br>&nbsp;&nbsp;abide by all local rules and regulations, as following all company policies.</div>
    <div class="c-item">- Information about products and complaints from Business Partners and Customers can be obtained and submitted via our Email:</div>
    <div class="c-item">- Each complaint will be followed up by the Reporting/Complaint Recipient Team professionally and porportionately.</div>
    <div class="c-item">- PT. Potensi Bumi Sakti will guarantee the confidentiality of the Reporting Party.</div>
  </div>

  <!-- Signature Area persis PO1.pdf -->
  <div class="sig-area">
    <div class="sig-col">
      <div style="font-weight:700;padding-left:20px;">PT. POTENSI BUMI SAKTI</div>
      <div class="sig-space"></div>
      <div>Name : <?= h($pbsSigner) ?></div>
      <div>Date &nbsp;&nbsp;: <?= h(tgl_po_long($po['po_date'])) ?></div>
    </div>
    <div class="sig-col">
      <div style="font-weight:700;">Approved and accepted by:</div>
      <div style="font-weight:700;"><?= h($po['vendor_name']) ?></div>
      <div class="sig-space" style="height:44px;"></div>
      <div>Name &nbsp;&nbsp;&nbsp;&nbsp;:</div>
      <div>Position :</div>
      <div>Date &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</div>
    </div>
  </div>
</div>
</body>
</html>
