<?php
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("SELECT * FROM ppbj_requests WHERE id = ?");
$stmt->execute([$id]);
$pr = $stmt->fetch();

if (!$pr) {
    echo '<div class="card"><p>Data PPBJ tidak ditemukan.</p><a href="index.php?page=ppbj_list" class="btn btn-outline btn-sm">Kembali</a></div>';
    return;
}

$role = $user['role'];

if ($role === 'PEMOHON' && (int)$pr['user_id'] !== (int)$user['id']) {
    echo '<div class="card"><div class="flash flash-error">Anda hanya dapat melihat detail PPBJ yang Anda ajukan sendiri.</div><a href="index.php?page=ppbj_list" class="btn btn-outline btn-sm">&larr; Kembali ke PPBJ Saya</a></div>';
    return;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['workflow_action'])) {
    $act = $_POST['workflow_action'];
    $note = trim($_POST['note'] ?? '');
    $actor = $user['nama_lengkap'];
    $today = date('Y-m-d');

    try {
        if ($act === 'SUBMIT_DRAFT' && in_array($pr['status'], ['DRAFT', 'REVISI'], true) && in_array($role, ['PEMOHON', 'ADMIN'], true)) {
            $pdo->prepare("UPDATE ppbj_requests SET status = 'MENUNGGU_MANAGER', applied_by_date = ? WHERE id = ?")
                ->execute([$today, $id]);
            $pdo->prepare("INSERT INTO ppbj_logs (ppbj_id, actor_name, actor_role, aksi, catatan) VALUES (?, ?, ?, ?, ?)")
                ->execute([$id, $actor, role_label($role), 'Mengajukan PPBJ ke Manager', $note ?: 'Diajukan untuk persetujuan Atasan / Manager.']);
            set_flash('PPBJ berhasil diajukan ke Atasan / Manager.');
        } elseif ($act === 'APPROVE_MANAGER' && $pr['status'] === 'MENUNGGU_MANAGER' && in_array($role, ['MANAGER', 'ADMIN'], true)) {
            $pdo->prepare("UPDATE ppbj_requests SET manager_name = ?, manager_note = ?, manager_date = ?, status = 'MENUNGGU_DIR_OPS' WHERE id = ?")
                ->execute([$actor, $note ?: 'Disetujui Atasan / Manager.', $today, $id]);
            $pdo->prepare("INSERT INTO ppbj_logs (ppbj_id, actor_name, actor_role, aksi, catatan) VALUES (?, ?, ?, ?, ?)")
                ->execute([$id, $actor, 'Atasan / Manager', 'Disetujui Manager', $note ?: 'Diteruskan ke Direktur Operasional.']);
            set_flash('Approval Manager berhasil. PPBJ diteruskan ke Direktur Operasional.');
        } elseif ($act === 'APPROVE_DIR_OPS' && $pr['status'] === 'MENUNGGU_DIR_OPS' && in_array($role, ['DIREKTUR_OPS', 'ADMIN'], true)) {
            $pdo->prepare("UPDATE ppbj_requests SET dir_ops_name = ?, dir_ops_note = ?, dir_ops_date = ?, status = 'MENUNGGU_DIR_KEU' WHERE id = ?")
                ->execute([$actor, $note ?: 'Disetujui Direktur Operasional.', $today, $id]);
            $pdo->prepare("INSERT INTO ppbj_logs (ppbj_id, actor_name, actor_role, aksi, catatan) VALUES (?, ?, ?, ?, ?)")
                ->execute([$id, $actor, 'Direktur Operasional', 'Disetujui Direktur Operasional', $note ?: 'Diteruskan ke Direktur Keuangan (approval terakhir).']);
            set_flash('Approval Direktur Operasional berhasil. PPBJ diteruskan ke Direktur Keuangan.');
        } elseif ($act === 'APPROVE_DIR_KEU' && $pr['status'] === 'MENUNGGU_DIR_KEU' && in_array($role, ['DIREKTUR_KEUANGAN', 'ADMIN'], true)) {
            $pdo->prepare("UPDATE ppbj_requests SET dir_keu_name = ?, dir_keu_note = ?, dir_keu_date = ?, status = 'SIAP_BID' WHERE id = ?")
                ->execute([$actor, $note ?: 'Anggaran & dana disetujui Direktur Keuangan.', $today, $id]);
            $pdo->prepare("INSERT INTO ppbj_logs (ppbj_id, actor_name, actor_role, aksi, catatan) VALUES (?, ?, ?, ?, ?)")
                ->execute([$id, $actor, 'Direktur Keuangan', 'Disetujui Direktur Keuangan (Final)', $note ?: 'Seluruh approval selesai. Siap dibuatkan Bid Summary oleh Procurement.']);
            set_flash('Approval Final Direktur Keuangan berhasil! PPBJ siap dibuatkan Bid Summary oleh Procurement.');
        } elseif ($act === 'REQUEST_REVISI' && in_array($role, ['MANAGER', 'DIREKTUR_OPS', 'DIREKTUR_KEUANGAN', 'ADMIN'], true)) {
            if ($note === '') throw new RuntimeException('Catatan alasan revisi wajib diisi.');
            $pdo->prepare("UPDATE ppbj_requests SET status = 'REVISI', catatan_revisi_tolak = ? WHERE id = ?")
                ->execute([$note, $id]);
            $pdo->prepare("INSERT INTO ppbj_logs (ppbj_id, actor_name, actor_role, aksi, catatan) VALUES (?, ?, ?, ?, ?)")
                ->execute([$id, $actor, role_label($role), 'Dikembalikan untuk Revisi', $note]);
            set_flash('PPBJ dikembalikan ke pemohon untuk revisi.');
        } elseif ($act === 'REJECT' && in_array($role, ['MANAGER', 'DIREKTUR_OPS', 'DIREKTUR_KEUANGAN', 'ADMIN'], true)) {
            if ($note === '') throw new RuntimeException('Alasan penolakan wajib diisi.');
            $pdo->prepare("UPDATE ppbj_requests SET status = 'DITOLAK', catatan_revisi_tolak = ? WHERE id = ?")
                ->execute([$note, $id]);
            $pdo->prepare("INSERT INTO ppbj_logs (ppbj_id, actor_name, actor_role, aksi, catatan) VALUES (?, ?, ?, ?, ?)")
                ->execute([$id, $actor, role_label($role), 'PPBJ Ditolak', $note]);
            set_flash('PPBJ telah ditolak.', 'error');
        } else {
            throw new RuntimeException('Anda tidak memiliki wewenang untuk melakukan aksi pada tahap ini.');
        }
        redirect_to("index.php?page=ppbj_detail&id={$id}");
    } catch (Throwable $e) {
        set_flash($e->getMessage(), 'error');
    }
}

$itemsStmt = $pdo->prepare("SELECT * FROM ppbj_items WHERE ppbj_id = ? ORDER BY item_no ASC");
$itemsStmt->execute([$id]);
$items = $itemsStmt->fetchAll();
$grandTotal = array_sum(array_map(fn($x) => (float)$x['harga_anggaran'], $items));

$logsStmt = $pdo->prepare("SELECT * FROM ppbj_logs WHERE ppbj_id = ? ORDER BY id ASC");
$logsStmt->execute([$id]);
$logs = $logsStmt->fetchAll();

$ftbStmt = $pdo->prepare("SELECT * FROM ftb_receipts WHERE ppbj_id = ? ORDER BY id DESC");
$ftbStmt->execute([$id]);
$linkedFtbs = $ftbStmt->fetchAll();

$bidStmt = $pdo->prepare("SELECT * FROM bid_summaries WHERE ppbj_id = ? ORDER BY id DESC");
$bidStmt->execute([$id]);
$linkedBids = $bidStmt->fetchAll();

$poStmt = $pdo->prepare("SELECT * FROM purchase_orders WHERE ppbj_id = ? ORDER BY id ASC");
$poStmt->execute([$id]);
$linkedPos = $poStmt->fetchAll();

[$sLabel, $sClass] = status_meta($pr['status']);
?>

<div class="card">
  <div class="card-header">
    <div>
      <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
        <h1 class="card-title" style="font-size:19px;margin:0;"><?= h($pr['request_no']) ?></h1>
        <span class="badge <?= h($sClass) ?>"><?= h($sLabel) ?></span>
      </div>
      <div style="font-size:12px;color:#64748b;margin-top:4px;">
        Dokumen: <strong><?= h($pr['doc_form_no']) ?></strong> | Divisi: <strong><?= h($pr['division_subdivision']) ?></strong> | Lokasi: <?= h($pr['delivery_location']) ?>
      </div>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;">
      <?php if (in_array($pr['status'], ['DRAFT', 'REVISI'], true) && in_array($role, ['PEMOHON', 'ADMIN'], true)): ?>
        <a href="index.php?page=ppbj_form&id=<?= $id ?>" class="btn btn-outline btn-sm">Edit PPBJ</a>
      <?php endif; ?>
      <a href="index.php?page=print_ppbj&id=<?= $id ?>" target="_blank" class="btn btn-primary btn-sm">Cetak Form PPBJ</a>
      <a href="index.php?page=ppbj_list" class="btn btn-outline btn-sm">&larr; Daftar PPBJ</a>
    </div>
  </div>

  <?php if ($pr['catatan_revisi_tolak'] && in_array($pr['status'], ['REVISI', 'DITOLAK'], true)): ?>
    <div class="flash flash-error">Catatan Revisi / Penolakan: <?= h($pr['catatan_revisi_tolak']) ?></div>
  <?php endif; ?>

  <div class="grid-3" style="font-size:13px;margin-bottom:16px;">
    <div class="disp-box">
      <h4>Informasi Permintaan</h4>
      <div>Tanggal Request: <strong><?= tgl_indo($pr['request_date']) ?></strong></div>
      <div>Target Penerimaan: <strong><?= tgl_indo($pr['received_date']) ?></strong></div>
      <div>Jenis Permintaan: <strong><?= h($pr['request_types']) ?></strong></div>
    </div>
    <div class="disp-box">
      <h4>Pemohon (Applied by)</h4>
      <div>Nama Pemohon: <strong><?= h($pr['applied_by_name']) ?></strong></div>
      <div>Tanggal Pengajuan: <strong><?= tgl_indo($pr['applied_by_date']) ?></strong></div>
      <div>Catatan: <?= h($pr['catatan_umum'] ?: '-') ?></div>
    </div>
    <div class="disp-box">
      <h4>Purchase Order (PO) &amp; Vendor</h4>
      <div>No. PO: <strong><?= h($pr['po_no'] ?: 'Belum diterbitkan') ?></strong></div>
      <div>Tanggal PO: <strong><?= tgl_indo($pr['po_date']) ?></strong></div>
      <div>Penjual / Vendor: <strong><?= h($pr['vendor_name'] ?: '-') ?></strong></div>
    </div>
  </div>

  <!-- Tabel Item PPBJ -->
  <div class="table-wrap" style="margin-bottom:18px;">
    <table class="data-table">
      <thead>
        <tr>
          <th>No.</th>
          <th>Jumlah</th>
          <th>Satuan</th>
          <th>No. Anggr</th>
          <th>Nama Barang / Jasa</th>
          <th>Peruntukan</th>
          <th>Foto</th>
          <th style="text-align:right;">Harga/Unit</th>
          <th style="text-align:right;">Harga (Sesuai Anggaran)</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($items as $it): ?>
          <tr>
            <td><?= (int)$it['item_no'] ?></td>
            <td><strong><?= rtrim(rtrim((string)$it['jumlah'], '0'), '.') ?></strong></td>
            <td><?= h($it['satuan']) ?></td>
            <td><?= h($it['no_anggaran'] ?: '-') ?></td>
            <td>
              <strong><?= h($it['nama_barang_jasa']) ?></strong>
              <?php if (($it['jalur_pengadaan'] ?? 'PO') === 'NON_PO'): ?>
                <span class="badge badge-purple" style="margin-left:4px;font-size:10px;">Non PO</span>
              <?php endif; ?>
            </td>
            <td style="color:#475569;"><?= h($it['peruntukan'] ?: '-') ?></td>
            <td>
              <?php if (!empty($it['foto_path'])): ?>
                <a href="<?= h($it['foto_path']) ?>" target="_blank">
                  <img src="<?= h($it['foto_path']) ?>" alt="Lampiran" style="width:46px;height:46px;object-fit:cover;border-radius:6px;border:1px solid #cbd5e1;">
                </a>
              <?php else: ?>
                <span style="color:#94a3b8;font-size:11.5px;">-</span>
              <?php endif; ?>
            </td>
            <td style="text-align:right;white-space:nowrap;"><?= rupiah($it['harga_unit']) ?></td>
            <td style="text-align:right;font-weight:700;white-space:nowrap;"><?= rupiah($it['harga_anggaran']) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
      <tfoot>
        <tr style="background:#f8fafc;">
          <td colspan="8" style="text-align:right;font-weight:800;">T O T A L</td>
          <td style="text-align:right;font-weight:800;font-size:15px;color:#007AB3;white-space:nowrap;"><?= rupiah($grandTotal) ?></td>
        </tr>
      </tfoot>
    </table>
  </div>

  <!-- 3 Tahap Approval Resmi -->
  <div class="grid-3">
    <div class="disp-box">
      <h4>1. Approval Atasan / Manager</h4>
      <p style="font-size:12.5px;margin:6px 0;"><?= h($pr['manager_note'] ?: 'Menunggu persetujuan Manager.') ?></p>
      <div style="font-size:11.5px;color:#64748b;">
        Manager: <strong><?= h($pr['manager_name'] ?: '-') ?></strong> | <?= tgl_indo($pr['manager_date']) ?>
      </div>
    </div>
    <div class="disp-box">
      <h4>2. Approval Direktur Operasional</h4>
      <p style="font-size:12.5px;margin:6px 0;"><?= h($pr['dir_ops_note'] ?: 'Menunggu approval Direktur Operasional.') ?></p>
      <div style="font-size:11.5px;color:#64748b;">
        Dir. Operasional: <strong><?= h($pr['dir_ops_name'] ?: '-') ?></strong> | <?= tgl_indo($pr['dir_ops_date']) ?>
      </div>
    </div>
    <div class="disp-box">
      <h4>3. Approval Direktur Keuangan (Final)</h4>
      <p style="font-size:12.5px;margin:6px 0;"><?= h($pr['dir_keu_note'] ?: 'Menunggu approval final Direktur Keuangan.') ?></p>
      <div style="font-size:11.5px;color:#64748b;">
        Dir. Keuangan: <strong><?= h($pr['dir_keu_name'] ?: '-') ?></strong> | <?= tgl_indo($pr['dir_keu_date']) ?>
      </div>
    </div>
  </div>
</div>

<!-- PANEL AKSI BERDASARKAN ROLE YANG SEDANG LOGIN -->
<?php if (!in_array($pr['status'], ['SELESAI_FTB', 'DITOLAK'], true)): ?>
<div class="card" style="border-color:#bae6fd;background:#f0f9ff;">
  <div class="card-header" style="border-bottom-color:#bae6fd;">
    <h2 class="card-title" style="color:#0369a1;">Tindak Lanjut Alur Approval (Status: <?= h($sLabel) ?>)</h2>
    <span style="font-size:12px;color:#0369a1;">Login Anda: <strong><?= h($user['nama_lengkap']) ?> (<?= h(role_label($role)) ?>)</strong></span>
  </div>

  <?php if (in_array($pr['status'], ['DRAFT', 'REVISI'], true)): ?>
    <?php if (in_array($role, ['PEMOHON', 'ADMIN'], true)): ?>
      <form method="post">
        <div class="form-group">
          <label class="form-label">Catatan Pengajuan ke Manager</label>
          <input type="text" name="note" class="form-control" placeholder="Keterangan pengajuan atau perbaikan revisi...">
        </div>
        <button type="submit" name="workflow_action" value="SUBMIT_DRAFT" class="btn btn-primary">Ajukan PPBJ ke Atasan / Manager</button>
      </form>
    <?php else: ?>
      <p style="margin:0;font-size:13px;color:#0369a1;">PPBJ ini berstatus <strong><?= h($sLabel) ?></strong> dan sedang ditindaklanjuti oleh <strong>Pemohon (<?= h($pr['applied_by_name']) ?>)</strong>.</p>
    <?php endif; ?>

  <?php elseif ($pr['status'] === 'MENUNGGU_MANAGER'): ?>
    <?php if (in_array($role, ['MANAGER', 'ADMIN'], true)): ?>
      <form method="post">
        <div class="form-group">
          <label class="form-label">Catatan Approval Manager (Wajib diisi jika Minta Revisi / Tolak)</label>
          <input type="text" name="note" class="form-control" placeholder="Catatan evaluasi manager...">
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
          <button type="submit" name="workflow_action" value="APPROVE_MANAGER" class="btn btn-green">Setujui Manager &rarr; Teruskan ke Direktur Operasional</button>
          <button type="submit" name="workflow_action" value="REQUEST_REVISI" class="btn btn-warning">Minta Revisi</button>
          <button type="submit" name="workflow_action" value="REJECT" class="btn btn-danger">Tolak PPBJ</button>
        </div>
      </form>
    <?php else: ?>
      <p style="margin:0;font-size:13px;color:#0369a1;">Menunggu persetujuan dari akun <strong>Atasan / Manager</strong> (username: <code>manager</code>).</p>
    <?php endif; ?>

  <?php elseif ($pr['status'] === 'MENUNGGU_DIR_OPS'): ?>
    <?php if (in_array($role, ['DIREKTUR_OPS', 'ADMIN'], true)): ?>
      <form method="post">
        <div class="form-group">
          <label class="form-label">Catatan Approval Direktur Operasional</label>
          <input type="text" name="note" class="form-control" placeholder="Evaluasi / arahan Direktur Operasional...">
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
          <button type="submit" name="workflow_action" value="APPROVE_DIR_OPS" class="btn btn-green">Setujui Direktur Operasional &rarr; Teruskan ke Direktur Keuangan</button>
          <button type="submit" name="workflow_action" value="REQUEST_REVISI" class="btn btn-warning">Minta Revisi</button>
          <button type="submit" name="workflow_action" value="REJECT" class="btn btn-danger">Tolak</button>
        </div>
      </form>
    <?php else: ?>
      <p style="margin:0;font-size:13px;color:#0369a1;">Menunggu approval dari akun <strong>Direktur Operasional</strong> (username: <code>dirops</code>).</p>
    <?php endif; ?>

  <?php elseif ($pr['status'] === 'MENUNGGU_DIR_KEU'): ?>
    <?php if (in_array($role, ['DIREKTUR_KEUANGAN', 'ADMIN'], true)): ?>
      <form method="post">
        <div class="form-group">
          <label class="form-label">Catatan Approval Final Direktur Keuangan (Anggaran &amp; Dana)</label>
          <input type="text" name="note" class="form-control" placeholder="Verifikasi kecukupan anggaran & persetujuan final...">
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
          <button type="submit" name="workflow_action" value="APPROVE_DIR_KEU" class="btn btn-green">Setujui Direktur Keuangan (Final) &rarr; Siap PO</button>
          <button type="submit" name="workflow_action" value="REQUEST_REVISI" class="btn btn-warning">Minta Revisi</button>
          <button type="submit" name="workflow_action" value="REJECT" class="btn btn-danger">Tolak</button>
        </div>
      </form>
    <?php else: ?>
      <p style="margin:0;font-size:13px;color:#0369a1;">Menunggu approval terakhir dari akun <strong>Direktur Keuangan</strong> (username: <code>dirkeu</code>).</p>
    <?php endif; ?>

  <?php elseif ($pr['status'] === 'SIAP_BID'): ?>
    <?php if (in_array($role, ['PROCUREMENT', 'ADMIN'], true)): ?>
      <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;">
        <div>
          <strong>PPBJ telah disetujui final oleh Direktur Keuangan!</strong>
          <div style="font-size:12.5px;color:#475569;">Langkah selanjutnya: buat <strong>Bid Summary</strong> untuk membandingkan harga beberapa vendor, lalu generate 1 atau beberapa PO otomatis.</div>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
          <a href="index.php?page=bid_summary_form&ppbj_id=<?= $id ?>" class="btn btn-primary">Buat Bid Summary (Bandingkan Vendor) &rarr;</a>
          <a href="index.php?page=po_form&ppbj_id=<?= $id ?>" class="btn btn-outline">Buat PO Langsung (Pilih Item)</a>
        </div>
      </div>
    <?php else: ?>
      <p style="margin:0;font-size:13px;color:#0369a1;">PPBJ sudah disetujui final oleh Direktur Keuangan. Menunggu tim <strong>Procurement</strong> (<code>noviani</code> / <code>safril</code> / <code>ichsan</code>) membuat Bid Summary &amp; PO.</p>
    <?php endif; ?>

  <?php elseif ($pr['status'] === 'PO_TERBIT'): ?>
    <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;">
      <div>
        <strong>Purchase Order <?= h($pr['po_no']) ?> sudah terbit ke <?= h($pr['vendor_name']) ?>.</strong>
        <div style="font-size:12.5px;color:#475569;">Langkah terakhir: isi <strong>Formulir Terima Barang/Jasa (FTB)</strong> saat barang/jasa tiba di lokasi/gudang.</div>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;">
        <a href="index.php?page=po_list" class="btn btn-outline">Kelola / Edit PO</a>
        <a href="index.php?page=ftb_form&ppbj_id=<?= $id ?>" class="btn btn-green">Isi FTB (PO) &rarr;</a>
        <?php if (count(array_filter($items, fn($x) => ($x['jalur_pengadaan'] ?? 'PO') === 'NON_PO')) > 0): ?>
          <a href="index.php?page=ftb_form&nonpo_ppbj_id=<?= $id ?>" class="btn btn-outline" style="border-color:#7c3aed;color:#6d28d9;">Isi FTB (Item Non PO) &rarr;</a>
        <?php endif; ?>
      </div>
    </div>

  <?php elseif ($pr['status'] === 'NON_PO'): ?>
    <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;">
      <div>
        <strong>Pengadaan Jalur Non-PO (<?= h($pr['po_no'] ?: 'Tanpa PO') ?>) — Vendor: <?= h($pr['vendor_name'] ?: '-') ?>.</strong>
        <div style="font-size:12.5px;color:#475569;">Sesuai Bid Summary, pengadaan ini tidak menggunakan PO. Langkah terakhir: langsung isi <strong>Formulir Terima Barang/Jasa (FTB)</strong>.</div>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;">
        <a href="index.php?page=ftb_form&ppbj_id=<?= $id ?>" class="btn btn-green">Isi Formulir Terima Barang/Jasa (FTB) &rarr;</a>
      </div>
    </div>
  <?php endif; ?>
</div>
<?php endif; ?>

<?php if (!empty($linkedBids) || !empty($linkedPos)): ?>
<div class="card" style="border-color:#93c5fd;">
  <div class="card-header">
    <h2 class="card-title" style="color:#1e40af;">Bid Summary &amp; Purchase Order Terkait</h2>
  </div>
  <?php if (!empty($linkedBids)): ?>
    <div style="margin-bottom:12px;font-size:13px;">
      <strong>Bid Summary:</strong>
      <?php foreach ($linkedBids as $lb): ?>
        <a href="index.php?page=bid_summary_form&id=<?= (int)$lb['id'] ?>" class="btn btn-outline btn-sm" style="margin-left:6px;">
          <?= h($lb['bid_no']) ?> — <?= h($lb['judul']) ?>
        </a>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
  <?php if (!empty($linkedPos)): ?>
    <div class="table-wrap">
      <table class="data-table">
        <thead>
          <tr><th>No. PO</th><th>Vendor</th><th>Total PO</th><th>Status</th><th>Aksi</th></tr>
        </thead>
        <tbody>
          <?php foreach ($linkedPos as $lpo): [$pLbl, $pCls] = po_status_meta($lpo['status']); ?>
            <tr>
              <td><strong><?= h($lpo['po_no']) ?></strong></td>
              <td><?= h($lpo['vendor_name']) ?></td>
              <td style="font-weight:700;"><?= rupiah($lpo['total_po']) ?></td>
              <td><span class="badge <?= h($pCls) ?>"><?= h($pLbl) ?></span></td>
              <td style="white-space:nowrap;">
                <?php if (in_array($role, ['PROCUREMENT', 'ADMIN'], true)): ?>
                  <a href="index.php?page=po_form&id=<?= (int)$lpo['id'] ?>" class="btn btn-primary btn-sm">Edit PO</a>
                <?php endif; ?>
                <a href="index.php?page=print_po&id=<?= (int)$lpo['id'] ?>" target="_blank" class="btn btn-outline btn-sm">Cetak PO</a>
                <?php if ($lpo['status'] !== 'SELESAI_FTB'): ?>
                  <a href="index.php?page=ftb_form&po_id=<?= (int)$lpo['id'] ?>" class="btn btn-green btn-sm">Isi FTB</a>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>
<?php endif; ?>

<?php if (!empty($linkedFtbs)): ?>
<div class="card" style="border-color:#86efac;">
  <div class="card-header">
    <h2 class="card-title" style="color:#166534;">Dokumen FTB Terkait (Akhir Alur)</h2>
  </div>
  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th>No. FTB</th>
          <th>Tgl FTB</th>
          <th>SJ/DO No.</th>
          <th>Lokasi Gudang</th>
          <th>Pemakai / Gudang</th>
          <th>Procurement</th>
          <th>Cetak</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($linkedFtbs as $f): ?>
          <tr>
            <td><strong><?= h($f['ftb_no']) ?></strong></td>
            <td><?= tgl_indo($f['ftb_date']) ?></td>
            <td><?= h($f['sj_do_no'] ?: '-') ?></td>
            <td><?= h($f['lokasi_gudang']) ?></td>
            <td><?= h($f['pemakai_gudang_nama']) ?> (<?= h($f['pemakai_gudang_jabatan']) ?>)</td>
            <td><?= h($f['procurement_nama']) ?> (<?= h($f['procurement_jabatan']) ?>)</td>
            <td><a href="index.php?page=print_ftb&id=<?= (int)$f['id'] ?>" target="_blank" class="btn btn-green btn-sm">Cetak FTB</a></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<div class="card">
  <div class="card-header">
    <h2 class="card-title">Riwayat Aktivitas &amp; Approval PPBJ</h2>
  </div>
  <div class="timeline">
    <?php foreach ($logs as $lg): ?>
      <div class="timeline-item">
        <span class="timeline-dot"></span>
        <div style="font-size:13px;">
          <strong><?= h($lg['aksi']) ?></strong>
          <span style="color:#94a3b8;font-size:11.5px;margin-left:8px;"><?= h($lg['created_at']) ?></span>
        </div>
        <div style="font-size:12.5px;color:#475569;">
          <strong><?= h($lg['actor_name']) ?></strong> (<?= h($lg['actor_role']) ?>) &mdash; <?= h($lg['catatan']) ?>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>
