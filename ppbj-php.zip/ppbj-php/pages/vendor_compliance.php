<?php
report_guard($user);
$period = report_period();
$canEdit = report_can_edit($user);
$selfUrl = 'index.php?page=vendor_compliance&tahun=' . $period['year'] . '&bulan=' . ($period['month'] ?: '');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $canEdit) {
    $act = $_POST['action'] ?? '';
    try {
        if ($act === 'add_incident') {
            $vendor = trim((string)($_POST['vendor_name'] ?? ''));
            $jenis = (string)($_POST['jenis'] ?? '');
            $date = (string)($_POST['incident_date'] ?? '');
            if ($vendor === '' || !isset(REPORT_INCIDENT_TYPES[$jenis]) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
                set_flash('Vendor, jenis catatan, dan tanggal wajib diisi.', 'error');
            } else {
                $pdo->prepare(
                    "INSERT INTO vendor_incidents (incident_date, vendor_name, jenis, po_no, keterangan, dibuat_oleh) VALUES (?, ?, ?, ?, ?, ?)"
                )->execute([
                    $date, $vendor, $jenis, trim((string)($_POST['po_no'] ?? '')) ?: null,
                    mb_substr(trim((string)($_POST['keterangan'] ?? '')), 0, 255) ?: null, $user['nama_lengkap'],
                ]);
                set_flash('Catatan vendor berhasil disimpan.');
            }
        } elseif ($act === 'del_incident') {
            $pdo->prepare("DELETE FROM vendor_incidents WHERE id = ?")->execute([(int)($_POST['id'] ?? 0)]);
            set_flash('Catatan vendor dihapus.');
        }
    } catch (Throwable $e) {
        set_flash('Gagal menyimpan: ' . $e->getMessage(), 'error');
    }
    redirect_to($selfUrl);
}

$perf = report_vendor_performance($pdo, $period);
[$hl1, $hl2, $hl3] = report_vendor_highlights($perf);
$gov = $perf['governance'];
$vendorNames = $pdo->query("SELECT nama_vendor FROM vendors ORDER BY nama_vendor ASC")->fetchAll(PDO::FETCH_COLUMN);
$stMeta = [
    'TOP' => ['Top Performing', 'badge-green'],
    'WATCH' => ['Under Watch', 'badge-red'],
    'NORMAL' => ['Normal', 'badge-slate'],
];
?>
<div class="card">
  <div class="card-header">
    <div>
      <h1 class="card-title" style="font-size:18px;">Vendor Performance &amp; Compliance Highlights</h1>
      <div style="font-size:12px;color:#64748b;">
        Periode <strong><?= h($period['label']) ?></strong> &middot; Dihitung otomatis dari PO/WO, FTB, dan Bid Summary + catatan vendor.
      </div>
    </div>
    <?php report_head_actions('vendor_compliance', $user); ?>
  </div>

  <?php report_nav_tabs('vendor_compliance'); ?>
  <?php report_filter_bar('vendor_compliance', $period); ?>

  <div class="table-wrap">
    <table class="rpt-table rpt-left">
      <thead><tr><th colspan="1" style="text-align:left;font-size:14px;">Vendor Performance &amp; Compliance Highlights</th></tr></thead>
      <tbody>
        <tr><td><?= h($hl1) ?></td></tr>
        <tr><td><?= h($hl2) ?></td></tr>
        <tr><td><?= h($hl3) ?></td></tr>
      </tbody>
    </table>
  </div>
</div>

<div class="card">
  <div class="card-header">
    <div>
      <h2 class="card-title">Skor Kinerja per Vendor</h2>
      <div style="font-size:12px;color:#64748b;">
        <strong>Top Performing</strong>: OTD &ge; <?= fmt_pct($perf['params']['top_min'], 0) ?>, tanpa reject &amp; tanpa catatan insiden. &nbsp;
        <strong>Under Watch</strong>: OTD &lt; <?= fmt_pct($perf['params']['watch_below'], 0) ?> atau ada SP/penalti/insiden K3/pelanggaran kepatuhan.
      </div>
    </div>
  </div>
  <div class="table-wrap">
    <table class="rpt-table">
      <thead>
        <tr>
          <th style="min-width:200px;">Vendor</th>
          <th>Order</th>
          <th style="min-width:130px;">Nilai (IDR)</th>
          <th>OTD (SLA)</th>
          <th>Terlambat</th>
          <th>Reject</th>
          <th>Catatan</th>
          <th style="min-width:130px;">Status</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($perf['vendors'])): ?>
          <tr><td colspan="8" style="text-align:center;color:#64748b;padding:20px;">Belum ada transaksi vendor pada periode ini.</td></tr>
        <?php endif; ?>
        <?php foreach ($perf['vendors'] as $r): [$sl, $sb] = $stMeta[$r['status']]; ?>
          <tr>
            <td><strong><?= h($r['vendor']) ?></strong>
              <?php if ($r['reasons']): ?><div class="sub"><?= h(implode('; ', $r['reasons'])) ?></div><?php endif; ?>
            </td>
            <td class="num"><?= (int)$r['orders'] ?></td>
            <td class="num"><?= fmt_idr($r['spent']) ?></td>
            <td class="num <?= $r['otd'] === null ? '' : ($r['otd'] >= $perf['params']['top_min'] ? 'rpt-ok' : ($r['otd'] < $perf['params']['watch_below'] ? 'rpt-bad' : 'rpt-warn')) ?>"><?= $r['otd'] === null ? 'n/a' : fmt_pct($r['otd'], 0) . " <span class=\"sub\">({$r['ontime']}/{$r['eval']})</span>" ?></td>
            <td class="num"><?= $r['late'] > 0 ? (int)$r['late'] . ' PO <span class="sub">(maks ' . (int)$r['max_late'] . ' hr)</span>' : '-' ?></td>
            <td class="num <?= $r['rej'] > 0 ? 'rpt-bad' : '' ?>"><?= $r['rej'] > 0 ? fmt_qty($r['rej']) . ' <span class="sub">(' . fmt_pct($r['rej_pct']) . ')</span>' : '-' ?></td>
            <td class="num"><?= $r['incidents'] > 0 ? (int)$r['incidents'] : '-' ?></td>
            <td><span class="badge <?= $sb ?>"><?= h($sl) ?></span></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <div class="rpt-foot">
    OTD = jumlah PO/WO yang diterima (FTB) paling lambat pada estimasi kirim &divide; PO/WO yang sudah jatuh tempo.
    PO yang melewati jatuh tempo tetapi belum ada FTB dihitung terlambat.
  </div>
</div>

<div class="card">
  <div class="card-header">
    <div>
      <h2 class="card-title">Governance: Komparasi Penawaran</h2>
      <div style="font-size:12px;color:#64748b;">
        Transaksi di atas <strong><?= rupiah($perf['params']['threshold']) ?></strong> wajib memiliki minimal
        <strong><?= (int)$perf['params']['min_quotes'] ?></strong> penawaran pada Bid Summary.
        <?= $gov['eligible'] > 0 ? 'Kepatuhan: <strong>' . fmt_pct($gov['pct'], 0) . '</strong> (' . $gov['compliant'] . ' dari ' . $gov['eligible'] . ').' : 'Tidak ada transaksi di atas batas pada periode ini.' ?>
      </div>
    </div>
  </div>
  <?php if (!empty($gov['rows'])): ?>
  <div class="table-wrap">
    <table class="rpt-table">
      <thead><tr><th>PO / WO</th><th style="min-width:200px;">Vendor</th><th style="min-width:130px;">Nilai (IDR)</th><th>Jumlah Penawaran</th><th>Status</th></tr></thead>
      <tbody>
        <?php foreach ($gov['rows'] as $g): ?>
          <tr>
            <td><?= h($g['po_no']) ?></td>
            <td><?= h($g['vendor']) ?></td>
            <td class="num"><?= fmt_idr($g['value']) ?></td>
            <td class="num"><?= (int)$g['quotes'] ?></td>
            <td><span class="badge <?= $g['ok'] ? 'badge-green' : 'badge-red' ?>"><?= $g['ok'] ? 'Sesuai' : 'Belum memenuhi' ?></span></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<div class="card">
  <div class="card-header">
    <div>
      <h2 class="card-title">Catatan Vendor (SP, Penalti, Insiden K3, Kepatuhan)</h2>
      <div style="font-size:12px;color:#64748b;">Data yang tidak bisa dihitung otomatis dicatat di sini dan ikut menentukan status vendor.</div>
    </div>
  </div>

  <?php if ($canEdit): ?>
  <form method="post" class="no-print" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;padding:12px;margin-bottom:14px;">
    <input type="hidden" name="action" value="add_incident">
    <div class="grid-4" style="margin-bottom:8px;">
      <div>
        <label class="form-label">Vendor *</label>
        <input type="text" name="vendor_name" class="form-control" list="vendorList" required placeholder="Nama vendor">
        <datalist id="vendorList"><?php foreach ($vendorNames as $vn): ?><option value="<?= h($vn) ?>"><?php endforeach; ?></datalist>
      </div>
      <div>
        <label class="form-label">Jenis *</label>
        <select name="jenis" class="form-control" required>
          <?php foreach (REPORT_INCIDENT_TYPES as $k => $lbl): ?><option value="<?= h($k) ?>"><?= h($lbl) ?></option><?php endforeach; ?>
        </select>
      </div>
      <div>
        <label class="form-label">Tanggal *</label>
        <input type="date" name="incident_date" class="form-control" required value="<?= h(min(date('Y-m-d'), $period['to'])) ?>">
      </div>
      <div>
        <label class="form-label">No. PO/WO (opsional)</label>
        <input type="text" name="po_no" class="form-control" placeholder="001/PO/XI-2026/PBS">
      </div>
    </div>
    <div style="display:flex;gap:8px;">
      <input type="text" name="keterangan" class="form-control" maxlength="255" placeholder="Keterangan singkat (mis. SP-1 karena keterlambatan pengiriman 7 hari)">
      <button type="submit" class="btn btn-primary btn-sm" style="white-space:nowrap;">+ Simpan Catatan</button>
    </div>
  </form>
  <?php endif; ?>

  <div class="table-wrap">
    <table class="rpt-table rpt-left">
      <thead><tr><th>Tanggal</th><th>Vendor</th><th>Jenis</th><th>PO/WO</th><th style="min-width:240px;">Keterangan</th><th class="no-print"></th></tr></thead>
      <tbody>
        <?php if (empty($perf['incidents'])): ?>
          <tr><td colspan="6" style="text-align:center;color:#64748b;padding:18px;">Tidak ada catatan pada periode ini.</td></tr>
        <?php endif; ?>
        <?php foreach ($perf['incidents'] as $in): ?>
          <tr>
            <td><?= h(tgl_indo($in['incident_date'])) ?></td>
            <td><?= h($in['vendor_name']) ?></td>
            <td><?= h(REPORT_INCIDENT_TYPES[$in['jenis']] ?? $in['jenis']) ?></td>
            <td><?= h($in['po_no'] ?: '-') ?></td>
            <td><?= h($in['keterangan'] ?: '-') ?></td>
            <td class="no-print">
              <?php if ($canEdit): ?>
              <form method="post" onsubmit="return confirm('Hapus catatan ini?');">
                <input type="hidden" name="action" value="del_incident">
                <input type="hidden" name="id" value="<?= (int)$in['id'] ?>">
                <button type="submit" class="btn btn-outline btn-sm" style="color:#dc2626;">Hapus</button>
              </form>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
