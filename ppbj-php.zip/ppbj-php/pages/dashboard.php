<?php
$role = $user['role'];
$isPemohon = ($role === 'PEMOHON');
$uid = (int)$user['id'];

if ($isPemohon) {
    // Statistik khusus PPBJ yang diajukan oleh user ini saja (bukan total semua user)
    $stMy = $pdo->prepare("SELECT status, manager_date, dir_ops_date, dir_keu_date FROM ppbj_requests WHERE user_id = ?");
    $stMy->execute([$uid]);
    $myAllRows = $stMy->fetchAll();

    $myTotal = count($myAllRows);
    $cntWaitMgr = 0;
    $cntWaitOps = 0;
    $cntWaitKeu = 0;
    $cntSiapBid = 0;
    $cntPoTerbit = 0;
    $cntNonPo = 0;
    $cntSelesai = 0;
    $cntRevisiTolak = 0;
    $approvedMgr = 0;
    $approvedOps = 0;
    $approvedKeu = 0;

    foreach ($myAllRows as $row) {
        if (!empty($row['manager_date'])) $approvedMgr++;
        if (!empty($row['dir_ops_date'])) $approvedOps++;
        if (!empty($row['dir_keu_date'])) $approvedKeu++;

        switch ($row['status']) {
            case 'MENUNGGU_MANAGER': $cntWaitMgr++; break;
            case 'MENUNGGU_DIR_OPS': $cntWaitOps++; break;
            case 'MENUNGGU_DIR_KEU': $cntWaitKeu++; break;
            case 'SIAP_BID': $cntSiapBid++; break;
            case 'PO_TERBIT': $cntPoTerbit++; break;
            case 'NON_PO': $cntNonPo++; break;
            case 'SELESAI_FTB': $cntSelesai++; break;
            case 'REVISI':
            case 'DITOLAK': $cntRevisiTolak++; break;
        }
    }

    $taskStmt = $pdo->prepare(
        "SELECT p.*, COALESCE(SUM(i.harga_anggaran),0) AS total_anggaran
         FROM ppbj_requests p
         LEFT JOIN ppbj_items i ON i.ppbj_id = p.id
         WHERE p.user_id = ? AND p.status IN ('DRAFT','REVISI','PO_TERBIT','NON_PO')
         GROUP BY p.id
         ORDER BY p.id DESC"
    );
    $taskStmt->execute([$uid]);
    $myTasks = $taskStmt->fetchAll();

    $recStmt = $pdo->prepare(
        "SELECT p.*, COALESCE(SUM(i.harga_anggaran),0) AS total_anggaran
         FROM ppbj_requests p
         LEFT JOIN ppbj_items i ON i.ppbj_id = p.id
         WHERE p.user_id = ?
         GROUP BY p.id
         ORDER BY p.id DESC LIMIT 8"
    );
    $recStmt->execute([$uid]);
    $recentPpbj = $recStmt->fetchAll();
} else {
    $totalPpbj = (int)$pdo->query("SELECT COUNT(*) FROM ppbj_requests")->fetchColumn();
    $waitingApproval = (int)$pdo->query(
        "SELECT COUNT(*) FROM ppbj_requests WHERE status IN ('MENUNGGU_MANAGER','MENUNGGU_DIR_OPS','MENUNGGU_DIR_KEU')"
    )->fetchColumn();
    $readyBid = (int)$pdo->query("SELECT COUNT(*) FROM ppbj_requests WHERE status = 'SIAP_BID'")->fetchColumn();
    $readyFtb = (int)$pdo->query("SELECT COUNT(*) FROM purchase_orders WHERE status IN ('TERBIT','DALAM_PENGIRIMAN')")->fetchColumn()
              + (int)$pdo->query("SELECT COUNT(*) FROM ppbj_requests WHERE status = 'NON_PO'")->fetchColumn();
    $totalFtb = (int)$pdo->query("SELECT COUNT(*) FROM ftb_receipts")->fetchColumn();
    $totalBudget = (float)$pdo->query(
        "SELECT COALESCE(SUM(i.harga_anggaran),0) FROM ppbj_items i JOIN ppbj_requests p ON i.ppbj_id = p.id WHERE p.status != 'DITOLAK'"
    )->fetchColumn();

    // Antrean tugas sesuai role yang sedang login
    $taskStatusMap = [
        'MANAGER' => ['MENUNGGU_MANAGER'],
        'DIREKTUR_OPS' => ['MENUNGGU_DIR_OPS'],
        'DIREKTUR_KEUANGAN' => ['MENUNGGU_DIR_KEU'],
        'PROCUREMENT' => ['SIAP_BID', 'PO_TERBIT', 'NON_PO'],
    ];
    $targetStatuses = $taskStatusMap[$role] ?? ['MENUNGGU_MANAGER', 'MENUNGGU_DIR_OPS', 'MENUNGGU_DIR_KEU'];
    $placeholders = implode(',', array_fill(0, count($targetStatuses), '?'));
    $taskStmt = $pdo->prepare(
        "SELECT p.*, COALESCE(SUM(i.harga_anggaran),0) AS total_anggaran
         FROM ppbj_requests p
         LEFT JOIN ppbj_items i ON i.ppbj_id = p.id
         WHERE p.status IN ({$placeholders})
         GROUP BY p.id
         ORDER BY p.id DESC"
    );
    $taskStmt->execute($targetStatuses);
    $myTasks = $taskStmt->fetchAll();

    $recentPpbj = $pdo->query(
        "SELECT p.*, COALESCE(SUM(i.harga_anggaran),0) AS total_anggaran
         FROM ppbj_requests p
         LEFT JOIN ppbj_items i ON i.ppbj_id = p.id
         GROUP BY p.id
         ORDER BY p.id DESC LIMIT 8"
    )->fetchAll();
}
?>

<div class="hero-banner">
  <div>
    <span class="hero-pill">Login Aktif: <?= h($user['nama_lengkap']) ?> &bull; <?= h(role_label($role)) ?></span>
    <h1>Sistem Informasi Permintaan Pembelian Barang &amp; Jasa</h1>
    <p>
      Alur resmi pengadaan: <strong>Pemohon</strong> &rarr; <strong>Manager</strong> &rarr;
      <strong>Direktur Operasional</strong> &rarr; <strong>Direktur Keuangan</strong> &rarr;
      <strong>Bid Summary</strong> &rarr; <strong>Purchase Order (1..N PO)</strong> &rarr; <strong>Form Terima Barang (FTB)</strong>.
    </p>
  </div>
  <div style="display:flex;gap:10px;flex-wrap:wrap;">
    <a href="index.php?page=ppbj_form" class="btn" style="background:#fff;color:#007AB3;">+ Ajukan Form PPBJ</a>
    <?php if (!$isPemohon): ?>
      <a href="index.php?page=bid_summary_list" class="btn" style="background:rgba(255,255,255,.16);color:#fff;border:1px solid rgba(255,255,255,.35);">Bid Summary (<?= $readyBid ?>)</a>
    <?php else: ?>
      <a href="index.php?page=ppbj_list" class="btn" style="background:rgba(255,255,255,.16);color:#fff;border:1px solid rgba(255,255,255,.35);">PPBJ Saya (<?= $myTotal ?>)</a>
    <?php endif; ?>
    <a href="index.php?page=ftb_form" class="btn" style="background:#00692D;color:#fff;border:1px solid rgba(255,255,255,.35);">Isi Form FTB</a>
  </div>
</div>

<div class="card">
  <div class="card-header">
    <h2 class="card-title">Alur Persetujuan Resmi: Form PPBJ &rarr; Bid Summary &rarr; PO &rarr; FTB</h2>
    <span style="font-size:12px;color:#64748b;">Dokumen FRM.APR.01.00 &amp; FTB Revisi</span>
  </div>
  <div class="pipeline">
    <div class="pipe-step">
      <span class="pipe-num">1</span>
      <span class="pipe-title">User / Pemohon</span>
      <span class="pipe-sub">Ajukan Form PPBJ</span>
    </div>
    <div class="pipe-step">
      <span class="pipe-num">2</span>
      <span class="pipe-title">Atasan / Manager</span>
      <span class="pipe-sub">Approval awal</span>
    </div>
    <div class="pipe-step">
      <span class="pipe-num">3</span>
      <span class="pipe-title">Dir. Operasional</span>
      <span class="pipe-sub">Approval operasional</span>
    </div>
    <div class="pipe-step">
      <span class="pipe-num">4</span>
      <span class="pipe-title">Dir. Keuangan</span>
      <span class="pipe-sub">Approval final dana</span>
    </div>
    <div class="pipe-step">
      <span class="pipe-num">5</span>
      <span class="pipe-title">Bid Summary</span>
      <span class="pipe-sub">Banding harga vendor</span>
    </div>
    <div class="pipe-step">
      <span class="pipe-num">6</span>
      <span class="pipe-title">Purchase Order</span>
      <span class="pipe-sub">Generate 1..N PO</span>
    </div>
    <div class="pipe-step final">
      <span class="pipe-num">7</span>
      <span class="pipe-title">Form FTB (Akhir)</span>
      <span class="pipe-sub">Terima Barang/Jasa</span>
    </div>
  </div>
</div>

<?php if ($isPemohon): ?>
  <!-- Ringkasan KHUSUS pengajuan milik user yang login (tanpa menampilkan total seluruh form/anggaran perusahaan) -->
  <div class="grid-4">
    <div class="kpi-card">
      <div class="kpi-label">PPBJ Saya Ajukan</div>
      <div class="kpi-val"><?= $myTotal ?></div>
      <div class="kpi-sub">Pengajuan milik <?= h($user['nama_lengkap']) ?></div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Sudah Approve Manager</div>
      <div class="kpi-val" style="color:#0369a1;"><?= $approvedMgr ?></div>
      <div class="kpi-sub">Menunggu Manager saat ini: <?= $cntWaitMgr ?></div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Sudah Approve Dir. Operasional</div>
      <div class="kpi-val" style="color:#6d28d9;"><?= $approvedOps ?></div>
      <div class="kpi-sub">Menunggu Dir. Ops saat ini: <?= $cntWaitOps ?></div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Approve Dir. Keuangan / Selesai</div>
      <div class="kpi-val" style="color:#008A3B;"><?= $approvedKeu ?></div>
      <div class="kpi-sub">PO Terbit: <?= $cntPoTerbit ?> &bull; Selesai FTB: <?= $cntSelesai ?></div>
    </div>
  </div>

  <div class="card">
    <div class="card-header">
      <div>
        <h2 class="card-title">Status Progress PPBJ yang Anda Ajukan</h2>
        <div style="font-size:12px;color:#64748b;">Klik status untuk melihat daftar PPBJ Anda pada tahap tersebut.</div>
      </div>
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px;">
      <a href="index.php?page=ppbj_list&status=MENUNGGU_MANAGER" class="pipe-step" style="text-decoration:none;color:inherit;">
        <span class="badge badge-amber">Menunggu Manager</span>
        <div style="font-size:22px;font-weight:800;margin-top:6px;"><?= $cntWaitMgr ?></div>
      </a>
      <a href="index.php?page=ppbj_list&status=MENUNGGU_DIR_OPS" class="pipe-step" style="text-decoration:none;color:inherit;">
        <span class="badge badge-sky">Menunggu Dir. Ops</span>
        <div style="font-size:22px;font-weight:800;margin-top:6px;"><?= $cntWaitOps ?></div>
      </a>
      <a href="index.php?page=ppbj_list&status=MENUNGGU_DIR_KEU" class="pipe-step" style="text-decoration:none;color:inherit;">
        <span class="badge badge-purple">Menunggu Dir. Keu</span>
        <div style="font-size:22px;font-weight:800;margin-top:6px;"><?= $cntWaitKeu ?></div>
      </a>
      <a href="index.php?page=ppbj_list&status=SIAP_BID" class="pipe-step" style="text-decoration:none;color:inherit;">
        <span class="badge badge-teal">Siap Bid / Proses PO</span>
        <div style="font-size:22px;font-weight:800;margin-top:6px;"><?= $cntSiapBid ?></div>
      </a>
      <a href="index.php?page=ppbj_list&status=PO_TERBIT" class="pipe-step" style="text-decoration:none;color:inherit;">
        <span class="badge badge-blue">PO Terbit</span>
        <div style="font-size:22px;font-weight:800;margin-top:6px;"><?= $cntPoTerbit ?></div>
      </a>
      <?php if ($cntNonPo > 0): ?>
      <a href="index.php?page=ppbj_list&status=NON_PO" class="pipe-step" style="text-decoration:none;color:inherit;">
        <span class="badge badge-purple">Non PO (Siap FTB)</span>
        <div style="font-size:22px;font-weight:800;margin-top:6px;"><?= $cntNonPo ?></div>
      </a>
      <?php endif; ?>
      <a href="index.php?page=ppbj_list&status=SELESAI_FTB" class="pipe-step" style="text-decoration:none;color:inherit;">
        <span class="badge badge-green">Selesai (FTB)</span>
        <div style="font-size:22px;font-weight:800;margin-top:6px;"><?= $cntSelesai ?></div>
      </a>
      <?php if ($cntRevisiTolak > 0): ?>
      <a href="index.php?page=ppbj_list&status=REVISI" class="pipe-step" style="text-decoration:none;color:inherit;">
        <span class="badge badge-orange">Revisi / Ditolak</span>
        <div style="font-size:22px;font-weight:800;margin-top:6px;"><?= $cntRevisiTolak ?></div>
      </a>
      <?php endif; ?>
    </div>
  </div>
<?php else: ?>
  <div class="grid-4">
    <div class="kpi-card">
      <div class="kpi-label">Total Form PPBJ</div>
      <div class="kpi-val"><?= $totalPpbj ?></div>
      <div class="kpi-sub">Permintaan Pengadaan Barang/Jasa</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Menunggu Approval</div>
      <div class="kpi-val"><?= $waitingApproval ?></div>
      <div class="kpi-sub">Manager / Dir. Ops / Dir. Keuangan</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Menunggu FTB (Akhir)</div>
      <div class="kpi-val" style="color:#007AB3;"><?= $readyFtb ?></div>
      <div class="kpi-sub"><?= $totalFtb ?> dokumen FTB telah selesai</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Total Nilai Anggaran</div>
      <div class="kpi-val" style="font-size:20px;color:#008A3B;"><?= rupiah($totalBudget) ?></div>
      <div class="kpi-sub">Akumulasi PPBJ aktif</div>
    </div>
  </div>
<?php endif; ?>

<!-- Antrean Tugas Peran Login -->
<div class="card" style="border-color:#bae6fd;background:#f0f9ff;">
  <div class="card-header" style="border-bottom-color:#bae6fd;">
    <div>
      <h2 class="card-title" style="color:#0369a1;">Tugas Menunggu Tindakan Anda (<?= h(role_label($role)) ?>)</h2>
      <div style="font-size:12px;color:#0369a1;">Daftar PPBJ/PO yang memerlukan aksi pada akun Anda saat ini.</div>
    </div>
    <span class="badge badge-sky"><?= count($myTasks) ?> Item</span>
  </div>
  <?php if (empty($myTasks)): ?>
    <p style="margin:0;font-size:13px;color:#475569;">Tidak ada tugas tertunda untuk peran Anda saat ini.</p>
  <?php else: ?>
    <div class="table-wrap">
      <table class="data-table">
        <thead>
          <tr>
            <th>No. PPBJ</th>
            <th>Divisi &amp; Pemohon</th>
            <th>Jenis Permintaan</th>
            <th style="text-align:right;">Total Anggaran</th>
            <th>Status</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($myTasks as $t): [$tLbl, $tCls] = status_meta($t['status']); ?>
            <tr>
              <td><strong><?= h($t['request_no']) ?></strong></td>
              <td>
                <div><?= h($t['division_subdivision']) ?></div>
                <div style="font-size:11.5px;color:#64748b;">Pemohon: <?= h($t['applied_by_name']) ?></div>
              </td>
              <td style="font-size:12px;"><?= h($t['request_types']) ?></td>
              <td style="text-align:right;font-weight:700;white-space:nowrap;"><?= rupiah($t['total_anggaran']) ?></td>
              <td><span class="badge <?= h($tCls) ?>"><?= h($tLbl) ?></span></td>
              <td style="white-space:nowrap;">
                <?php if ($t['status'] === 'SIAP_BID'): ?>
                  <a href="index.php?page=bid_summary_form&ppbj_id=<?= (int)$t['id'] ?>" class="btn btn-primary btn-sm">Buat Bid Summary &rarr;</a>
                <?php elseif ($t['status'] === 'PO_TERBIT'): ?>
                  <a href="index.php?page=ftb_list" class="btn btn-green btn-sm">Lihat PO / Isi FTB &rarr;</a>
                <?php elseif ($t['status'] === 'NON_PO'): ?>
                  <a href="index.php?page=ftb_form&ppbj_id=<?= (int)$t['id'] ?>" class="btn btn-green btn-sm">Isi FTB (Non PO) &rarr;</a>
                <?php else: ?>
                  <a href="index.php?page=ppbj_detail&id=<?= (int)$t['id'] ?>" class="btn btn-primary btn-sm">Tinjau &amp; Proses &rarr;</a>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<div class="card">
  <div class="card-header">
    <h2 class="card-title"><?= $isPemohon ? 'Daftar PPBJ yang Anda Ajukan' : 'Daftar PPBJ Terbaru' ?></h2>
    <a href="index.php?page=ppbj_list" class="btn btn-outline btn-sm"><?= $isPemohon ? 'Lihat Semua PPBJ Saya' : 'Lihat Semua PPBJ' ?></a>
  </div>
  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th>No. Permintaan (PPBJ)</th>
          <th>Tanggal</th>
          <th>Divisi &amp; Lokasi Pengiriman</th>
          <th>Jenis Permintaan</th>
          <th style="text-align:right;">Total Anggaran</th>
          <th>Status Alur</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($recentPpbj)): ?>
          <tr><td colspan="7" style="text-align:center;padding:24px;color:#64748b;">Belum ada PPBJ yang Anda ajukan.</td></tr>
        <?php else: foreach ($recentPpbj as $r): [$sLabel, $sClass] = status_meta($r['status']); ?>
          <tr>
            <td>
              <a href="index.php?page=ppbj_detail&id=<?= (int)$r['id'] ?>" style="font-weight:700;color:#007AB3;">
                <?= h($r['request_no']) ?>
              </a>
              <div style="font-size:11.5px;color:#64748b;">Pemohon: <?= h($r['applied_by_name']) ?></div>
            </td>
            <td style="white-space:nowrap;">
              <div><?= tgl_indo($r['request_date']) ?></div>
              <div style="font-size:11px;color:#64748b;">Target: <?= tgl_indo($r['received_date']) ?></div>
            </td>
            <td>
              <div style="font-weight:600;"><?= h($r['division_subdivision']) ?></div>
              <div style="font-size:11.5px;color:#64748b;"><?= h($r['delivery_location']) ?></div>
            </td>
            <td style="font-size:12px;"><?= h($r['request_types']) ?></td>
            <td style="text-align:right;font-weight:700;white-space:nowrap;"><?= rupiah($r['total_anggaran']) ?></td>
            <td><span class="badge <?= h($sClass) ?>"><?= h($sLabel) ?></span></td>
            <td style="white-space:nowrap;">
              <a href="index.php?page=ppbj_detail&id=<?= (int)$r['id'] ?>" class="btn btn-outline btn-sm">Detail</a>
              <a href="index.php?page=print_ppbj&id=<?= (int)$r['id'] ?>" target="_blank" class="btn btn-outline btn-sm">Cetak</a>
            </td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>
