<?php
$prePoId = isset($_GET['po_id']) ? (int)$_GET['po_id'] : 0;
$preNonPoPpbjId = isset($_GET['nonpo_ppbj_id']) ? (int)$_GET['nonpo_ppbj_id'] : 0;
$prePpbjId = isset($_GET['ppbj_id']) ? (int)$_GET['ppbj_id'] : 0;

$selectedPo = null;
$selectedPpbj = null;
$isNonPoMode = false;
$preItems = [];

if ($prePoId > 0) {
    $st = $pdo->prepare(
        "SELECT po.*, p.request_no, p.applied_by_name
         FROM purchase_orders po
         JOIN ppbj_requests p ON po.ppbj_id = p.id
         WHERE po.id = ?"
    );
    $st->execute([$prePoId]);
    $selectedPo = $st->fetch();
    if ($selectedPo) {
        $prePpbjId = (int)$selectedPo['ppbj_id'];
        $itSt = $pdo->prepare(
            "SELECT ppbj_item_id AS id, nama_barang_jasa, qty AS jumlah, satuan
             FROM po_items WHERE po_id = ? ORDER BY item_no ASC"
        );
        $itSt->execute([$prePoId]);
        $preItems = $itSt->fetchAll();
    }
} elseif ($preNonPoPpbjId > 0) {
    $isNonPoMode = true;
    $prePpbjId = $preNonPoPpbjId;
    $stmt = $pdo->prepare("SELECT * FROM ppbj_requests WHERE id = ?");
    $stmt->execute([$prePpbjId]);
    $selectedPpbj = $stmt->fetch();
    if ($selectedPpbj) {
        $st2 = $pdo->prepare(
            "SELECT * FROM ppbj_items pi
             WHERE pi.ppbj_id = ? AND pi.jalur_pengadaan = 'NON_PO'
               AND NOT EXISTS (SELECT 1 FROM ftb_items fi WHERE fi.ppbj_item_id = pi.id)
             ORDER BY pi.item_no ASC"
        );
        $st2->execute([$prePpbjId]);
        $preItems = $st2->fetchAll();
        if (empty($preItems)) {
            $stAll = $pdo->prepare("SELECT * FROM ppbj_items WHERE ppbj_id = ? AND jalur_pengadaan = 'NON_PO' ORDER BY item_no ASC");
            $stAll->execute([$prePpbjId]);
            $preItems = $stAll->fetchAll();
        }
    }
} elseif ($prePpbjId > 0) {
    // jika ada PO aktif untuk PPBJ ini, arahkan ke PO pertama yang belum selesai
    $poFirst = $pdo->prepare("SELECT id FROM purchase_orders WHERE ppbj_id = ? AND status != 'SELESAI_FTB' ORDER BY id ASC LIMIT 1");
    $poFirst->execute([$prePpbjId]);
    $foundPoId = (int)$poFirst->fetchColumn();
    if ($foundPoId > 0) {
        redirect_to("index.php?page=ftb_form&po_id={$foundPoId}");
    }
    $stmt = $pdo->prepare("SELECT * FROM ppbj_requests WHERE id = ?");
    $stmt->execute([$prePpbjId]);
    $selectedPpbj = $stmt->fetch();
    if ($selectedPpbj) {
        $isNonPoMode = ($selectedPpbj['status'] === 'NON_PO');
        $st2 = $pdo->prepare("SELECT * FROM ppbj_items WHERE ppbj_id = ? ORDER BY item_no ASC");
        $st2->execute([$prePpbjId]);
        $preItems = $st2->fetchAll();
    }
}

$poReadyList = $pdo->query(
    "SELECT po.id, po.po_no, po.po_date, po.vendor_name, po.ppbj_id, p.request_no
     FROM purchase_orders po
     JOIN ppbj_requests p ON po.ppbj_id = p.id
     WHERE po.status IN ('TERBIT', 'DALAM_PENGIRIMAN')
     ORDER BY po.id DESC"
)->fetchAll();

$nonPoReadyList = $pdo->query(
    "SELECT p.id, p.request_no, p.po_no, p.vendor_name, p.division_subdivision, COUNT(pi.id) AS jml_item
     FROM ppbj_requests p
     JOIN ppbj_items pi ON pi.ppbj_id = p.id
     WHERE pi.jalur_pengadaan = 'NON_PO'
       AND NOT EXISTS (SELECT 1 FROM ftb_items fi WHERE fi.ppbj_item_id = pi.id)
     GROUP BY p.id
     ORDER BY p.id DESC"
)->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ftbNo = trim($_POST['ftb_no'] ?? next_ftb_no($pdo));
    $ftbDate = $_POST['ftb_date'] ?: date('Y-m-d');
    $poId = (int)($_POST['po_id'] ?? 0) ?: null;
    $ppbjId = (int)($_POST['ppbj_id'] ?? 0) ?: null;
    $sumber = $_POST['sumber_penerimaan'] === 'BARANG_RETUR' ? 'BARANG_RETUR' : 'PEMBELIAN_BARU';
    $penjual = trim($_POST['penjual_seller'] ?? '');
    $poNo = trim($_POST['po_no'] ?? '');
    $poDate = $_POST['po_date'] ?: null;
    $sjDoNo = trim($_POST['sj_do_no'] ?? '');
    $returDivisi = trim($_POST['retur_divisi'] ?? '');
    $returNama = trim($_POST['retur_nama'] ?? '');
    $lokasiGudang = trim($_POST['lokasi_gudang'] ?? '');
    $pemakaiNama = trim($_POST['pemakai_gudang_nama'] ?? '');
    $pemakaiJabatan = trim($_POST['pemakai_gudang_jabatan'] ?? '');
    $procNama = trim($_POST['procurement_nama'] ?? ($user['role'] === 'PROCUREMENT' ? $user['nama_lengkap'] : 'Noviani Nuzulia'));
    $procJabatan = trim($_POST['procurement_jabatan'] ?? 'Procurement Specialist');

    if ($poId && !$ppbjId) {
        $pSt = $pdo->prepare("SELECT ppbj_id FROM purchase_orders WHERE id = ?");
        $pSt->execute([$poId]);
        $ppbjId = (int)$pSt->fetchColumn() ?: null;
    }

    $descArr = $_POST['item_perincian'] ?? [];
    $qtyArr = $_POST['item_qty'] ?? [];
    $unitArr = $_POST['item_unit'] ?? [];
    $condArr = $_POST['item_kondisi'] ?? [];
    $accArr = $_POST['item_accepted'] ?? [];
    $rejArr = $_POST['item_rejected'] ?? [];
    $ppbjItemIds = $_POST['ppbj_item_id'] ?? [];

    $itemsToInsert = [];
    for ($i = 0; $i < count($descArr); $i++) {
        $d = trim($descArr[$i] ?? '');
        if ($d === '') continue;
        $q = max(0.01, (float)($qtyArr[$i] ?? 1));
        $u = trim($unitArr[$i] ?? 'Unit') ?: 'Unit';
        $c = trim($condArr[$i] ?? 'Baik / Lengkap');
        $acc = max(0, (float)($accArr[$i] ?? $q));
        $rej = max(0, (float)($rejArr[$i] ?? 0));
        $statusItem = $rej <= 0 ? 'Accepted' : ($acc <= 0 ? 'Rejected' : 'Partial');

        $itemsToInsert[] = [
            'ppbj_item_id' => !empty($ppbjItemIds[$i]) ? (int)$ppbjItemIds[$i] : null,
            'item_no' => count($itemsToInsert) + 1,
            'perincian' => $d,
            'qty' => $q,
            'unit' => $u,
            'catatan_kondisi' => $c,
            'qty_accepted' => $acc,
            'qty_rejected' => $rej,
            'status_penerimaan' => $statusItem,
        ];
    }

    if ($ftbNo === '' || $lokasiGudang === '' || empty($itemsToInsert)) {
        set_flash('No. FTB, Lokasi Gudang, dan minimal 1 perincian barang/jasa wajib diisi.', 'error');
    } else {
        try {
            $pdo->beginTransaction();
            $ins = $pdo->prepare(
                "INSERT INTO ftb_receipts (
                    ftb_no, ftb_date, ppbj_id, po_id, sumber_penerimaan, penjual_seller, po_no, po_date, sj_do_no,
                    retur_divisi, retur_nama, lokasi_gudang,
                    pemakai_gudang_nama, pemakai_gudang_jabatan, procurement_nama, procurement_jabatan
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
            );
            $ins->execute([
                $ftbNo, $ftbDate, $ppbjId, $poId, $sumber, $penjual, $poNo, $poDate, $sjDoNo,
                $returDivisi, $returNama, $lokasiGudang,
                $pemakaiNama, $pemakaiJabatan, $procNama, $procJabatan
            ]);
            $ftbId = (int)$pdo->lastInsertId();

            $insItem = $pdo->prepare(
                "INSERT INTO ftb_items (ftb_id, ppbj_item_id, item_no, perincian, qty, unit, catatan_kondisi, qty_accepted, qty_rejected, status_penerimaan)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
            );
            foreach ($itemsToInsert as $it) {
                $insItem->execute([
                    $ftbId, $it['ppbj_item_id'], $it['item_no'], $it['perincian'], $it['qty'],
                    $it['unit'], $it['catatan_kondisi'], $it['qty_accepted'], $it['qty_rejected'], $it['status_penerimaan']
                ]);
            }

            if ($poId) {
                $pdo->prepare("UPDATE purchase_orders SET status = 'SELESAI_FTB' WHERE id = ?")->execute([$poId]);
            }

            if ($ppbjId) {
                $remPo = $pdo->prepare("SELECT COUNT(*) FROM purchase_orders WHERE ppbj_id = ? AND status != 'SELESAI_FTB'");
                $remPo->execute([$ppbjId]);
                $remainingPoCount = (int)$remPo->fetchColumn();

                $remNonPo = $pdo->prepare(
                    "SELECT COUNT(*) FROM ppbj_items pi
                     WHERE pi.ppbj_id = ? AND pi.jalur_pengadaan = 'NON_PO'
                       AND NOT EXISTS (SELECT 1 FROM ftb_items fi WHERE fi.ppbj_item_id = pi.id)"
                );
                $remNonPo->execute([$ppbjId]);
                $remainingNonPoCount = (int)$remNonPo->fetchColumn();

                if ($remainingPoCount === 0 && $remainingNonPoCount === 0) {
                    $pdo->prepare("UPDATE ppbj_requests SET status = 'SELESAI_FTB' WHERE id = ?")->execute([$ppbjId]);
                }
                $pdo->prepare("INSERT INTO ppbj_logs (ppbj_id, actor_name, actor_role, aksi, catatan) VALUES (?, ?, ?, ?, ?)")
                    ->execute([
                        $ppbjId, "{$pemakaiNama} & {$procNama}", 'Gudang & Procurement',
                        "FTB Diterbitkan ({$ftbNo})",
                        "PO: {$poNo} | Lokasi: {$lokasiGudang} | SJ/DO: {$sjDoNo}"
                    ]);
            }

            $pdo->commit();
            set_flash("Formulir Terima Barang/Jasa ({$ftbNo}) berhasil disimpan ke MySQL!");
            redirect_to("index.php?page=print_ftb&id={$ftbId}");
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            set_flash('Gagal menyimpan FTB: ' . $e->getMessage(), 'error');
        }
    }
}

$defaultFtbNo = next_ftb_no($pdo);
$defaultSeller = $selectedPo['vendor_name'] ?? ($selectedPpbj['vendor_name'] ?? '');
$defaultPoNo = $selectedPo['po_no'] ?? ($isNonPoMode ? 'NON-PO' : ($selectedPpbj['po_no'] ?? ''));
$defaultPoDate = $selectedPo['po_date'] ?? ($selectedPpbj['po_date'] ?? '');
$defaultLocation = $selectedPo['delivery_location'] ?? ($selectedPpbj['delivery_location'] ?? 'Gudang Site Woyla Aceh');
$defaultUser = $selectedPo['applied_by_name'] ?? ($selectedPpbj['applied_by_name'] ?? $user['nama_lengkap']);

if (empty($preItems)) {
    $preItems = [[
        'id' => '',
        'nama_barang_jasa' => '',
        'jumlah' => 1,
        'satuan' => 'Unit',
    ]];
}
?>

<form method="post">
  <input type="hidden" name="ppbj_id" value="<?= $prePpbjId ?>">
  <div class="card">
    <div class="card-header">
      <div>
        <h1 class="card-title" style="font-size:18px;">FORMULIR TERIMA BARANG/JASA (FTB)</h1>
        <div style="font-size:12px;color:#64748b;">Tahap Akhir Pengadaan — PT. Potensi Bumi Sakti (Sesuai FTB Revisi)</div>
      </div>
      <a href="index.php?page=ftb_list" class="btn btn-outline btn-sm">&larr; Daftar FTB</a>
    </div>

    <!-- Pilih PO Aktif atau Pengadaan Non-PO untuk auto-fill -->
    <div class="form-group" style="background:#f0f9ff;border:1px solid #bae6fd;border-radius:12px;padding:14px;">
      <label class="form-label" style="color:#0369a1;">Pilih PO Aktif atau Pengadaan Non-PO (Otomatis Mengisi Penjual &amp; Item Barang)</label>
      <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
        <select name="po_id" class="form-control" style="flex:1;min-width:260px;" onchange="if(this.value.startsWith('nonpo:')){window.location='index.php?page=ftb_form&nonpo_ppbj_id='+this.value.slice(6);}else if(this.value){window.location='index.php?page=ftb_form&po_id='+this.value;}">
          <option value="">-- Pilih Purchase Order (PO) atau Barang Non-PO --</option>
          <?php if (!empty($poReadyList)): ?>
            <optgroup label="Purchase Order (PO)">
              <?php foreach ($poReadyList as $po): ?>
                <option value="<?= (int)$po['id'] ?>" <?= $prePoId === (int)$po['id'] ? 'selected' : '' ?>>
                  <?= h($po['po_no']) ?> — <?= h($po['vendor_name']) ?> (Ref: <?= h($po['request_no']) ?>)
                </option>
              <?php endforeach; ?>
            </optgroup>
          <?php endif; ?>
          <?php if (!empty($nonPoReadyList)): ?>
            <optgroup label="Barang Jalur Non PO (Langsung FTB)">
              <?php foreach ($nonPoReadyList as $np): ?>
                <option value="nonpo:<?= (int)$np['id'] ?>" <?= ($isNonPoMode && $prePpbjId === (int)$np['id']) ? 'selected' : '' ?>>
                  [NON-PO · <?= (int)$np['jml_item'] ?> item] <?= h($np['request_no']) ?> — <?= h($np['vendor_name'] ?: $np['division_subdivision']) ?>
                </option>
              <?php endforeach; ?>
            </optgroup>
          <?php endif; ?>
        </select>
        <?php if ($selectedPo): ?>
          <span class="badge badge-green">Terhubung ke <?= h($selectedPo['po_no']) ?></span>
        <?php elseif ($isNonPoMode && $selectedPpbj): ?>
          <span class="badge badge-purple">Barang Non PO (<?= h($selectedPpbj['request_no']) ?>)</span>
        <?php endif; ?>
      </div>
    </div>

    <div class="grid-3">
      <div class="form-group">
        <label class="form-label">Nomor FTB *</label>
        <input type="text" name="ftb_no" class="form-control" required value="<?= h($defaultFtbNo) ?>">
      </div>
      <div class="form-group">
        <label class="form-label">Tgl / Date of FTB *</label>
        <input type="date" name="ftb_date" class="form-control" required value="<?= date('Y-m-d') ?>">
      </div>
      <div class="form-group">
        <label class="form-label">Sumber Penerimaan *</label>
        <select name="sumber_penerimaan" id="sumberSelect" class="form-control" onchange="toggleSumber()">
          <option value="PEMBELIAN_BARU">PEMBELIAN BARU DARI / NEW PURCHASE FROM</option>
          <option value="BARANG_RETUR">BARANG RETUR DARI / RETURNED GOODS FROM</option>
        </select>
      </div>
    </div>

    <!-- Blok Pembelian Baru -->
    <div id="blokPembelian" class="disp-box" style="margin-bottom:14px;">
      <h4>Pembelian Baru Dari / New Purchase From</h4>
      <div class="grid-4" style="margin-bottom:0;">
        <div class="form-group" style="margin-bottom:0;">
          <label class="form-label">Penjual / Seller</label>
          <input type="text" name="penjual_seller" class="form-control" value="<?= h($defaultSeller) ?>" placeholder="Nama Vendor / Toko">
        </div>
        <div class="form-group" style="margin-bottom:0;">
          <label class="form-label">PO No.</label>
          <input type="text" name="po_no" class="form-control" value="<?= h($defaultPoNo) ?>" placeholder="PO/PBS/...">
        </div>
        <div class="form-group" style="margin-bottom:0;">
          <label class="form-label">Tgl PO / PO Date</label>
          <input type="date" name="po_date" class="form-control" value="<?= h($defaultPoDate) ?>">
        </div>
        <div class="form-group" style="margin-bottom:0;">
          <label class="form-label">SJ No. / DO No. (Surat Jalan)</label>
          <input type="text" name="sj_do_no" class="form-control" placeholder="Nomor Surat Jalan / Delivery Order">
        </div>
      </div>
    </div>

    <!-- Blok Barang Retur -->
    <div id="blokRetur" class="disp-box" style="margin-bottom:14px;display:none;">
      <h4>Barang Retur Dari / Returned Goods From</h4>
      <div class="grid-2" style="margin-bottom:0;">
        <div class="form-group" style="margin-bottom:0;">
          <label class="form-label">Divisi Pemakai / User Div.</label>
          <input type="text" name="retur_divisi" class="form-control" placeholder="Divisi pengembali barang">
        </div>
        <div class="form-group" style="margin-bottom:0;">
          <label class="form-label">Nama / Name</label>
          <input type="text" name="retur_nama" class="form-control" placeholder="Nama penanggung jawab retur">
        </div>
      </div>
    </div>

    <div class="form-group">
      <label class="form-label">Di Lokasi Gudang / At Warehouse Location *</label>
      <input type="text" name="lokasi_gudang" class="form-control" required value="<?= h($defaultLocation) ?>">
    </div>
  </div>

  <!-- Tabel Perincian Barang atau Jasa -->
  <div class="card">
    <div class="card-header">
      <div>
        <h2 class="card-title">Perincian Barang atau Jasa / Description of Goods or Services</h2>
        <div style="font-size:12px;color:#64748b;">*) Nama &amp; spesifikasi barang, Qty, Catatan Kondisi, serta jumlah Accepted / Rejected.</div>
      </div>
      <button type="button" onclick="addFtbRow()" class="btn btn-green btn-sm">+ Tambah Baris</button>
    </div>

    <div class="table-wrap">
      <table class="data-table">
        <thead>
          <tr>
            <th style="width:45px;">No.</th>
            <th style="min-width:240px;">Perincian*) / Description*)</th>
            <th style="width:85px;">Jml / Qty</th>
            <th style="width:90px;">Unit</th>
            <th style="min-width:190px;">Catatan Kondisi / Remarks of Condition</th>
            <th style="width:95px;">Accepted</th>
            <th style="width:95px;">Rejected</th>
            <th style="width:45px;"></th>
          </tr>
        </thead>
        <tbody id="ftbBody">
          <?php foreach ($preItems as $idx => $it): ?>
          <tr class="ftb-row">
            <td class="ftb-num" style="font-weight:700;text-align:center;"><?= $idx + 1 ?></td>
            <td>
              <input type="hidden" name="ppbj_item_id[]" value="<?= h((string)($it['id'] ?? '')) ?>">
              <input type="text" name="item_perincian[]" class="form-control" required value="<?= h($it['nama_barang_jasa'] ?? '') ?>" placeholder="Nama &amp; spesifikasi barang/jasa">
            </td>
            <td><input type="number" step="0.01" min="0.01" name="item_qty[]" class="form-control" value="<?= h((string)($it['jumlah'] ?? 1)) ?>"></td>
            <td><input type="text" name="item_unit[]" class="form-control" value="<?= h($it['satuan'] ?? 'Unit') ?>"></td>
            <td><input type="text" name="item_kondisi[]" class="form-control" value="Baik / Sesuai Spesifikasi"></td>
            <td><input type="number" step="0.01" min="0" name="item_accepted[]" class="form-control" value="<?= h((string)($it['jumlah'] ?? 1)) ?>"></td>
            <td><input type="number" step="0.01" min="0" name="item_rejected[]" class="form-control" value="0"></td>
            <td><button type="button" onclick="removeFtbRow(this)" class="btn btn-outline btn-sm" style="color:#dc2626;">&times;</button></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Blok Penandatangan FTB -->
  <div class="card">
    <div class="card-header">
      <h2 class="card-title">Pengesahan Serah Terima (Tanda Tangan FTB)</h2>
    </div>
    <div class="grid-2">
      <div class="disp-box">
        <h4>Pemakai (User) / Gudang (Warehouse)</h4>
        <div class="form-group">
          <label class="form-label">Nama Lengkap *</label>
          <input type="text" name="pemakai_gudang_nama" class="form-control" required value="<?= h($defaultUser) ?>">
        </div>
        <div class="form-group" style="margin-bottom:0;">
          <label class="form-label">Jabatan / Position *</label>
          <input type="text" name="pemakai_gudang_jabatan" class="form-control" required value="User / Staff Gudang Site">
        </div>
      </div>

      <div class="disp-box">
        <h4>Procurement</h4>
        <div class="form-group">
          <label class="form-label">Nama Lengkap *</label>
          <input type="text" name="procurement_nama" class="form-control" required value="<?= h($user['role'] === 'PROCUREMENT' ? $user['nama_lengkap'] : 'Noviani Nuzulia') ?>">
        </div>
        <div class="form-group" style="margin-bottom:0;">
          <label class="form-label">Jabatan / Position *</label>
          <input type="text" name="procurement_jabatan" class="form-control" required value="Procurement Specialist">
        </div>
      </div>
    </div>

    <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:18px;">
      <a href="index.php?page=ftb_list" class="btn btn-outline">Batal</a>
      <button type="submit" class="btn btn-green">Simpan &amp; Terbitkan Form FTB</button>
    </div>
  </div>
</form>

<script>
function toggleSumber() {
  const val = document.getElementById('sumberSelect').value;
  document.getElementById('blokPembelian').style.display = val === 'PEMBELIAN_BARU' ? 'block' : 'none';
  document.getElementById('blokRetur').style.display = val === 'BARANG_RETUR' ? 'block' : 'none';
}
function addFtbRow() {
  const tbody = document.getElementById('ftbBody');
  const n = tbody.querySelectorAll('.ftb-row').length + 1;
  const tr = document.createElement('tr');
  tr.className = 'ftb-row';
  tr.innerHTML = `
    <td class="ftb-num" style="font-weight:700;text-align:center;">${n}</td>
    <td><input type="hidden" name="ppbj_item_id[]" value=""><input type="text" name="item_perincian[]" class="form-control" required placeholder="Nama & spesifikasi barang/jasa"></td>
    <td><input type="number" step="0.01" min="0.01" name="item_qty[]" class="form-control" value="1"></td>
    <td><input type="text" name="item_unit[]" class="form-control" value="Unit"></td>
    <td><input type="text" name="item_kondisi[]" class="form-control" value="Baik / Sesuai Spesifikasi"></td>
    <td><input type="number" step="0.01" min="0" name="item_accepted[]" class="form-control" value="1"></td>
    <td><input type="number" step="0.01" min="0" name="item_rejected[]" class="form-control" value="0"></td>
    <td><button type="button" onclick="removeFtbRow(this)" class="btn btn-outline btn-sm" style="color:#dc2626;">&times;</button></td>
  `;
  tbody.appendChild(tr);
}
function removeFtbRow(btn) {
  const rows = document.querySelectorAll('#ftbBody .ftb-row');
  if (rows.length <= 1) return;
  btn.closest('tr').remove();
  document.querySelectorAll('#ftbBody .ftb-num').forEach((el, i) => el.textContent = i + 1);
}
</script>
