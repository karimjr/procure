<?php
report_guard($user);
$period = report_period();
$q = trim((string)($_GET['q'] ?? ''));
$stFilter = trim((string)($_GET['status'] ?? ''));

$all = report_order_lines($pdo, $period['from'], $period['to']);
$rows = array_values(array_filter($all, function ($r) use ($q, $stFilter) {
    if ($stFilter !== '' && $r['track_status'] !== $stFilter) return false;
    if ($q !== '') {
        $hay = strtolower($r['po_no'] . ' ' . $r['vendor_name'] . ' ' . $r['nama_barang_jasa']);
        if (strpos($hay, strtolower($q)) === false) return false;
    }
    return true;
}));

$poSet = [];
$totValue = 0.0; $totOrd = 0.0; $totRecv = 0.0; $totRej = 0.0; $done = 0;
foreach ($rows as $r) {
    $poSet[$r['po_id']] = true;
    $totValue += $r['subtotal'];
    $totOrd += $r['ordered'];
    $totRecv += $r['received'];
    $totRej += $r['rejected'];
    if ($r['track_status'] === 'SELESAI') $done++;
}

$extra = [
    'q' => '<input type="text" name="q" class="form-control" style="max-width:230px;" placeholder="Cari PO / vendor / item..." value="' . h($q) . '">',
    'status' => '<select name="status" class="form-control" style="max-width:190px;"><option value="">Semua Status</option>'
        . implode('', array_map(function ($k) use ($stFilter) {
            [$lbl] = report_track_status_meta($k);
            return '<option value="' . $k . '"' . ($stFilter === $k ? ' selected' : '') . '>' . h($lbl) . '</option>';
        }, ['BELUM', 'PARSIAL', 'SELESAI', 'REJECT'])) . '</select>',
];
?>
<div class="card">
  <div class="card-header">
    <div>
      <h1 class="card-title" style="font-size:18px;">Order Tracking</h1>
      <div style="font-size:12px;color:#64748b;">
        Periode <strong><?= h($period['label']) ?></strong> &middot; Pelacakan setiap baris PO/WO sampai penerimaan barang/jasa (FTB).
      </div>
    </div>
    <?php report_head_actions('order_tracking', $user, false); ?>
  </div>

  <?php report_nav_tabs('order_tracking'); ?>
  <?php report_filter_bar('order_tracking', $period, $extra); ?>

  <div class="kpi-grid" style="margin-bottom:16px;">
    <div class="kpi-card">
      <div class="kpi-label">PO / WO</div>
      <div class="kpi-value" style="font-size:20px;color:#007AB3;"><?= count($poSet) ?> <span style="font-size:13px;color:#64748b;font-weight:600;">(<?= count($rows) ?> item)</span></div>
      <div class="kpi-sub"><?= $done ?> item sudah diterima lengkap</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Total Value</div>
      <div class="kpi-value" style="font-size:20px;color:#0f172a;"><?= rupiah($totValue) ?></div>
      <div class="kpi-sub">Sebelum PPN/ongkir</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Received vs Order</div>
      <div class="kpi-value" style="font-size:20px;color:#008A3B;"><?= $totOrd > 0 ? fmt_pct($totRecv / $totOrd * 100) : '-' ?></div>
      <div class="kpi-sub">Reject: <strong><?= fmt_qty($totRej) ?></strong> unit</div>
    </div>
  </div>

  <div class="table-wrap">
    <table class="rpt-table">
      <thead>
        <tr>
          <th style="width:44px;">No</th>
          <th style="min-width:190px;">PO / WO number</th>
          <th style="min-width:190px;">Vendor name</th>
          <th style="min-width:250px;">Detail Items/Services</th>
          <th style="min-width:90px;">Order Qty</th>
          <th style="min-width:130px;">Total Value</th>
          <th style="min-width:90px;">Received Qty</th>
          <th style="min-width:90px;">Reject Qty</th>
          <th style="min-width:130px;">Status</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($rows)): ?>
          <tr><td colspan="9" style="text-align:center;color:#64748b;padding:22px;">Belum ada PO/WO pada periode dan filter ini.</td></tr>
        <?php endif; ?>
        <?php $lastPo = null; foreach ($rows as $i => $r):
          [$sl, $sb] = report_track_status_meta($r['track_status']);
          $first = $lastPo !== $r['po_id'];
          $lastPo = $r['po_id'];
        ?>
          <tr class="<?= $first ? 'rpt-po-start' : '' ?>">
            <td style="text-align:center;"><?= $i + 1 ?></td>
            <td>
              <?php if ($first): ?>
                <a href="index.php?page=print_po&id=<?= (int)$r['po_id'] ?>" target="_blank" style="font-weight:700;color:#007AB3;"><?= h($r['po_no']) ?></a>
                <div class="sub"><?= h($r['order_type'] === 'WORK ORDER' ? 'Work Order' : 'Purchase Order') ?> &middot; <?= h(tgl_indo($r['po_date'])) ?></div>
              <?php else: ?>
                <span class="sub">&uarr; <?= h($r['po_no']) ?></span>
              <?php endif; ?>
            </td>
            <td><?= $first ? h($r['vendor_name']) : '' ?></td>
            <td><?= h($r['nama_barang_jasa']) ?></td>
            <td class="num"><?= fmt_qty($r['ordered']) ?> <span class="sub"><?= h($r['satuan']) ?></span></td>
            <td class="num"><?= fmt_idr($r['subtotal']) ?></td>
            <td class="num"><?= fmt_qty($r['received']) ?></td>
            <td class="num <?= $r['rejected'] > 0 ? 'rpt-bad' : '' ?>"><?= fmt_qty($r['rejected']) ?></td>
            <td><span class="badge <?= $sb ?>"><?= h($sl) ?></span></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
      <?php if (!empty($rows)): ?>
      <tfoot>
        <tr class="rpt-group">
          <td colspan="5" style="text-align:right;font-weight:700;">Total</td>
          <td class="num"><?= fmt_idr($totValue) ?></td>
          <td class="num"><?= fmt_qty($totRecv) ?></td>
          <td class="num"><?= fmt_qty($totRej) ?></td>
          <td></td>
        </tr>
      </tfoot>
      <?php endif; ?>
    </table>
  </div>
  <div class="rpt-foot">
    Received &amp; Reject Qty diambil dari Form Terima Barang/Jasa (FTB) yang terhubung ke PO/WO tersebut. Status &quot;Belum Diterima&quot; berarti belum ada FTB.
  </div>
</div>
