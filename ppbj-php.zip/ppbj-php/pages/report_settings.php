<?php
report_guard($user);
if (!report_can_edit($user)) {
    set_flash('Hanya Procurement dan Admin yang dapat mengubah target & parameter laporan.', 'error');
    redirect_to('index.php?page=cost_saving');
}

$year = (int)($_GET['tahun'] ?? $_POST['tahun'] ?? date('Y'));
if ($year < 2000 || $year > 2100) $year = (int)date('Y');
$monthRaw = $_GET['bulan'] ?? $_POST['bulan'] ?? '';
$month = ($monthRaw === '' || $monthRaw === null) ? 0 : max(0, min(12, (int)$monthRaw));
$periode = $month > 0 ? sprintf('%04d-%02d', $year, $month) : (string)$year;
$selfUrl = 'index.php?page=report_settings&tahun=' . $year . '&bulan=' . ($month ?: '');

$targetKeys = array_merge(report_categories(), ['__COST_AVOIDANCE']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdo->beginTransaction();
        if (($_POST['action'] ?? '') === 'save_targets') {
            $up = $pdo->prepare(
                "INSERT INTO saving_targets (periode, kategori, target_amount) VALUES (?, ?, ?)
                 ON DUPLICATE KEY UPDATE target_amount = VALUES(target_amount)"
            );
            $del = $pdo->prepare("DELETE FROM saving_targets WHERE periode = ? AND kategori = ?");
            foreach ($targetKeys as $i => $key) {
                $raw = trim((string)($_POST['target'][$i] ?? ''));
                $val = (float)str_replace(['.', ' '], '', str_replace(',', '.', $raw === '' ? '0' : preg_replace('/[^\d,.\-]/', '', $raw)));
                if ($val > 0) {
                    $up->execute([$periode, $key, $val]);
                } else {
                    $del->execute([$periode, $key]);
                }
            }
            set_flash('Target saving periode ' . $periode . ' berhasil disimpan.');
        } elseif (($_POST['action'] ?? '') === 'save_params') {
            $allowed = array_keys(report_default_settings());
            $up = $pdo->prepare(
                "INSERT INTO report_settings (skey, svalue) VALUES (?, ?) ON DUPLICATE KEY UPDATE svalue = VALUES(svalue)"
            );
            foreach ($allowed as $k) {
                if (!isset($_POST['p'][$k])) continue;
                $v = trim((string)$_POST['p'][$k]);
                if ($k === 'sla_start_basis') {
                    $v = $v === 'REQUEST_DATE' ? 'REQUEST_DATE' : 'FINAL_APPROVAL';
                } else {
                    $v = (string)max(0, (float)str_replace(',', '.', $v));
                }
                $up->execute([$k, $v]);
            }
            set_flash('Parameter KPI & compliance berhasil disimpan.');
        }
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        set_flash('Gagal menyimpan: ' . $e->getMessage(), 'error');
    }
    redirect_to($selfUrl);
}

$current = report_targets_exact($pdo, $periode);
$settings = [];
foreach (array_keys(report_default_settings()) as $k) {
    $settings[$k] = report_setting($pdo, $k);
}
$names = report_month_names();
$cur = (int)date('Y');
?>
<div class="card">
  <div class="card-header">
    <div>
      <h1 class="card-title" style="font-size:18px;">Target &amp; Parameter Laporan Procurement</h1>
      <div style="font-size:12px;color:#64748b;">Dipakai pada menu Cost Saving &amp; KPI dan Vendor &amp; Compliance.</div>
    </div>
    <a href="index.php?page=cost_saving" class="btn btn-outline btn-sm">&larr; Kembali ke Laporan</a>
  </div>

  <form method="get" class="rpt-filter">
    <input type="hidden" name="page" value="report_settings">
    <span class="rpt-filter-label">Target untuk:</span>
    <select name="bulan" class="form-control" style="max-width:190px;">
      <option value="" <?= $month === 0 ? 'selected' : '' ?>>Setahun (target tahunan)</option>
      <?php foreach ($names as $n => $nm): ?><option value="<?= $n ?>" <?= $month === $n ? 'selected' : '' ?>><?= h($nm) ?></option><?php endforeach; ?>
    </select>
    <select name="tahun" class="form-control" style="max-width:110px;">
      <?php for ($y = $cur + 1; $y >= $cur - 5; $y--): ?><option value="<?= $y ?>" <?= $year === $y ? 'selected' : '' ?>><?= $y ?></option><?php endfor; ?>
    </select>
    <button type="submit" class="btn btn-primary btn-sm">Tampilkan</button>
  </form>

  <form method="post">
    <input type="hidden" name="action" value="save_targets">
    <input type="hidden" name="tahun" value="<?= $year ?>">
    <input type="hidden" name="bulan" value="<?= $month ?: '' ?>">
    <h2 class="card-title" style="margin-bottom:6px;">Target Saving &amp; Cost Avoidance (IDR) &mdash; periode <?= h($periode) ?></h2>
    <div style="font-size:12px;color:#64748b;margin-bottom:10px;">
      Jika target bulanan kosong, laporan memakai target tahunan &divide; 12. Jika laporan setahun dan target tahunan kosong, laporan memakai jumlah target bulanan. Isi 0/kosong untuk menghapus.
    </div>
    <div class="grid-3">
      <?php foreach ($targetKeys as $i => $key): ?>
        <div class="form-group">
          <label class="form-label"><?= h($key === '__COST_AVOIDANCE' ? 'Cost Avoidance' : $key) ?></label>
          <input type="text" inputmode="numeric" name="target[<?= $i ?>]" class="form-control" placeholder="0"
                 value="<?= isset($current[$key]) ? h(number_format($current[$key], 0, ',', '.')) : '' ?>">
        </div>
      <?php endforeach; ?>
    </div>
    <div style="text-align:right;"><button type="submit" class="btn btn-primary">Simpan Target</button></div>
  </form>
</div>

<div class="card">
  <form method="post">
    <input type="hidden" name="action" value="save_params">
    <input type="hidden" name="tahun" value="<?= $year ?>">
    <input type="hidden" name="bulan" value="<?= $month ?: '' ?>">
    <h2 class="card-title" style="margin-bottom:10px;">Parameter KPI &amp; Compliance</h2>
    <div class="grid-3">
      <div class="form-group"><label class="form-label">Target On-Time Delivery (%)</label>
        <input type="number" step="0.1" min="0" max="100" name="p[target_otd_pct]" class="form-control" value="<?= h((string)$settings['target_otd_pct']) ?>"></div>
      <div class="form-group"><label class="form-label">Target Order Accuracy (%)</label>
        <input type="number" step="0.1" min="0" max="100" name="p[target_accuracy_pct]" class="form-control" value="<?= h((string)$settings['target_accuracy_pct']) ?>"></div>
      <div class="form-group"><label class="form-label">Target PO dalam SLA (%)</label>
        <input type="number" step="0.1" min="0" max="100" name="p[target_sla_pct]" class="form-control" value="<?= h((string)$settings['target_sla_pct']) ?>"></div>
      <div class="form-group"><label class="form-label">SLA PR &rarr; PO (hari kalender)</label>
        <input type="number" step="1" min="0" name="p[sla_pr_po_days]" class="form-control" value="<?= h((string)$settings['sla_pr_po_days']) ?>"></div>
      <div class="form-group"><label class="form-label">SLA dihitung sejak</label>
        <select name="p[sla_start_basis]" class="form-control">
          <option value="FINAL_APPROVAL" <?= $settings['sla_start_basis'] === 'FINAL_APPROVAL' ? 'selected' : '' ?>>Persetujuan final PPBJ (Dir. Keuangan)</option>
          <option value="REQUEST_DATE" <?= $settings['sla_start_basis'] === 'REQUEST_DATE' ? 'selected' : '' ?>>Tanggal PPBJ dibuat</option>
        </select></div>
      <div class="form-group"><label class="form-label">Batas nilai transaksi wajib komparasi (Rp)</label>
        <input type="number" step="1" min="0" name="p[compliance_threshold]" class="form-control" value="<?= h((string)(int)$settings['compliance_threshold']) ?>"></div>
      <div class="form-group"><label class="form-label">Minimal jumlah penawaran</label>
        <input type="number" step="1" min="1" name="p[compliance_min_quotes]" class="form-control" value="<?= h((string)(int)$settings['compliance_min_quotes']) ?>"></div>
      <div class="form-group"><label class="form-label">Vendor Top Performing: OTD minimal (%)</label>
        <input type="number" step="0.1" min="0" max="100" name="p[top_vendor_min_otd]" class="form-control" value="<?= h((string)$settings['top_vendor_min_otd']) ?>"></div>
      <div class="form-group"><label class="form-label">Vendor Under Watch: OTD di bawah (%)</label>
        <input type="number" step="0.1" min="0" max="100" name="p[watch_otd_below]" class="form-control" value="<?= h((string)$settings['watch_otd_below']) ?>"></div>
    </div>
    <div style="text-align:right;"><button type="submit" class="btn btn-primary">Simpan Parameter</button></div>
  </form>
</div>
