<?php
$editId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$existing = null;
$existingItems = [];

if ($editId > 0) {
    $stmt = $pdo->prepare("SELECT * FROM ppbj_requests WHERE id = ?");
    $stmt->execute([$editId]);
    $existing = $stmt->fetch();
    if ($existing) {
        if ($user['role'] === 'PEMOHON' && (int)$existing['user_id'] !== (int)$user['id']) {
            set_flash('Anda tidak memiliki akses untuk mengedit PPBJ milik user lain.', 'error');
            redirect_to('index.php?page=ppbj_list');
        }
        $stmt2 = $pdo->prepare("SELECT * FROM ppbj_items WHERE ppbj_id = ? ORDER BY item_no ASC");
        $stmt2->execute([$editId]);
        $existingItems = $stmt2->fetchAll();
    }
}

$divisions = $pdo->query("SELECT * FROM divisions WHERE aktif = 1 ORDER BY id ASC")->fetchAll();
$divById = [];
$divMetaMap = [];
foreach ($divisions as $d) {
    $did = (int)$d['id'];
    $divById[$did] = $d;
    $divMetaMap[$did] = [
        'kode' => $d['kode_divisi'],
        'nama' => $d['nama_divisi'],
        'lokasi' => $d['lokasi_default'],
        'next_no' => next_ppbj_no($pdo, $d['kode_divisi']),
    ];
}

$isPemohonFixedDiv = ($user['role'] === 'PEMOHON');
$fixedDivId = (int)($user['division_id'] ?? 0);
if ($isPemohonFixedDiv && ($fixedDivId <= 0 || !isset($divById[$fixedDivId]))) {
    echo '<div class="card"><div class="flash flash-error">Divisi akun Anda belum ditetapkan atau tidak aktif. Silakan hubungi <strong>Super Admin</strong> untuk menetapkan divisi tetap pada akun Anda.</div><a href="index.php?page=ppbj_list" class="btn btn-outline btn-sm">&larr; Kembali</a></div>';
    return;
}

// Pilih default divisi: jika Pemohon terkunci ke divisi tetapnya; jika non-Pemohon bisa memilih
$defaultDivId = 0;
if ($isPemohonFixedDiv) {
    $defaultDivId = $fixedDivId;
} elseif ($existing && !empty($existing['division_id']) && isset($divById[(int)$existing['division_id']])) {
    $defaultDivId = (int)$existing['division_id'];
} else {
    foreach ($divisions as $d) {
        if (stripos($user['divisi'] ?? '', $d['kode_divisi']) !== false || stripos($d['nama_divisi'], $user['divisi'] ?? '') !== false) {
            $defaultDivId = (int)$d['id'];
            break;
        }
    }
    if ($defaultDivId === 0 && !empty($divisions)) {
        $defaultDivId = (int)$divisions[0]['id'];
    }
}

$defaultDivCode = $defaultDivId > 0 ? $divById[$defaultDivId]['kode_divisi'] : 'OIT';
$defaultReqNo = $existing ? $existing['request_no'] : next_ppbj_no($pdo, $defaultDivCode);
$defaultReqDate = $existing['request_date'] ?? date('Y-m-d');
$defaultRecDate = $existing['received_date'] ?? date('Y-m-d', strtotime('+10 days'));
$defaultLoc = $existing['delivery_location'] ?? ($defaultDivId > 0 ? $divById[$defaultDivId]['lokasi_default'] : 'Dusun Pintu Rimba Glee Siblah Woyla Aceh');
$defaultApplied = $existing['applied_by_name'] ?? $user['nama_lengkap'];
$selectedTypes = $existing ? array_map('trim', explode(',', $existing['request_types'])) : ['4. Suku cadang'];

if (empty($existingItems)) {
    $existingItems = [[
        'jumlah' => 1,
        'satuan' => 'Unit',
        'no_anggaran' => '',
        'kategori_pengadaan' => '',
        'nama_barang_jasa' => '',
        'peruntukan' => '',
        'foto_path' => '',
        'harga_unit' => 0,
        'harga_anggaran' => 0,
    ]];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postDivId = $isPemohonFixedDiv ? $fixedDivId : (int)($_POST['division_id'] ?? 0);
    $divRow = $divById[$postDivId] ?? null;
    if (!$divRow && $postDivId > 0) {
        $dSt = $pdo->prepare("SELECT * FROM divisions WHERE id = ?");
        $dSt->execute([$postDivId]);
        $divRow = $dSt->fetch();
    }

    $requestDate = $_POST['request_date'] ?: date('Y-m-d');
    $receivedDate = $_POST['received_date'] ?: null;
    $location = trim($_POST['delivery_location'] ?? '');
    $reqTypesArr = $_POST['request_types'] ?? [];
    $reqTypesStr = !empty($reqTypesArr) ? implode(', ', $reqTypesArr) : '6. Lain-lain';
    $catatan = trim($_POST['catatan_umum'] ?? '');
    $appliedBy = trim($_POST['applied_by_name'] ?? $user['nama_lengkap']);
    $submitMode = ($_POST['submit_mode'] ?? 'submit') === 'draft' ? 'DRAFT' : 'MENUNGGU_MANAGER';

    $names = $_POST['item_nama'] ?? [];
    $qtys = $_POST['item_jumlah'] ?? [];
    $units = $_POST['item_satuan'] ?? [];
    $budgets = $_POST['item_anggaran'] ?? [];
    $purposes = $_POST['item_peruntukan'] ?? [];
    $prices = $_POST['item_harga'] ?? [];
    $oldPhotos = $_POST['item_old_foto'] ?? [];
    $kategoris = $_POST['item_kategori'] ?? [];
    $validKategori = array_flip(report_categories());

    $itemsToInsert = [];
    for ($i = 0; $i < count($names); $i++) {
        $nm = trim($names[$i] ?? '');
        if ($nm === '') continue;
        $qty = max(0.01, (float)($qtys[$i] ?? 1));
        $unit = trim($units[$i] ?? 'Unit') ?: 'Unit';
        $noAng = trim($budgets[$i] ?? '');
        $peruntukan = trim($purposes[$i] ?? '');
        $hargaUnit = max(0, (float)($prices[$i] ?? 0));
        $hargaAnggaran = $qty * $hargaUnit;
        $kategori = trim((string)($kategoris[$i] ?? ''));
        if (!isset($validKategori[$kategori])) {
            $kategori = report_guess_category($nm) ?? '';
        }

        $fotoPath = $oldPhotos[$i] ?? null;
        if (isset($_FILES['item_foto']['tmp_name'][$i]) && $_FILES['item_foto']['error'][$i] === UPLOAD_ERR_OK) {
            $ext = strtolower(pathinfo($_FILES['item_foto']['name'][$i], PATHINFO_EXTENSION));
            if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif'], true)) {
                $newName = 'item_' . time() . '_' . $i . '_' . bin2hex(random_bytes(3)) . '.' . $ext;
                $dest = __DIR__ . '/../uploads/' . $newName;
                if (move_uploaded_file($_FILES['item_foto']['tmp_name'][$i], $dest)) {
                    $fotoPath = 'uploads/' . $newName;
                }
            }
        }

        $itemsToInsert[] = [
            'item_no' => count($itemsToInsert) + 1,
            'jumlah' => $qty,
            'satuan' => $unit,
            'no_anggaran' => $noAng,
            'kategori_pengadaan' => $kategori !== '' ? $kategori : null,
            'nama_barang_jasa' => $nm,
            'peruntukan' => $peruntukan,
            'foto_path' => $fotoPath,
            'harga_unit' => $hargaUnit,
            'harga_anggaran' => $hargaAnggaran,
        ];
    }

    if (!$divRow || empty($itemsToInsert)) {
        set_flash('Pilih Divisi dan isi minimal 1 item barang/jasa.', 'error');
    } else {
        try {
            $pdo->beginTransaction();
            $divCode = normalize_div_code($divRow['kode_divisi']);
            $division = $divRow['nama_divisi'];

            if ($editId > 0 && $existing) {
                // Jika divisi berubah saat edit, buatkan nomor otomatis sesuai divisi barunya; jika sama, pertahankan nomor lama
                $requestNo = ((int)$existing['division_id'] === $postDivId)
                    ? $existing['request_no']
                    : next_ppbj_no($pdo, $divCode);

                $upd = $pdo->prepare(
                    "UPDATE ppbj_requests SET
                        request_no = ?, request_date = ?, received_date = ?,
                        division_id = ?, division_code = ?, division_subdivision = ?,
                        delivery_location = ?, request_types = ?, catatan_umum = ?,
                        applied_by_name = ?, applied_by_date = ?, status = ?
                     WHERE id = ?"
                );
                $upd->execute([
                    $requestNo, $requestDate, $receivedDate,
                    $postDivId, $divCode, $division,
                    $location, $reqTypesStr, $catatan,
                    $appliedBy, $requestDate, $submitMode, $editId
                ]);
                $pdo->prepare("DELETE FROM ppbj_items WHERE ppbj_id = ?")->execute([$editId]);
                $ppbjId = $editId;
                $logAction = $submitMode === 'DRAFT' ? 'Memperbarui Draft PPBJ' : 'Revisi & Mengajukan Ulang ke Manager';
            } else {
                // Penomoran otomatis per divisi langsung di server!
                $requestNo = next_ppbj_no($pdo, $divCode);

                $ins = $pdo->prepare(
                    "INSERT INTO ppbj_requests (
                        request_no, request_date, received_date,
                        division_id, division_code, division_subdivision,
                        delivery_location, request_types, catatan_umum, user_id,
                        applied_by_name, applied_by_date, status
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
                );
                $ins->execute([
                    $requestNo, $requestDate, $receivedDate,
                    $postDivId, $divCode, $division,
                    $location, $reqTypesStr, $catatan, (int)$user['id'],
                    $appliedBy, $requestDate, $submitMode
                ]);
                $ppbjId = (int)$pdo->lastInsertId();
                $logAction = $submitMode === 'DRAFT' ? 'Menyimpan Draft PPBJ' : 'Mengajukan PPBJ ke Atasan / Manager';
            }

            $insItem = $pdo->prepare(
                "INSERT INTO ppbj_items (ppbj_id, item_no, jumlah, satuan, no_anggaran, kategori_pengadaan, nama_barang_jasa, peruntukan, foto_path, harga_unit, harga_anggaran)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
            );
            foreach ($itemsToInsert as $it) {
                $insItem->execute([
                    $ppbjId, $it['item_no'], $it['jumlah'], $it['satuan'], $it['no_anggaran'], $it['kategori_pengadaan'],
                    $it['nama_barang_jasa'], $it['peruntukan'], $it['foto_path'], $it['harga_unit'], $it['harga_anggaran']
                ]);
            }

            $insLog = $pdo->prepare(
                "INSERT INTO ppbj_logs (ppbj_id, actor_name, actor_role, aksi, catatan) VALUES (?, ?, ?, ?, ?)"
            );
            $insLog->execute([
                $ppbjId, $appliedBy, role_label($user['role']), $logAction,
                "Divisi: {$division} (PBS-{$divCode}) | No: {$requestNo}"
            ]);

            $pdo->commit();
            set_flash("Form PPBJ {$requestNo} berhasil disimpan (otomatis per divisi {$divCode}).");
            redirect_to("index.php?page=ppbj_detail&id={$ppbjId}");
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            set_flash('Gagal menyimpan PPBJ: ' . $e->getMessage(), 'error');
        }
    }
}
?>

<form method="post" enctype="multipart/form-data">
  <div class="card">
    <div class="card-header">
      <div>
        <h1 class="card-title" style="font-size:18px;">
          <?= $editId > 0 ? 'Edit Form PPBJ (' . h($defaultReqNo) . ')' : 'Ajukan Permintaan Pengadaan Barang/Jasa (PPBJ)' ?>
        </h1>
        <div style="font-size:12px;color:#64748b;">
          Nomor Dokumen: <strong>FRM.APR.01.00</strong> | Diajukan oleh: <strong><?= h($user['nama_lengkap']) ?></strong>
        </div>
      </div>
      <div style="display:flex;gap:8px;">
        <?php if ($user['role'] === 'ADMIN'): ?>
          <a href="index.php?page=divisions" class="btn btn-outline btn-sm">Kelola Master Divisi</a>
        <?php endif; ?>
        <a href="index.php?page=ppbj_list" class="btn btn-outline btn-sm">&larr; Kembali</a>
      </div>
    </div>

    <div class="grid-3">
      <div class="form-group">
        <label class="form-label">Permintaan / Request No. <span class="badge badge-blue" style="font-size:10px;margin-left:4px;">Otomatis per Divisi</span></label>
        <input type="text" name="request_no" id="requestNoInput" class="form-control" readonly
               style="background:#f8fafc;font-weight:700;color:#007AB3;cursor:not-allowed;"
               value="<?= h($defaultReqNo) ?>">
        <div style="font-size:11px;color:#64748b;margin-top:4px;">Nomor terisi otomatis mengikuti urutan masing-masing divisi.</div>
      </div>
      <div class="form-group">
        <label class="form-label">Tanggal / Date *</label>
        <input type="date" name="request_date" class="form-control" required value="<?= h($defaultReqDate) ?>">
      </div>
      <div class="form-group">
        <label class="form-label">Tanggal Penerimaan / Received Date</label>
        <input type="date" name="received_date" class="form-control" value="<?= h($defaultRecDate) ?>">
      </div>
    </div>

    <div class="grid-2">
      <div class="form-group">
        <label class="form-label">
          Divisi &amp; Sub Divisi / Division &amp; Sub Division *
          <?php if ($isPemohonFixedDiv): ?>
            <span class="badge badge-green" style="font-size:10px;margin-left:4px;">Ditetapkan Super Admin</span>
          <?php endif; ?>
        </label>
        <?php if ($isPemohonFixedDiv): ?>
          <input type="hidden" name="division_id" value="<?= $fixedDivId ?>">
          <input type="text" class="form-control" readonly style="background:#f8fafc;font-weight:700;color:#0f172a;cursor:not-allowed;"
                 value="<?= h($divById[$fixedDivId]['nama_divisi']) ?> (PBS-<?= h($divById[$fixedDivId]['kode_divisi']) ?>)">
          <div style="font-size:11px;color:#0369a1;margin-top:4px;">Divisi Anda dikunci ke <strong><?= h($divById[$fixedDivId]['nama_divisi']) ?></strong> oleh Super Admin.</div>
        <?php else: ?>
          <select name="division_id" id="divisionSelect" class="form-control" required onchange="onDivisionChange()">
            <?php if (empty($divisions)): ?>
              <option value="">-- Belum ada divisi aktif (Hubungi Super Admin) --</option>
            <?php else: foreach ($divisions as $d): ?>
              <option value="<?= (int)$d['id'] ?>" <?= $defaultDivId === (int)$d['id'] ? 'selected' : '' ?>>
                <?= h($d['nama_divisi']) ?> (PBS-<?= h($d['kode_divisi']) ?>)
              </option>
            <?php endforeach; endif; ?>
          </select>
          <div style="font-size:11px;color:#64748b;margin-top:4px;">Daftar divisi dikelola oleh <strong>Super Admin</strong> di menu <em>Master Divisi</em>.</div>
        <?php endif; ?>
      </div>
      <div class="form-group">
        <label class="form-label">Lokasi Pengiriman / Delivery Location *</label>
        <input type="text" name="delivery_location" id="locationInput" class="form-control" required value="<?= h($defaultLoc) ?>">
      </div>
    </div>

    <div class="form-group">
      <label class="form-label">Jenis Permintaan / Type of Request</label>
      <div class="check-grid">
        <?php foreach (PPBJ_REQUEST_TYPES as $indo => $eng): ?>
          <label class="check-card">
            <input type="checkbox" name="request_types[]" value="<?= h($indo) ?>" <?= in_array($indo, $selectedTypes, true) ? 'checked' : '' ?>>
            <div>
              <strong><?= h($indo) ?></strong><br>
              <span style="color:#64748b;font-size:11px;"><?= h($eng) ?></span>
            </div>
          </label>
        <?php endforeach; ?>
      </div>
    </div>

    <div class="grid-2">
      <div class="form-group">
        <label class="form-label">Pemohon (Applied by) *</label>
        <input type="text" name="applied_by_name" class="form-control" required value="<?= h($defaultApplied) ?>">
      </div>
      <div class="form-group">
        <label class="form-label">Catatan / Lampiran Spesifikasi Barang/Jasa</label>
        <input type="text" name="catatan_umum" class="form-control" value="<?= h($existing['catatan_umum'] ?? 'Lampirkan SPESIFIKASI BARANG/JASA') ?>">
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header">
      <div>
        <h2 class="card-title">Daftar Barang / Jasa &amp; Peruntukan</h2>
        <div style="font-size:12px;color:#64748b;">Isi rincian item, nomor anggaran, peruntukan, harga satuan, serta foto spesifikasi (opsional).</div>
      </div>
      <button type="button" onclick="addItemRow()" class="btn btn-green btn-sm">+ Tambah Baris Item</button>
    </div>

    <div class="table-wrap">
      <table class="data-table">
        <thead>
          <tr>
            <th style="width:40px;">No</th>
            <th style="width:80px;">Jumlah</th>
            <th style="width:90px;">Satuan</th>
            <th style="width:110px;">No. Anggr</th>
            <th style="width:200px;">Kategori</th>
            <th style="min-width:210px;">Nama Barang/Jasa *</th>
            <th style="min-width:180px;">Peruntukan</th>
            <th style="width:140px;">Harga/Unit (Rp)</th>
            <th style="width:150px;text-align:right;">Harga Anggaran</th>
            <th style="width:140px;">Foto Spesifikasi</th>
            <th style="width:50px;"></th>
          </tr>
        </thead>
        <tbody id="itemsBody">
          <?php foreach ($existingItems as $idx => $it): ?>
          <tr class="item-row">
            <td class="row-num" style="font-weight:700;text-align:center;"><?= $idx + 1 ?></td>
            <td><input type="number" step="0.01" min="0.01" name="item_jumlah[]" class="form-control qty-input" value="<?= h((string)$it['jumlah']) ?>" oninput="recalcAll()"></td>
            <td><input type="text" name="item_satuan[]" class="form-control" value="<?= h($it['satuan']) ?>" placeholder="Unit/PCS"></td>
            <td><input type="text" name="item_anggaran[]" class="form-control" value="<?= h($it['no_anggaran']) ?>" placeholder="ANG-01"></td>
            <td>
              <select name="item_kategori[]" class="form-control">
                <option value="">Otomatis / pilih...</option>
                <?php foreach (report_categories() as $catOpt): ?>
                  <option value="<?= h($catOpt) ?>" <?= ($it['kategori_pengadaan'] ?? '') === $catOpt ? 'selected' : '' ?>><?= h($catOpt) ?></option>
                <?php endforeach; ?>
              </select>
            </td>
            <td><input type="text" name="item_nama[]" class="form-control" required value="<?= h($it['nama_barang_jasa']) ?>" placeholder="Nama &amp; merek/spesifikasi"></td>
            <td><input type="text" name="item_peruntukan[]" class="form-control" value="<?= h($it['peruntukan']) ?>" placeholder="Keperluan/user"></td>
            <td><input type="number" step="100" min="0" name="item_harga[]" class="form-control price-input" value="<?= h((string)$it['harga_unit']) ?>" oninput="recalcAll()"></td>
            <td class="row-total" style="text-align:right;font-weight:700;white-space:nowrap;"><?= rupiah($it['harga_anggaran']) ?></td>
            <td>
              <input type="hidden" name="item_old_foto[]" value="<?= h($it['foto_path'] ?? '') ?>">
              <input type="file" name="item_foto[]" accept="image/*" style="font-size:11px;max-width:135px;">
              <?php if (!empty($it['foto_path'])): ?>
                <div style="font-size:11px;color:#008A3B;margin-top:2px;">Foto tersimpan</div>
              <?php endif; ?>
            </td>
            <td><button type="button" onclick="removeRow(this)" class="btn btn-outline btn-sm" style="color:#dc2626;">&times;</button></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
        <tfoot>
          <tr style="background:#f8fafc;">
            <td colspan="8" style="text-align:right;font-weight:800;font-size:14px;">T O T A L</td>
            <td id="grandTotal" style="text-align:right;font-weight:800;font-size:15px;color:#007AB3;white-space:nowrap;">Rp 0</td>
            <td colspan="2"></td>
          </tr>
        </tfoot>
      </table>
    </div>

    <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:20px;flex-wrap:wrap;">
      <button type="submit" name="submit_mode" value="draft" class="btn btn-outline">Simpan sebagai Draft</button>
      <button type="submit" name="submit_mode" value="submit" class="btn btn-primary">Ajukan ke Atasan / Manager</button>
    </div>
  </div>
</form>

<script>
const divMetaMap = <?= json_encode($divMetaMap, JSON_UNESCAPED_UNICODE) ?>;
const CATEGORY_OPTIONS = '<option value="">Otomatis / pilih...</option>' + <?= json_encode(array_map(fn($c) => '<option value="' . h($c) . '">' . h($c) . '</option>', report_categories()), JSON_UNESCAPED_UNICODE) ?>.join('');
const isEditMode = <?= $editId > 0 ? 'true' : 'false' ?>;
const origDivId = <?= $existing ? (int)($existing['division_id'] ?? 0) : 0 ?>;
const origReqNo = <?= json_encode($existing['request_no'] ?? '') ?>;
let locationDirty = false;
document.getElementById('locationInput').addEventListener('input', () => { locationDirty = true; });

function onDivisionChange() {
  const sel = document.getElementById('divisionSelect');
  const did = sel.value;
  const meta = divMetaMap[did];
  if (!meta) return;
  const reqInput = document.getElementById('requestNoInput');
  if (isEditMode && parseInt(did, 10) === origDivId && origReqNo) {
    reqInput.value = origReqNo;
  } else {
    reqInput.value = meta.next_no;
  }
  if (!locationDirty && !isEditMode && meta.lokasi) {
    document.getElementById('locationInput').value = meta.lokasi;
  }
}

function formatRp(val) {
  return 'Rp ' + Math.round(val).toLocaleString('id-ID');
}
function recalcAll() {
  let grand = 0;
  document.querySelectorAll('#itemsBody .item-row').forEach((row, idx) => {
    row.querySelector('.row-num').textContent = idx + 1;
    const q = parseFloat(row.querySelector('.qty-input').value || 0);
    const p = parseFloat(row.querySelector('.price-input').value || 0);
    const sub = q * p;
    grand += sub;
    row.querySelector('.row-total').textContent = formatRp(sub);
  });
  document.getElementById('grandTotal').textContent = formatRp(grand);
}
function addItemRow() {
  const tbody = document.getElementById('itemsBody');
  const idx = tbody.querySelectorAll('.item-row').length + 1;
  const tr = document.createElement('tr');
  tr.className = 'item-row';
  tr.innerHTML = `
    <td class="row-num" style="font-weight:700;text-align:center;">${idx}</td>
    <td><input type="number" step="0.01" min="0.01" name="item_jumlah[]" class="form-control qty-input" value="1" oninput="recalcAll()"></td>
    <td><input type="text" name="item_satuan[]" class="form-control" value="Unit" placeholder="Unit/PCS"></td>
    <td><input type="text" name="item_anggaran[]" class="form-control" placeholder="ANG-01"></td>
    <td><select name="item_kategori[]" class="form-control">${CATEGORY_OPTIONS}</select></td>
    <td><input type="text" name="item_nama[]" class="form-control" required placeholder="Nama & merek/spesifikasi"></td>
    <td><input type="text" name="item_peruntukan[]" class="form-control" placeholder="Keperluan/user"></td>
    <td><input type="number" step="100" min="0" name="item_harga[]" class="form-control price-input" value="0" oninput="recalcAll()"></td>
    <td class="row-total" style="text-align:right;font-weight:700;white-space:nowrap;">Rp 0</td>
    <td>
      <input type="hidden" name="item_old_foto[]" value="">
      <input type="file" name="item_foto[]" accept="image/*" style="font-size:11px;max-width:135px;">
    </td>
    <td><button type="button" onclick="removeRow(this)" class="btn btn-outline btn-sm" style="color:#dc2626;">&times;</button></td>
  `;
  tbody.appendChild(tr);
  recalcAll();
}
function removeRow(btn) {
  const rows = document.querySelectorAll('#itemsBody .item-row');
  if (rows.length <= 1) return;
  btn.closest('tr').remove();
  recalcAll();
}
recalcAll();
</script>
