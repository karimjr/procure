<?php
$readyForBid = $pdo->query(
    "SELECT p.*, COALESCE(SUM(i.harga_anggaran),0) AS total_anggaran, COUNT(i.id) AS jml_item
     FROM ppbj_requests p
     LEFT JOIN ppbj_items i ON i.ppbj_id = p.id
     WHERE p.status = 'SIAP_BID'
     GROUP BY p.id
     ORDER BY p.id DESC"
)->fetchAll();

$bids = $pdo->query(
    "SELECT b.*, p.request_no, p.division_subdivision, p.status AS ppbj_status,
            (SELECT COUNT(*) FROM bid_vendors bv WHERE bv.bid_id = b.id) AS jml_vendor,
            (SELECT COUNT(*) FROM purchase_orders po WHERE po.bid_id = b.id) AS jml_po,
            (SELECT GROUP_CONCAT(po.po_no SEPARATOR ', ') FROM purchase_orders po WHERE po.bid_id = b.id) AS daftar_po,
            (SELECT COUNT(*) FROM ppbj_items pi WHERE pi.ppbj_id = b.ppbj_id AND pi.jalur_pengadaan = 'NON_PO') AS jml_non_po,
            (SELECT COUNT(*) FROM ppbj_items pi WHERE pi.ppbj_id = b.ppbj_id AND pi.jalur_pengadaan = 'NON_PO'
              AND NOT EXISTS (SELECT 1 FROM ftb_items fi WHERE fi.ppbj_item_id = pi.id)) AS sisa_non_po_ftb
     FROM bid_summaries b
     JOIN ppbj_requests p ON b.ppbj_id = p.id
     ORDER BY b.id DESC"
)->fetchAll();
?>

<?php if (!empty($readyForBid)): ?>
<div class="card" style="border-color:#99f6e4;background:#f0fdfa;">
  <div class="card-header" style="border-bottom-color:#99f6e4;">
    <div>
      <h2 class="card-title" style="color:#115e59;">PPBJ Disetujui Final — Siap Dibuatkan Bid Summary</h2>
      <div style="font-size:12px;color:#0f766e;">Bandingkan harga dari beberapa vendor sebelum menerbitkan PO (1 Bid Summary dapat menghasilkan beberapa PO).</div>
    </div>
  </div>
  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th>No. PPBJ</th>
          <th>Divisi &amp; Pemohon</th>
          <th>Jenis Permintaan</th>
          <th>Item</th>
          <th style="text-align:right;">Total Anggaran</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($readyForBid as $r): ?>
          <tr>
            <td><a href="index.php?page=ppbj_detail&id=<?= (int)$r['id'] ?>" style="font-weight:700;color:#007AB3;"><?= h($r['request_no']) ?></a></td>
            <td>
              <div><strong><?= h($r['division_subdivision']) ?></strong></div>
              <div style="font-size:11.5px;color:#64748b;">Pemohon: <?= h($r['applied_by_name']) ?></div>
            </td>
            <td style="font-size:12px;"><?= h($r['request_types']) ?></td>
            <td style="font-weight:700;"><?= (int)$r['jml_item'] ?></td>
            <td style="text-align:right;font-weight:700;"><?= rupiah($r['total_anggaran']) ?></td>
            <td>
              <a href="index.php?page=bid_summary_form&ppbj_id=<?= (int)$r['id'] ?>" class="btn btn-primary btn-sm">
                Buat Bid Summary &rarr;
              </a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<div class="card">
  <div class="card-header">
    <div>
      <h1 class="card-title" style="font-size:18px;">Daftar Bid Summary (Perbandingan Harga Vendor)</h1>
      <div style="font-size:12px;color:#64748b;">Perbandingan penawaran beberapa vendor untuk menentukan pemenang per item &amp; generate PO otomatis.</div>
    </div>
    <a href="index.php?page=bid_summary_form" class="btn btn-primary btn-sm">+ Buat Bid Summary Baru</a>
  </div>

  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th>No. Bid Summary &amp; Tanggal</th>
          <th>Judul &amp; Referensi PPBJ</th>
          <th>Vendor Dibandingkan</th>
          <th>PO Dihasilkan</th>
          <th>Dibuat Oleh</th>
          <th>Status</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($bids)): ?>
          <tr><td colspan="7" style="text-align:center;padding:30px;color:#64748b;">Belum ada Bid Summary.</td></tr>
        <?php else: foreach ($bids as $b): ?>
          <tr>
            <td>
              <strong><?= h($b['bid_no']) ?></strong>
              <div style="font-size:11.5px;color:#64748b;"><?= tgl_indo($b['bid_date']) ?></div>
            </td>
            <td>
              <div style="font-weight:600;"><?= h($b['judul']) ?></div>
              <div style="font-size:12px;color:#007AB3;">Ref: <?= h($b['request_no']) ?> (<?= h($b['division_subdivision']) ?>)</div>
            </td>
            <td style="text-align:center;font-weight:700;"><?= (int)$b['jml_vendor'] ?> Vendor</td>
            <td style="font-size:12px;">
              <?php if ((int)$b['jml_po'] > 0): ?>
                <span class="badge badge-blue"><?= (int)$b['jml_po'] ?> PO</span>
                <div style="color:#1e40af;margin-top:3px;font-weight:600;"><?= h($b['daftar_po']) ?></div>
              <?php endif; ?>
              <?php if ((int)$b['jml_non_po'] > 0): ?>
                <div style="margin-top:3px;"><span class="badge badge-purple"><?= (int)$b['jml_non_po'] ?> Item Non PO</span></div>
              <?php endif; ?>
              <?php if ((int)$b['jml_po'] === 0 && (int)$b['jml_non_po'] === 0): ?>
                <span class="badge badge-amber">Belum Diproses</span>
              <?php endif; ?>
            </td>
            <td style="font-size:12px;"><?= h($b['dibuat_oleh']) ?></td>
            <td><span class="badge <?= $b['status'] === 'FINAL' ? 'badge-green' : 'badge-slate' ?>"><?= h($b['status']) ?></span></td>
            <td style="white-space:nowrap;">
              <a href="index.php?page=bid_summary_form&id=<?= (int)$b['id'] ?>" class="btn btn-primary btn-sm">Buka / Edit</a>
              <?php if ((int)$b['sisa_non_po_ftb'] > 0): ?>
                <a href="index.php?page=ftb_form&nonpo_ppbj_id=<?= (int)$b['ppbj_id'] ?>" class="btn btn-green btn-sm">Isi FTB (Non PO)</a>
              <?php endif; ?>
              <?php if ((int)$b['jml_po'] > 0): ?>
                <a href="index.php?page=po_list&bid_id=<?= (int)$b['id'] ?>" class="btn btn-outline btn-sm">Lihat PO</a>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>
