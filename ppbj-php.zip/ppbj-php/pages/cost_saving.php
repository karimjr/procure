<?php
report_guard($user);
$period = report_period();
$canEdit = report_can_edit($user);
$selfUrl = 'index.php?page=cost_saving&tahun=' . $period['year'] . '&bulan=' . ($period['month'] ?: '');

// ---- Aksi: set kategori item / auto-kategori ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $canEdit) {
    $act = $_POST['action'] ?? '';
    try {
        if ($act === 'set_kategori') {
            $valid = array_flip(report_categories());
            $upd = $pdo->prepare("UPDATE ppbj_items SET kategori_pengadaan = ? WHERE id = ?");
            $n = 0;
            foreach (($_POST['kategori'] ?? []) as $itemId => $kat) {
                $kat = trim((string)$kat);
                if ($kat !== '' && isset($valid[$kat])) {
                    $upd->execute([$kat, (int)$itemId]);
                    $n++;
                }
            }
            set_flash($n > 0 ? "{$n} item berhasil dikategorikan." : 'Tidak ada kategori yang dipilih.', $n > 0 ? 'success' : 'error');
        } elseif ($act === 'autocat') {
            $n = report_autocategorize($pdo);
            set_flash($n > 0 ? "{$n} item dikategorikan otomatis berdasarkan nama barang/jasa. Silakan periksa kembali." : 'Tidak ada item yang bisa ditebak otomatis. Pilih kategori secara manual.', $n > 0 ? 'success' : 'error');
        }
    } catch (Throwable $e) {
        set_flash('Gagal menyimpan kategori: ' . $e->getMessage(), 'error');
    }
    redirect_to($selfUrl);
}

$data = report_cost_saving($pdo, $period);
$rows = $data['rows'];
$tot = $data['totals'];
$caRow = null;
foreach ($rows as $r) {
    if ($r['no'] === '2') { $caRow = $r; }
}

function rpt_pct_class(array $r): string
{
    if ($r['pct'] === null) return '';
    if ($r['kind'] === 'kpi') return $r['pct'] + 0.0001 >= $r['goal'] ? 'rpt-ok' : 'rpt-bad';
    if ($r['pct'] >= 100) return 'rpt-ok';
    return $r['pct'] < 0 ? 'rpt-bad' : 'rpt-warn';
}
?>
<div class="card">
  <div class="card-header">
    <div>
      <h1 class="card-title" style="font-size:18px;">Cost Saving &amp; KPI Procurement</h1>
      <div style="font-size:12px;color:#64748b;">
        Periode <strong><?= h($period['label']) ?></strong> &middot; Sumber data: Procurement Logbook, PO/WO, dan Bid Summary.
      </div>
    </div>
    <?php report_head_actions('cost_saving', $user); ?>
  </div>

  <?php report_nav_tabs('cost_saving'); ?>
  <?php report_filter_bar('cost_saving', $period); ?>

  <div class="kpi-grid" style="margin-bottom:16px;">
    <div class="kpi-card">
      <div class="kpi-label">Total Spent</div>
      <div class="kpi-value" style="font-size:20px;color:#0369a1;"><?= rupiah($tot['spent']) ?></div>
      <div class="kpi-sub"><?= (int)$data['line_count'] ?> baris item PO/WO &amp; Non-PO</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Total Saving (Budget &minus; Realisasi)</div>
      <div class="kpi-value" style="font-size:20px;color:<?= $tot['saving'] >= 0 ? '#008A3B' : '#dc2626' ?>;"><?= ($tot['saving'] < 0 ? '-' : '') . rupiah(abs($tot['saving'])) ?></div>
      <div class="kpi-sub">Budget PPBJ: <?= rupiah($tot['budget']) ?></div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Cost Avoidance</div>
      <div class="kpi-value" style="font-size:20px;color:#6b21a8;"><?= rupiah($caRow['ach'] ?? 0) ?></div>
      <div class="kpi-sub">Dari perbandingan penawaran Bid Summary</div>
    </div>
  </div>

  <div class="table-wrap">
    <table class="rpt-table">
      <thead>
        <tr>
          <th rowspan="2" style="width:44px;">No</th>
          <th rowspan="2" style="min-width:250px;">Key highlight</th>
          <th rowspan="2" style="min-width:130px;">Total spent</th>
          <th rowspan="2" style="min-width:120px;">Target</th>
          <th colspan="2">Achievement</th>
          <th rowspan="2" style="min-width:280px;">Note</th>
        </tr>
        <tr>
          <th style="min-width:120px;">in IDR</th>
          <th style="min-width:80px;">in %</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($rows as $r):
          $cls = rpt_pct_class($r);
          $isGroup = !empty($r['bold']);
        ?>
          <tr class="<?= $isGroup ? 'rpt-group' : '' ?>">
            <td style="text-align:center;"><?= h($r['no']) ?></td>
            <td style="<?= $isGroup ? 'font-weight:700;' : '' ?><?= !empty($r['italic']) ? 'font-style:italic;color:#64748b;' : '' ?>"><?= h($r['label']) ?></td>
            <td class="num"><?= fmt_idr($r['spent']) ?></td>
            <td class="num"><?= $r['target_fmt'] === 'pct' ? '&ge; ' . fmt_pct($r['target'], 0) : fmt_idr($r['target']) ?></td>
            <td class="num <?= ($r['ach'] ?? 0) < 0 ? 'rpt-bad' : '' ?>"><?= $r['ach'] === null ? '-' : fmt_idr($r['ach']) ?></td>
            <td class="num <?= $cls ?>" style="font-weight:700;"><?= fmt_pct($r['pct']) ?></td>
            <td class="note"><?= h($r['note']) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <div class="rpt-foot">
    <strong>Cara hitung.</strong> Total spent = nilai baris PO/WO (sebelum PPN/ongkir) &amp; pemenang Bid Summary jalur Non-PO pada periode.
    Saving = (harga satuan anggaran PPBJ &minus; harga satuan PO) &times; qty. Target &amp; parameter KPI diatur di menu
    <em>Atur Target &amp; Parameter</em>; persentase Achievement = Saving &divide; Target. Warna hijau = target tercapai.
  </div>
</div>

<?php if ($canEdit): ?>
<div class="card no-print">
  <div class="card-header">
    <div>
      <h2 class="card-title">Kategori Item PPBJ</h2>
      <div style="font-size:12px;color:#64748b;">
        Saving per kategori dihitung dari kolom kategori pada item PPBJ.
        <?php if (!empty($data['uncategorized'])): ?>
          Ada <strong><?= count($data['uncategorized']) ?></strong> item pada periode ini yang belum dikategorikan.
        <?php else: ?>
          Semua item pada periode ini sudah memiliki kategori.
        <?php endif; ?>
      </div>
    </div>
    <form method="post" onsubmit="return confirm('Tebak kategori otomatis untuk semua item yang masih kosong?');">
      <input type="hidden" name="action" value="autocat">
      <button type="submit" class="btn btn-outline btn-sm">Tebak Otomatis Semua Item Kosong</button>
    </form>
  </div>

  <?php if (!empty($data['uncategorized'])): ?>
  <form method="post">
    <input type="hidden" name="action" value="set_kategori">
    <div class="table-wrap">
      <table class="data-table">
        <thead><tr><th>Nama Barang / Jasa</th><th style="min-width:280px;">Kategori</th></tr></thead>
        <tbody>
          <?php foreach ($data['uncategorized'] as $itemId => $nm): ?>
            <tr>
              <td><?= h($nm) ?></td>
              <td>
                <select name="kategori[<?= (int)$itemId ?>]" class="form-control">
                  <option value="">— pilih kategori —</option>
                  <?php foreach (report_categories() as $c): ?>
                    <option value="<?= h($c) ?>"><?= h($c) ?></option>
                  <?php endforeach; ?>
                </select>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div style="text-align:right;margin-top:12px;"><button type="submit" class="btn btn-primary btn-sm">Simpan Kategori</button></div>
  </form>
  <?php endif; ?>
</div>
<?php endif; ?>
