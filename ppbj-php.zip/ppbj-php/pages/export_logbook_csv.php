<?php
$filters = [
    'q' => trim($_GET['q'] ?? ''),
    'divisi' => trim($_GET['divisi'] ?? ''),
    'status' => trim($_GET['status'] ?? ''),
    'jalur' => trim($_GET['jalur'] ?? ''),
    'date_from' => trim($_GET['date_from'] ?? ''),
    'date_to' => trim($_GET['date_to'] ?? ''),
];

$rows = fetch_logbook_rows($pdo, $user, $filters);

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="Logbook-Procurement-PBS-' . date('Y-m-d') . '.csv"');
$out = fopen('php://output', 'w');
fprintf($out, chr(0xEF) . chr(0xBB) . chr(0xBF));

fputcsv($out, [
    'No', 'No. PPBJ', 'Tgl PPBJ', 'Divisi', 'Pemohon',
    'Item No', 'Nama Barang / Jasa', 'Qty', 'Satuan', 'Peruntukan', 'Jalur Barang',
    'Approval Manager', 'Tgl Manager', 'Approval Dir. Ops', 'Tgl Dir. Ops', 'Approval Dir. Keu', 'Tgl Dir. Keu',
    'No. Bid Summary', 'No. PO', 'Tgl PO', 'Vendor',
    'Nilai Budget (Rp)', 'Nilai Realisasi PO/Bid (Rp)',
    'No. FTB', 'Tgl FTB', 'Qty Diterima', 'Qty Ditolak', 'Status Inspeksi', 'Lead Time (Hari)', 'Status Pengadaan'
]);

foreach ($rows as $idx => $r) {
    [$sLabel] = status_meta($r['ppbj_status']);
    $vendor = $r['po_vendor_name'] ?: ($r['bid_winner_vendor'] ?: '-');
    $real = $r['po_subtotal'] !== null ? (float)$r['po_subtotal'] : ((float)($r['bid_winner_total'] ?? 0));
    $leadDays = '';
    if (!empty($r['ftb_date']) && !empty($r['request_date'])) {
        $leadDays = (string)max(0, (int)round((strtotime($r['ftb_date']) - strtotime($r['request_date'])) / 86400));
    }
    fputcsv($out, [
        $idx + 1,
        $r['request_no'],
        $r['request_date'],
        $r['division_code'] ?: $r['division_subdivision'],
        $r['applied_by_name'],
        $r['item_no'],
        $r['nama_barang_jasa'],
        $r['jumlah'],
        $r['satuan'],
        $r['peruntukan'],
        ($r['jalur_pengadaan'] ?? 'PO') === 'NON_PO' ? 'Non PO' : 'Via PO',
        $r['manager_name'] ?: '-',
        $r['manager_date'] ?: '-',
        $r['dir_ops_name'] ?: '-',
        $r['dir_ops_date'] ?: '-',
        $r['dir_keu_name'] ?: '-',
        $r['dir_keu_date'] ?: '-',
        $r['bid_no'] ?: '-',
        $r['po_no'] ?: (($r['jalur_pengadaan'] ?? 'PO') === 'NON_PO' ? 'NON-PO' : '-'),
        $r['po_date'] ?: '-',
        $vendor,
        $r['harga_anggaran'],
        $real,
        $r['ftb_no'] ?: '-',
        $r['ftb_date'] ?: '-',
        $r['qty_accepted'] ?? '-',
        $r['qty_rejected'] ?? '-',
        $r['status_penerimaan'] ?: '-',
        $leadDays,
        $sLabel,
    ]);
}
fclose($out);
exit;
