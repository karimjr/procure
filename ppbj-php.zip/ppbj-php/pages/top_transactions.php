<?php
report_guard($user);
$period = report_period();
$data = report_top_transactions($pdo, $period, 10);
$rows = $data['rows'];
?>
<div class="card">
  <div class="card-header">
    <div>
      <h1 class="card-title" style="font-size:18px;">Top 10 The Biggest Transaction</h1>
      <div style="font-size:12px;color:#64748b;">
        Periode <strong><?= h($period['label']) ?></strong> &middot; 10 PO/WO (atau transaksi Non-PO) dengan nilai terbesar dari total <?= (int)$data['order_count'] ?> transaksi.
      </div>
    </div>
    <?php report_head_actions('top_transactions', $user, false); ?>
  </div>

  <?php report_nav_tabs('top_transactions'); ?>
  <?php report_filter_bar('top_transactions', $period); ?>

  <div class="kpi-grid" style="margin-bottom:16px;">
    <div class="kpi-card">
      <div class="kpi-label">Total Spent Periode</div>
      <div class="kpi-value" style="font-size:20px;color:#0369a1;"><?= rupiah($data['total_spent']) ?></div>
      <div class="kpi-sub"><?= (int)$data['order_count'] ?> transaksi</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Nilai Top 10</div>
      <div class="kpi-value" style="font-size:20px;color:#0f172a;"><?= rupiah($data['top_spent']) ?></div>
      <div class="kpi-sub"><?= $data['total_spent'] > 0 ? fmt_pct($data['top_spent'] / $data['total_spent'] * 100) . ' dari total spent' : '-' ?></div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Total Saving Periode</div>
      <div class="kpi-value" style="font-size:20px;color:<?= $data['total_saving'] >= 0 ? '#008A3B' : '#dc2626' ?>;"><?= ($data['total_saving'] < 0 ? '-' : '') . rupiah(abs($data['total_saving'])) ?></div>
      <div class="kpi-sub">Budget &minus; realisasi</div>
    </div>
  </div>

  <div class="table-wrap">
    <table class="rpt-table">
      <thead>
        <tr>
          <th style="width:44px;">No</th>
          <th style="min-width:200px;">Vendor name</th>
          <th style="min-width:280px;">Detail items</th>
          <th style="min-width:130px;">Value in IDR</th>
          <th style="min-width:90px;">% From Total Spent</th>
          <th style="min-width:120px;">Saving Cost</th>
          <th style="min-width:90px;">% From Total Saving</th>
        </tr>
      </thead>
      <tbody>
        <?php for ($i = 0; $i < 10; $i++):
          $r = $rows[$i] ?? null;
        ?>
          <tr>
            <td style="text-align:center;"><?= $i + 1 ?></td>
            <?php if ($r): ?>
              <td>
                <strong><?= h($r['vendor_name']) ?></strong>
                <div class="sub"><?= $r['po_no'] ? h($r['po_no']) . ' &middot; ' . h($r['order_type'] === 'WORK ORDER' ? 'WO' : 'PO') : 'Non-PO (Bid Summary #' . (int)$r['bid_id'] . ')' ?></div>
              </td>
              <td><?= h($r['detail']) ?></td>
              <td class="num"><?= fmt_idr($r['actual']) ?></td>
              <td class="num"><?= fmt_pct($r['pct_spent']) ?></td>
              <td class="num <?= $r['saving'] < 0 ? 'rpt-bad' : '' ?>"><?= fmt_idr($r['saving']) ?></td>
              <td class="num"><?= fmt_pct($r['pct_saving']) ?></td>
            <?php else: ?>
              <td></td><td></td><td></td><td></td><td></td><td></td>
            <?php endif; ?>
          </tr>
        <?php endfor; ?>
      </tbody>
      <tfoot>
        <tr class="rpt-group">
          <td></td><td colspan="2" style="text-align:right;font-weight:700;">Total Top 10</td>
          <td class="num"><?= fmt_idr($data['top_spent']) ?></td>
          <td class="num"><?= $data['total_spent'] > 0 ? fmt_pct($data['top_spent'] / $data['total_spent'] * 100) : '-' ?></td>
          <td class="num"><?= fmt_idr(array_sum(array_column($rows, 'saving'))) ?></td>
          <td class="num"><?= $data['total_saving'] > 0 ? fmt_pct(array_sum(array_column($rows, 'saving')) / $data['total_saving'] * 100) : '-' ?></td>
        </tr>
      </tfoot>
    </table>
  </div>
  <div class="rpt-foot">
    Nilai = total baris item (sebelum PPN/ongkir) agar sebanding dengan laporan Cost Saving. Saving = budget PPBJ &minus; nilai PO.
    Transaksi Non-PO digabung per Bid Summary &amp; vendor pemenang.
  </div>
</div>
