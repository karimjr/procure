<?php
$canManageVendors = in_array($user['role'], ['PROCUREMENT', 'ADMIN'], true);
$editId = isset($_GET['edit']) ? (int)$_GET['edit'] : 0;
$editVendor = null;
if ($editId > 0) {
    $stE = $pdo->prepare("SELECT * FROM vendors WHERE id = ?");
    $stE->execute([$editId]);
    $editVendor = $stE->fetch();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$canManageVendors) {
        set_flash('Hanya akun Procurement / Admin yang dapat mengubah Master Vendor.', 'error');
        redirect_to('index.php?page=vendors');
    }

    if (isset($_POST['import_vendors'])) {
        if (empty($_FILES['vendor_file']['tmp_name']) || $_FILES['vendor_file']['error'] !== UPLOAD_ERR_OK) {
            set_flash('Pilih file Excel (.xlsx) atau CSV terlebih dahulu.', 'error');
            redirect_to('index.php?page=vendors');
        }
        $origName = $_FILES['vendor_file']['name'] ?? '';
        $ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
        $tmpPath = $_FILES['vendor_file']['tmp_name'];

        $rawRows = [];
        if ($ext === 'xlsx') {
            $rawRows = parse_xlsx_rows($tmpPath);
        } elseif (in_array($ext, ['csv', 'tsv', 'txt'], true)) {
            $rawRows = parse_csv_rows($tmpPath);
        } else {
            set_flash('Format file tidak didukung. Gunakan file .xlsx atau .csv.', 'error');
            redirect_to('index.php?page=vendors');
        }

        $parsed = extract_vendors_from_rows($rawRows);
        if (empty($parsed)) {
            set_flash('Tidak ada baris data vendor yang terbaca dari file tersebut. Pastikan kolom Nama Penyedia Eksternal terisi.', 'error');
            redirect_to('index.php?page=vendors');
        }

        try {
            $pdo->beginTransaction();
            $existingSt = $pdo->query("SELECT id, nama_vendor FROM vendors");
            $existingMap = [];
            foreach ($existingSt->fetchAll() as $ex) {
                $existingMap[strtolower(trim($ex['nama_vendor']))] = (int)$ex['id'];
            }

            $maxNum = 0;
            foreach ($pdo->query("SELECT kode_vendor FROM vendors")->fetchAll(PDO::FETCH_COLUMN) as $kv) {
                if (preg_match('/(\d+)/', (string)$kv, $m)) {
                    $maxNum = max($maxNum, (int)$m[1]);
                }
            }

            $insSt = $pdo->prepare(
                "INSERT INTO vendors (
                    kode_vendor, nama_vendor, jenis_penyedia, kategori, item_dijual,
                    no_rekening, an_rekening, nama_bank, npwp, pic, telepon, email, alamat, kota, aktif
                 ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)"
            );
            $updSt = $pdo->prepare(
                "UPDATE vendors SET
                    jenis_penyedia = ?, kategori = ?, item_dijual = ?,
                    no_rekening = ?, an_rekening = ?, nama_bank = ?,
                    npwp = CASE WHEN ? != '-' AND ? != '' THEN ? ELSE npwp END,
                    pic = CASE WHEN ? != '-' AND ? != '' THEN ? ELSE pic END,
                    telepon = ?,
                    email = CASE WHEN ? != '-' AND ? != '' THEN ? ELSE email END,
                    alamat = ?, kota = ?
                 WHERE id = ?"
            );

            $inserted = 0;
            $updated = 0;
            foreach ($parsed as $v) {
                $key = strtolower(trim($v['nama_vendor']));
                if (isset($existingMap[$key])) {
                    $updSt->execute([
                        $v['jenis_penyedia'], $v['kategori'], $v['item_dijual'],
                        $v['no_rekening'], $v['an_rekening'], $v['nama_bank'],
                        $v['npwp'], $v['npwp'], $v['npwp'],
                        $v['pic'], $v['pic'], $v['pic'],
                        $v['telepon'],
                        $v['email'], $v['email'], $v['email'],
                        $v['alamat'], $v['kota'],
                        $existingMap[$key]
                    ]);
                    $updated++;
                } else {
                    $maxNum++;
                    $kode = 'VND-' . str_pad((string)$maxNum, 3, '0', STR_PAD_LEFT);
                    $insSt->execute([
                        $kode, $v['nama_vendor'], $v['jenis_penyedia'], $v['kategori'], $v['item_dijual'],
                        $v['no_rekening'], $v['an_rekening'], $v['nama_bank'],
                        $v['npwp'], $v['pic'], $v['telepon'], $v['email'], $v['alamat'], $v['kota']
                    ]);
                    $existingMap[$key] = (int)$pdo->lastInsertId();
                    $inserted++;
                }
            }
            $pdo->commit();
            set_flash("Import berhasil: {$inserted} vendor baru ditambahkan, {$updated} vendor diperbarui dari file {$origName}.");
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            set_flash('Gagal mengimport vendor: ' . $e->getMessage(), 'error');
        }
        redirect_to('index.php?page=vendors');
    } elseif (isset($_POST['save_vendor'])) {
        $vid = (int)($_POST['vendor_id'] ?? 0);
        $nama = trim($_POST['nama_vendor'] ?? '');
        $itemDijual = trim($_POST['item_dijual'] ?? '');
        $kategori = trim($_POST['kategori'] ?? '') ?: mb_substr($itemDijual ?: 'Umum', 0, 240);
        $jenis = in_array($_POST['jenis_penyedia'] ?? '', ['Barang', 'Jasa', 'Barang & Jasa'], true)
            ? $_POST['jenis_penyedia']
            : infer_vendor_jenis($itemDijual ?: $kategori);
        $noRek = trim($_POST['no_rekening'] ?? '') ?: '-';
        $anRek = trim($_POST['an_rekening'] ?? '') ?: '-';
        $bank = trim($_POST['nama_bank'] ?? '') ?: '-';
        $npwp = trim($_POST['npwp'] ?? '') ?: '-';
        $pic = trim($_POST['pic'] ?? '') ?: '-';
        $telepon = trim($_POST['telepon'] ?? '') ?: '-';
        $email = trim($_POST['email'] ?? '') ?: '-';
        $alamat = trim($_POST['alamat'] ?? '') ?: '-';
        $kota = trim($_POST['kota'] ?? '') ?: infer_vendor_kota($alamat);

        if ($nama === '') {
            set_flash('Nama Penyedia Eksternal wajib diisi.', 'error');
            redirect_to('index.php?page=vendors' . ($vid > 0 ? '&edit=' . $vid : ''));
        }

        if ($vid > 0) {
            $upd = $pdo->prepare(
                "UPDATE vendors SET
                    nama_vendor = ?, jenis_penyedia = ?, kategori = ?, item_dijual = ?,
                    no_rekening = ?, an_rekening = ?, nama_bank = ?,
                    npwp = ?, pic = ?, telepon = ?, email = ?, alamat = ?, kota = ?
                 WHERE id = ?"
            );
            $upd->execute([
                $nama, $jenis, $kategori, $itemDijual ?: $kategori,
                $noRek, $anRek, $bank,
                $npwp, $pic, $telepon, $email, $alamat, $kota, $vid
            ]);
            set_flash("Data penyedia eksternal {$nama} berhasil diperbarui.");
        } else {
            $maxNum = 0;
            foreach ($pdo->query("SELECT kode_vendor FROM vendors")->fetchAll(PDO::FETCH_COLUMN) as $kv) {
                if (preg_match('/(\d+)/', (string)$kv, $m)) {
                    $maxNum = max($maxNum, (int)$m[1]);
                }
            }
            $kode = 'VND-' . str_pad((string)($maxNum + 1), 3, '0', STR_PAD_LEFT);
            $ins = $pdo->prepare(
                "INSERT INTO vendors (
                    kode_vendor, nama_vendor, jenis_penyedia, kategori, item_dijual,
                    no_rekening, an_rekening, nama_bank, npwp, pic, telepon, email, alamat, kota, aktif
                 ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)"
            );
            $ins->execute([
                $kode, $nama, $jenis, $kategori, $itemDijual ?: $kategori,
                $noRek, $anRek, $bank,
                $npwp, $pic, $telepon, $email, $alamat, $kota
            ]);
            set_flash("Penyedia eksternal {$nama} ({$kode}) berhasil ditambahkan.");
        }
        redirect_to('index.php?page=vendors');
    } elseif (isset($_POST['toggle_vendor'])) {
        $vid = (int)$_POST['vendor_id'];
        $newState = (int)$_POST['new_state'];
        $pdo->prepare("UPDATE vendors SET aktif = ? WHERE id = ?")->execute([$newState, $vid]);
        set_flash('Status keaktifan vendor diperbarui.');
        redirect_to('index.php?page=vendors');
    }
}

$q = trim($_GET['q'] ?? '');
$statusFilter = $_GET['aktif'] ?? '';
$sql = "SELECT * FROM vendors WHERE 1=1";
$params = [];
if ($q !== '') {
    $sql .= " AND (kode_vendor LIKE ? OR nama_vendor LIKE ? OR item_dijual LIKE ? OR kategori LIKE ? OR nama_bank LIKE ? OR no_rekening LIKE ? OR alamat LIKE ? OR telepon LIKE ?)";
    $like = "%{$q}%";
    $params = array_fill(0, 8, $like);
}
if ($statusFilter === '1' || $statusFilter === '0') {
    $sql .= " AND aktif = ?";
    $params[] = (int)$statusFilter;
}
$sql .= " ORDER BY id ASC";
$stList = $pdo->prepare($sql);
$stList->execute($params);
$vendors = $stList->fetchAll();

$totalVendors = (int)$pdo->query("SELECT COUNT(*) FROM vendors")->fetchColumn();
$activeVendors = (int)$pdo->query("SELECT COUNT(*) FROM vendors WHERE aktif = 1")->fetchColumn();
?>

<div class="card">
  <div class="card-header">
    <div>
      <h1 class="card-title" style="font-size:18px;">Daftar Penyedia Eksternal Terpilih (Master Vendor)</h1>
      <div style="font-size:12px;color:#64748b;">
        Disesuaikan dengan format resmi <strong>Formulir Daftar Penyedia Eksternal Terpilih (PT. Potensi Bumi Sakti)</strong> — Total: <strong><?= $totalVendors ?></strong> vendor (<?= $activeVendors ?> aktif).
      </div>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;">
      <a href="index.php?page=vendor_template_csv" class="btn btn-outline btn-sm">Download Template CSV</a>
      <a href="index.php?page=export_vendors_csv" class="btn btn-outline btn-sm">Export CSV</a>
      <a href="index.php?page=print_vendors" target="_blank" class="btn btn-primary btn-sm">Cetak Daftar Penyedia</a>
    </div>
  </div>

  <?php if ($canManageVendors): ?>
  <!-- Panel Import Excel / CSV -->
  <form method="post" enctype="multipart/form-data" style="background:#f0f9ff;border:1px solid #bae6fd;border-radius:12px;padding:15px;margin-bottom:16px;">
    <input type="hidden" name="import_vendors" value="1">
    <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;">
      <div style="flex:1;min-width:260px;">
        <div style="font-weight:700;font-size:13px;color:#0369a1;margin-bottom:4px;">Import Otomatis dari Excel (.xlsx) atau CSV (Tanpa Ketik Manual)</div>
        <div style="font-size:12px;color:#334155;">
          Unggah file <code>Daftar Penyedia Eksternal Terpilih PBS 2026.xlsx</code> atau file CSV hasil template. Sistem otomatis membaca kolom <em>Nama Penyedia, No. Rekening, A.n. Rekening Bank, Nama Bank, Alamat Toko, No. Telp,</em> dan <em>Item yang Dijual</em> (vendor yang sudah ada akan diperbarui, yang baru otomatis ditambahkan).
        </div>
      </div>
      <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
        <input type="file" name="vendor_file" accept=".xlsx,.csv,.tsv,.txt" required class="form-control" style="max-width:290px;background:#fff;">
        <button type="submit" class="btn btn-green btn-sm">Import &amp; Sinkronkan</button>
      </div>
    </div>
  </form>

  <!-- Form Tambah / Edit Vendor Lengkap sesuai Formulir PBS -->
  <form method="post" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;padding:16px;margin-bottom:18px;">
    <input type="hidden" name="save_vendor" value="1">
    <input type="hidden" name="vendor_id" value="<?= (int)($editVendor['id'] ?? 0) ?>">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
      <div style="font-weight:700;font-size:13.5px;color:#007AB3;">
        <?= $editVendor ? 'Edit Penyedia Eksternal: ' . h($editVendor['kode_vendor']) . ' — ' . h($editVendor['nama_vendor']) : '+ Tambah Penyedia Eksternal Baru (Format Resmi PBS)' ?>
      </div>
      <?php if ($editVendor): ?>
        <a href="index.php?page=vendors" class="btn btn-outline btn-sm">Batal Edit</a>
      <?php endif; ?>
    </div>

    <div class="grid-3" style="margin-bottom:10px;">
      <div class="form-group" style="margin-bottom:0;">
        <label style="font-size:11.5px;">Nama Penyedia Eksternal *</label>
        <input type="text" name="nama_vendor" class="form-control" required placeholder="Contoh: PT Horas Bangun Persada" value="<?= h($editVendor['nama_vendor'] ?? '') ?>">
      </div>
      <div class="form-group" style="margin-bottom:0;">
        <label style="font-size:11.5px;">Item yang Dijual *</label>
        <input type="text" name="item_dijual" class="form-control" placeholder="Contoh: Bahan Kimia, Instrumen Lab / Sparepart" value="<?= h($editVendor['item_dijual'] ?? ($editVendor['kategori'] ?? '')) ?>">
      </div>
      <div class="form-group" style="margin-bottom:0;">
        <label style="font-size:11.5px;">Jenis Penyedia</label>
        <select name="jenis_penyedia" class="form-control">
          <?php $curJenis = $editVendor['jenis_penyedia'] ?? 'Barang'; ?>
          <option value="Barang" <?= $curJenis === 'Barang' ? 'selected' : '' ?>>Barang</option>
          <option value="Jasa" <?= $curJenis === 'Jasa' ? 'selected' : '' ?>>Jasa</option>
          <option value="Barang & Jasa" <?= $curJenis === 'Barang & Jasa' ? 'selected' : '' ?>>Barang &amp; Jasa</option>
        </select>
      </div>
    </div>

    <div class="grid-3" style="margin-bottom:10px;">
      <div class="form-group" style="margin-bottom:0;">
        <label style="font-size:11.5px;">No. Rekening</label>
        <input type="text" name="no_rekening" class="form-control" placeholder="Contoh: 7141785731" value="<?= h($editVendor['no_rekening'] ?? '') ?>">
      </div>
      <div class="form-group" style="margin-bottom:0;">
        <label style="font-size:11.5px;">A.n. Rekening Bank</label>
        <input type="text" name="an_rekening" class="form-control" placeholder="Nama pemilik rekening" value="<?= h($editVendor['an_rekening'] ?? '') ?>">
      </div>
      <div class="form-group" style="margin-bottom:0;">
        <label style="font-size:11.5px;">Nama Bank</label>
        <input type="text" name="nama_bank" class="form-control" placeholder="Contoh: BSI Cabang Meulaboh / BCA / Mandiri" value="<?= h($editVendor['nama_bank'] ?? '') ?>">
      </div>
    </div>

    <div class="grid-4" style="margin-bottom:10px;">
      <div class="form-group" style="margin-bottom:0;">
        <label style="font-size:11.5px;">No. Telp Penyedia Eksternal</label>
        <input type="text" name="telepon" class="form-control" placeholder="Contoh: Faisal (0821-9975-5600)" value="<?= h($editVendor['telepon'] ?? '') ?>">
      </div>
      <div class="form-group" style="margin-bottom:0;">
        <label style="font-size:11.5px;">Nama PIC (Opsional)</label>
        <input type="text" name="pic" class="form-control" placeholder="Nama kontak person" value="<?= h($editVendor['pic'] ?? '') ?>">
      </div>
      <div class="form-group" style="margin-bottom:0;">
        <label style="font-size:11.5px;">Email</label>
        <input type="text" name="email" class="form-control" placeholder="email@vendor.co.id" value="<?= h($editVendor['email'] ?? '') ?>">
      </div>
      <div class="form-group" style="margin-bottom:0;">
        <label style="font-size:11.5px;">NPWP / Kota</label>
        <div style="display:flex;gap:6px;">
          <input type="text" name="npwp" class="form-control" placeholder="NPWP" value="<?= h($editVendor['npwp'] ?? '') ?>">
          <input type="text" name="kota" class="form-control" placeholder="Kota" value="<?= h($editVendor['kota'] ?? '') ?>">
        </div>
      </div>
    </div>

    <div class="form-group" style="margin-bottom:12px;">
      <label style="font-size:11.5px;">Alamat Toko / Kantor Lengkap</label>
      <input type="text" name="alamat" class="form-control" placeholder="Alamat lengkap sesuai form penyedia eksternal (otomatis terisi ke Seller PO)" value="<?= h($editVendor['alamat'] ?? '') ?>">
    </div>

    <button type="submit" class="btn btn-primary btn-sm"><?= $editVendor ? 'Simpan Perubahan Vendor' : 'Simpan Penyedia Eksternal' ?></button>
  </form>
  <?php endif; ?>

  <!-- Pencarian & Filter -->
  <form method="get" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:14px;">
    <input type="hidden" name="page" value="vendors">
    <input type="text" name="q" class="form-control" style="max-width:340px;" placeholder="Cari nama vendor, item dijual, bank, rekening, alamat..." value="<?= h($q) ?>">
    <select name="aktif" class="form-control" style="max-width:170px;">
      <option value="">Semua Status</option>
      <option value="1" <?= $statusFilter === '1' ? 'selected' : '' ?>>Aktif Saja</option>
      <option value="0" <?= $statusFilter === '0' ? 'selected' : '' ?>>Nonaktif Saja</option>
    </select>
    <button type="submit" class="btn btn-outline btn-sm">Cari</button>
    <?php if ($q !== '' || $statusFilter !== ''): ?>
      <a href="index.php?page=vendors" class="btn btn-outline btn-sm">Reset</a>
    <?php endif; ?>
    <span style="font-size:12px;color:#64748b;margin-left:auto;">Menampilkan <strong><?= count($vendors) ?></strong> penyedia</span>
  </form>

  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th>No / Kode</th>
          <th style="min-width:190px;">Nama Penyedia Eksternal</th>
          <th style="min-width:185px;">No. Rekening &amp; Bank</th>
          <th style="min-width:210px;">Alamat Toko</th>
          <th style="min-width:160px;">No. Telp Penyedia</th>
          <th style="min-width:180px;">Item yang Dijual</th>
          <th>Status</th>
          <?php if ($canManageVendors): ?><th>Aksi</th><?php endif; ?>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($vendors)): ?>
          <tr><td colspan="<?= $canManageVendors ? 8 : 7 ?>" style="text-align:center;color:#64748b;padding:24px;">Tidak ada data vendor yang cocok.</td></tr>
        <?php else: ?>
          <?php foreach ($vendors as $idx => $v): ?>
            <tr>
              <td style="white-space:nowrap;">
                <div style="font-weight:800;color:#0f172a;"><?= $idx + 1 ?></div>
                <div style="font-size:11px;color:#64748b;"><?= h($v['kode_vendor']) ?></div>
              </td>
              <td>
                <strong><?= h($v['nama_vendor']) ?></strong>
                <div style="margin-top:3px;"><span class="badge badge-sky"><?= h($v['jenis_penyedia']) ?></span></div>
              </td>
              <td style="font-size:12px;">
                <div><strong><?= h($v['no_rekening'] ?: '-') ?></strong></div>
                <div style="color:#334155;">a.n. <?= h($v['an_rekening'] ?: '-') ?></div>
                <div style="color:#0369a1;font-weight:600;"><?= h($v['nama_bank'] ?: '-') ?></div>
              </td>
              <td style="font-size:12px;">
                <div><?= h($v['alamat'] ?: '-') ?></div>
                <?php if (!empty($v['kota']) && $v['kota'] !== 'Indonesia'): ?>
                  <div style="color:#64748b;font-size:11px;margin-top:2px;">Kota: <?= h($v['kota']) ?></div>
                <?php endif; ?>
              </td>
              <td style="font-size:12px;">
                <div><?= h($v['telepon'] ?: '-') ?></div>
                <?php if (!empty($v['pic']) && $v['pic'] !== '-'): ?>
                  <div style="color:#64748b;font-size:11px;">PIC: <?= h($v['pic']) ?></div>
                <?php endif; ?>
                <?php if (!empty($v['email']) && $v['email'] !== '-'): ?>
                  <div style="color:#64748b;font-size:11px;"><?= h($v['email']) ?></div>
                <?php endif; ?>
              </td>
              <td style="font-size:12px;"><?= h($v['item_dijual'] ?: $v['kategori']) ?></td>
              <td>
                <?php if ($v['aktif']): ?>
                  <span class="badge badge-green">Aktif</span>
                <?php else: ?>
                  <span class="badge badge-slate">Nonaktif</span>
                <?php endif; ?>
              </td>
              <?php if ($canManageVendors): ?>
              <td style="white-space:nowrap;">
                <a href="index.php?page=vendors&edit=<?= (int)$v['id'] ?>" class="btn btn-outline btn-sm">Edit</a>
                <form method="post" style="display:inline;">
                  <input type="hidden" name="toggle_vendor" value="1">
                  <input type="hidden" name="vendor_id" value="<?= (int)$v['id'] ?>">
                  <input type="hidden" name="new_state" value="<?= $v['aktif'] ? 0 : 1 ?>">
                  <button type="submit" class="btn btn-outline btn-sm">
                    <?= $v['aktif'] ? 'Nonaktifkan' : 'Aktifkan' ?>
                  </button>
                </form>
              </td>
              <?php endif; ?>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
