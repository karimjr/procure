<?php
$role = $user['role'];
$canManagePo = in_array($role, ['PROCUREMENT', 'ADMIN'], true);
if (!$canManagePo) {
    echo '<div class="card"><div class="flash flash-error">Hanya akun Procurement / Admin yang dapat membuat atau mengedit PO.</div><a href="index.php?page=po_list" class="btn btn-outline btn-sm">&larr; Kembali</a></div>';
    return;
}

$poId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$existingPo = null;
$existingPoItems = [];

if ($poId > 0) {
    $st = $pdo->prepare("SELECT * FROM purchase_orders WHERE id = ?");
    $st->execute([$poId]);
    $existingPo = $st->fetch();
    if (!$existingPo) {
        echo '<div class="card"><p>Data PO tidak ditemukan.</p><a href="index.php?page=po_list" class="btn btn-outline btn-sm">Kembali</a></div>';
        return;
    }
    $itSt = $pdo->prepare("SELECT * FROM po_items WHERE po_id = ? ORDER BY item_no ASC");
    $itSt->execute([$poId]);
    $existingPoItems = $itSt->fetchAll();
}

$bidList = $pdo->query(
    "SELECT b.id, b.bid_no, b.judul, b.ppbj_id, p.request_no, p.delivery_location, p.received_date, p.division_code, p.division_subdivision
     FROM bid_summaries b
     JOIN ppbj_requests p ON b.ppbj_id = p.id
     ORDER BY b.id DESC"
)->fetchAll();

$ppbjList = $pdo->query(
    "SELECT id, request_no, division_code, division_subdivision, delivery_location, received_date, status
     FROM ppbj_requests
     WHERE status IN ('SIAP_BID', 'PO_TERBIT', 'SELESAI_FTB')
     ORDER BY id DESC"
)->fetchAll();

$vendors = $pdo->query("SELECT * FROM vendors WHERE aktif = 1 ORDER BY nama_vendor ASC")->fetchAll();
$vendorById = [];
$vendorMetaMap = [];
foreach ($vendors as $v) {
    $vid = (int)$v['id'];
    $vendorById[$vid] = $v;
    $addr = trim(($v['alamat'] ?? '') . (!empty($v['kota']) ? ', ' . $v['kota'] : ''), ', ');
    $vendorMetaMap[$vid] = [
        'address' => $addr ?: '-',
        'contact' => trim(($v['pic'] ?? '-') . (!empty($v['telepon']) ? ' (' . $v['telepon'] . ')' : '')),
        'email' => $v['email'] ?? '-',
    ];
}

$preBidId = $existingPo ? (int)($existingPo['bid_id'] ?? 0) : (isset($_GET['bid_id']) ? (int)$_GET['bid_id'] : 0);
$prePpbjId = $existingPo ? (int)$existingPo['ppbj_id'] : (isset($_GET['ppbj_id']) ? (int)$_GET['ppbj_id'] : 0);

if (!$existingPo && $preBidId > 0) {
    foreach ($bidList as $b) {
        if ((int)$b['id'] === $preBidId) {
            $prePpbjId = (int)$b['ppbj_id'];
            break;
        }
    }
}
if (!$existingPo && $preBidId === 0 && $prePpbjId === 0 && !empty($bidList)) {
    $preBidId = (int)$bidList[0]['id'];
    $prePpbjId = (int)$bidList[0]['ppbj_id'];
}
if (!$existingPo && $prePpbjId === 0 && !empty($ppbjList)) {
    $prePpbjId = (int)$ppbjList[0]['id'];
}

$selectedPpbj = null;
if ($prePpbjId > 0) {
    $ps = $pdo->prepare("SELECT * FROM ppbj_requests WHERE id = ?");
    $ps->execute([$prePpbjId]);
    $selectedPpbj = $ps->fetch();
}

$formItems = [];
if ($existingPo) {
    foreach ($existingPoItems as $epi) {
        $formItems[] = [
            'checked' => true,
            'ppbj_item_id' => (int)($epi['ppbj_item_id'] ?? 0),
            'nama_barang_jasa' => $epi['nama_barang_jasa'],
            'qty' => (float)$epi['qty'],
            'satuan' => $epi['satuan'],
            'harga_satuan' => (float)$epi['harga_satuan'],
        ];
    }
} elseif ($prePpbjId > 0) {
    $pItemsSt = $pdo->prepare("SELECT * FROM ppbj_items WHERE ppbj_id = ? ORDER BY item_no ASC");
    $pItemsSt->execute([$prePpbjId]);
    $pItems = $pItemsSt->fetchAll();

    $bidPriceMap = [];
    if ($preBidId > 0) {
        $bpSt = $pdo->prepare("SELECT ppbj_item_id, harga_penawaran FROM bid_items WHERE bid_id = ? AND is_selected = 1");
        $bpSt->execute([$preBidId]);
        foreach ($bpSt->fetchAll() as $bp) {
            $bidPriceMap[(int)$bp['ppbj_item_id']] = (float)$bp['harga_penawaran'];
        }
    }

    foreach ($pItems as $pi) {
        $pid = (int)$pi['id'];
        $formItems[] = [
            'checked' => true,
            'ppbj_item_id' => $pid,
            'nama_barang_jasa' => $pi['nama_barang_jasa'],
            'qty' => (float)$pi['jumlah'],
            'satuan' => $pi['satuan'],
            'harga_satuan' => $bidPriceMap[$pid] ?? (float)$pi['harga_unit'],
        ];
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $orderType = ($_POST['order_type'] ?? 'PURCHASE ORDER') === 'WORK ORDER' ? 'WORK ORDER' : 'PURCHASE ORDER';
    $poNo = trim($_POST['po_no'] ?? next_po_no($pdo));
    $poDate = $_POST['po_date'] ?: date('Y-m-d');
    $postPpbjId = (int)($_POST['ppbj_id'] ?? $prePpbjId);
    $postBidId = (int)($_POST['bid_id'] ?? 0) ?: null;
    $vendorId = (int)($_POST['vendor_id'] ?? 0);
    $sellerAddress = trim($_POST['seller_address'] ?? '-');
    $sellerContact = trim($_POST['seller_contact'] ?? '-');
    $sellerEmail = trim($_POST['seller_email'] ?? '-');
    $terminSelect = trim($_POST['termin_pembayaran_select'] ?? '');
    $terminCustom = trim($_POST['termin_pembayaran_custom'] ?? '');
    if ($terminSelect === '__CUSTOM__') {
        $termin = $terminCustom ?: 'Credit, 30 days after receipt of the invoice and BAST / Delivery Note';
    } elseif ($terminSelect !== '') {
        $termin = $terminSelect;
    } else {
        $termin = trim($_POST['termin_pembayaran'] ?? 'Credit, 30 days after receipt of the invoice and BAST / Delivery Note');
    }
    $termsDeliv = trim($_POST['terms_of_delivery'] ?? 'Franco PBS Site');
    $leadTime = trim($_POST['lead_time_delivery'] ?? '14 Days');
    $quotRef = trim($_POST['quotation_ref'] ?? '-');
    $estKirim = $_POST['estimasi_kirim'] ?: null;
    $delivLoc = trim($_POST['delivery_location'] ?? '');
    $delivContact = trim($_POST['delivery_contact'] ?? 'T Safril Nizam TM (082213151408)');
    $purchaseRef = trim($_POST['purchase_reference'] ?? '');
    $divisionDept = trim($_POST['division_dept'] ?? '');
    $pbsSigner = trim($_POST['pbs_signer_name'] ?? $user['nama_lengkap']);
    $statusPo = $_POST['status'] ?? 'TERBIT';
    $catatan = trim($_POST['catatan'] ?? '');

    $deliveryFee = max(0, (float)($_POST['delivery_fee'] ?? 0));
    $discountAmt = max(0, (float)($_POST['discount_amount'] ?? 0));
    $vatPct = max(0, (float)($_POST['vat_percent'] ?? 0));
    $pphCode = trim($_POST['pph_option_code'] ?? 'NONE');
    $whtPct = max(0, (float)($_POST['withholding_tax_pct'] ?? 0));
    $whtLabel = null;
    foreach (po_pph_options() as $pOpt) {
        if ($pOpt['code'] === $pphCode && $pphCode !== 'NONE') {
            $whtLabel = $pOpt['jenis_pajak'] . ' - ' . $pOpt['keterangan'];
            break;
        }
    }

    $checkedIdx = $_POST['item_pick'] ?? [];
    $ppbjItemIds = $_POST['item_ppbj_id'] ?? [];
    $itemNames = $_POST['item_nama'] ?? [];
    $itemQtys = $_POST['item_qty'] ?? [];
    $itemUnits = $_POST['item_satuan'] ?? [];
    $itemPrices = $_POST['item_harga'] ?? [];

    try {
        if ($postPpbjId <= 0) throw new RuntimeException('Referensi PPBJ wajib dipilih.');
        if ($vendorId <= 0 || !isset($vendorById[$vendorId])) throw new RuntimeException('Pilih Vendor terlebih dahulu.');

        $vendorName = $vendorById[$vendorId]['nama_vendor'];
        $chosenItems = [];
        foreach ($checkedIdx as $idxStr) {
            $i = (int)$idxStr;
            $nm = trim($itemNames[$i] ?? '');
            if ($nm === '') continue;
            $q = max(0.01, (float)($itemQtys[$i] ?? 1));
            $u = trim($itemUnits[$i] ?? 'Pcs') ?: 'Pcs';
            $p = max(0, (float)($itemPrices[$i] ?? 0));
            $chosenItems[] = [
                'ppbj_item_id' => !empty($ppbjItemIds[$i]) ? (int)$ppbjItemIds[$i] : null,
                'item_no' => count($chosenItems) + 1,
                'nama_barang_jasa' => $nm,
                'qty' => $q,
                'satuan' => $u,
                'harga_satuan' => $p,
                'subtotal' => $q * $p,
            ];
        }

        if (empty($chosenItems)) {
            throw new RuntimeException('Centang minimal 1 item barang/jasa untuk masuk ke PO.');
        }

        $subTotal = array_sum(array_column($chosenItems, 'subtotal'));
        $vatAmt = round($subTotal * ($vatPct / 100), 2);
        $grandTotal = max(0, $subTotal + $deliveryFee - $discountAmt + $vatAmt);

        $pdo->beginTransaction();

        if ($poId > 0 && $existingPo) {
            $pdo->prepare(
                "UPDATE purchase_orders
                 SET order_type = ?, po_no = ?, po_date = ?, ppbj_id = ?, bid_id = ?, vendor_id = ?, vendor_name = ?,
                     seller_address = ?, seller_contact = ?, seller_email = ?,
                     termin_pembayaran = ?, terms_of_delivery = ?, lead_time_delivery = ?, quotation_ref = ?,
                     estimasi_kirim = ?, delivery_location = ?, delivery_contact = ?,
                     purchase_reference = ?, division_dept = ?,
                     subtotal_po = ?, delivery_fee = ?, discount_amount = ?, vat_percent = ?, vat_amount = ?, withholding_tax_pct = ?, withholding_tax_label = ?,
                     catatan = ?, total_po = ?, pbs_signer_name = ?, status = ?
                 WHERE id = ?"
            )->execute([
                $orderType, $poNo, $poDate, $postPpbjId, $postBidId, $vendorId, $vendorName,
                $sellerAddress, $sellerContact, $sellerEmail,
                $termin, $termsDeliv, $leadTime, $quotRef,
                $estKirim, $delivLoc, $delivContact,
                $purchaseRef, $divisionDept,
                $subTotal, $deliveryFee, $discountAmt, $vatPct, $vatAmt, $whtPct, $whtLabel,
                $catatan, $grandTotal, $pbsSigner, $statusPo, $poId
            ]);
            $pdo->prepare("DELETE FROM po_items WHERE po_id = ?")->execute([$poId]);
            $savedPoId = $poId;
            $logAction = "Edit PO ({$poNo})";
        } else {
            $pdo->prepare(
                "INSERT INTO purchase_orders (
                    order_type, po_no, po_date, ppbj_id, bid_id, vendor_id, vendor_name,
                    seller_address, seller_contact, seller_email,
                    termin_pembayaran, terms_of_delivery, lead_time_delivery, quotation_ref,
                    estimasi_kirim, delivery_location, delivery_contact,
                    purchase_reference, division_dept,
                    subtotal_po, delivery_fee, discount_amount, vat_percent, vat_amount, withholding_tax_pct, withholding_tax_label,
                    catatan, total_po, pbs_signer_name, status, dibuat_oleh
                 ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
            )->execute([
                $orderType, $poNo, $poDate, $postPpbjId, $postBidId, $vendorId, $vendorName,
                $sellerAddress, $sellerContact, $sellerEmail,
                $termin, $termsDeliv, $leadTime, $quotRef,
                $estKirim, $delivLoc, $delivContact,
                $purchaseRef, $divisionDept,
                $subTotal, $deliveryFee, $discountAmt, $vatPct, $vatAmt, $whtPct, $whtLabel,
                $catatan, $grandTotal, $pbsSigner, $statusPo, $user['nama_lengkap']
            ]);
            $savedPoId = (int)$pdo->lastInsertId();
            $logAction = "PO Diterbitkan ({$poNo})";
        }

        $insItem = $pdo->prepare(
            "INSERT INTO po_items (po_id, ppbj_item_id, item_no, nama_barang_jasa, qty, satuan, harga_satuan, subtotal)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
        );
        foreach ($chosenItems as $ci) {
            $insItem->execute([
                $savedPoId, $ci['ppbj_item_id'], $ci['item_no'], $ci['nama_barang_jasa'],
                $ci['qty'], $ci['satuan'], $ci['harga_satuan'], $ci['subtotal']
            ]);
        }

        // Sinkronisasi ringkasan ke ppbj_requests
        $allPo = $pdo->prepare("SELECT po_no, vendor_name, status FROM purchase_orders WHERE ppbj_id = ? ORDER BY id ASC");
        $allPo->execute([$postPpbjId]);
        $poRows = $allPo->fetchAll();
        $poSummary = implode(', ', array_column($poRows, 'po_no'));
        $vSummary = implode(', ', array_unique(array_column($poRows, 'vendor_name')));
        $allSelesai = !empty($poRows) && count(array_filter($poRows, fn($x) => $x['status'] !== 'SELESAI_FTB')) === 0;
        $ppbjNewStatus = $allSelesai ? 'SELESAI_FTB' : 'PO_TERBIT';

        $pdo->prepare("UPDATE ppbj_requests SET status = ?, po_no = ?, po_date = ?, vendor_name = ? WHERE id = ?")
            ->execute([$ppbjNewStatus, $poSummary, $poDate, $vSummary, $postPpbjId]);

        $pdo->prepare("INSERT INTO ppbj_logs (ppbj_id, actor_name, actor_role, aksi, catatan) VALUES (?, ?, ?, ?, ?)")
            ->execute([$postPpbjId, $user['nama_lengkap'], 'Procurement', $logAction, "Vendor: {$vendorName} | Grand Total: " . rupiah($grandTotal)]);

        $pdo->commit();
        set_flash("{$orderType} {$poNo} berhasil disimpan.");
        redirect_to('index.php?page=po_list');
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        set_flash('Gagal menyimpan PO: ' . $e->getMessage(), 'error');
    }
}

$defaultOrderType = $existingPo['order_type'] ?? 'PURCHASE ORDER';
$defaultPoNo = $existingPo['po_no'] ?? next_po_no($pdo);
$defaultPoDate = $existingPo['po_date'] ?? date('Y-m-d');
$defaultVendorId = (int)($existingPo['vendor_id'] ?? ($vendors[0]['id'] ?? 0));
$defVendorMeta = $vendorMetaMap[$defaultVendorId] ?? ['address' => '-', 'contact' => '-', 'email' => '-'];

$defaultSellerAddr = $existingPo['seller_address'] ?? $defVendorMeta['address'];
$defaultSellerContact = $existingPo['seller_contact'] ?? $defVendorMeta['contact'];
$defaultSellerEmail = $existingPo['seller_email'] ?? $defVendorMeta['email'];
$paymentTermsOpts = po_payment_terms_options();
$pphOpts = po_pph_options();
$defaultTermin = $existingPo['termin_pembayaran'] ?? 'Credit, 30 days after receipt of the invoice and BAST / Delivery Note';
$isCustomTermin = !in_array($defaultTermin, $paymentTermsOpts, true);
$defaultTermsDeliv = $existingPo['terms_of_delivery'] ?? 'Franco PBS Site';
$defaultLeadTime = $existingPo['lead_time_delivery'] ?? '14 Days';
$defaultQuotRef = $existingPo['quotation_ref'] ?? '-';
$defaultEst = $existingPo['estimasi_kirim'] ?? ($selectedPpbj['received_date'] ?? date('Y-m-d', strtotime('+7 days')));
$defaultLoc = $existingPo['delivery_location'] ?? ($selectedPpbj['delivery_location'] ?? 'Dusun Pintu Rimba, Desa Glee Siblah, Kec. Woyla Induk, Meulaboh, Kab. Aceh Barat 23654');
$defaultDelivContact = $existingPo['delivery_contact'] ?? 'T Safril Nizam TM (082213151408)';
$defaultPurchaseRef = $existingPo['purchase_reference'] ?? ($selectedPpbj['request_no'] ?? '');
$defaultDivDept = $existingPo['division_dept'] ?? ($selectedPpbj['division_code'] ?: ($selectedPpbj['division_subdivision'] ?? 'OIT'));
$defaultPbsSigner = $existingPo['pbs_signer_name'] ?? $user['nama_lengkap'];
$defaultDelivFee = (float)($existingPo['delivery_fee'] ?? 0);
$defaultDiscount = (float)($existingPo['discount_amount'] ?? 0);
$defaultVatPct = (float)($existingPo['vat_percent'] ?? 0);
$defaultWhtPct = (float)($existingPo['withholding_tax_pct'] ?? 0);
$defaultWhtLabel = $existingPo['withholding_tax_label'] ?? '';
$defaultPphCode = 'NONE';
foreach ($pphOpts as $poOpt) {
    if ($defaultWhtLabel !== '' && strpos($defaultWhtLabel, $poOpt['keterangan']) !== false) {
        $defaultPphCode = $poOpt['code'];
        break;
    }
    if ($defaultWhtLabel === '' && $defaultWhtPct > 0 && abs((float)$poOpt['rate'] - $defaultWhtPct) < 0.001) {
        $defaultPphCode = $poOpt['code'];
        break;
    }
}
$defaultStatus = $existingPo['status'] ?? 'TERBIT';
?>

<form method="post">
  <div class="card">
    <div class="card-header">
      <div>
        <h1 class="card-title" style="font-size:18px;">
          <?= $existingPo ? 'Edit Order: ' . h($existingPo['po_no']) : 'Buat Purchase Order / Work Order (Sesuai Form Resmi PBS)' ?>
        </h1>
        <div style="font-size:12px;color:#64748b;">Pilih referensi Bid Summary / PPBJ dan Vendor — data Seller, Delivery Address, dan Item otomatis terisi tanpa ketik ulang.</div>
      </div>
      <div style="display:flex;gap:8px;">
        <?php if ($existingPo): ?>
          <a href="index.php?page=print_po&id=<?= (int)$existingPo['id'] ?>" target="_blank" class="btn btn-outline btn-sm">Cetak PO</a>
        <?php endif; ?>
        <a href="index.php?page=po_list" class="btn btn-outline btn-sm">&larr; Daftar PO</a>
      </div>
    </div>

    <?php if (!$existingPo): ?>
      <div class="grid-2" style="background:#f0f9ff;border:1px solid #bae6fd;border-radius:12px;padding:14px;margin-bottom:16px;">
        <div class="form-group" style="margin-bottom:0;">
          <label class="form-label" style="color:#0369a1;">Pilih dari Bid Summary</label>
          <select name="bid_id" class="form-control" onchange="if(this.value){window.location='index.php?page=po_form&bid_id='+this.value;}">
            <option value="">-- Pilih Bid Summary --</option>
            <?php foreach ($bidList as $b): ?>
              <option value="<?= (int)$b['id'] ?>" <?= $preBidId === (int)$b['id'] ? 'selected' : '' ?>>
                <?= h($b['bid_no']) ?> — <?= h($b['request_no']) ?> (<?= h($b['judul']) ?>)
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group" style="margin-bottom:0;">
          <label class="form-label" style="color:#0369a1;">Atau Pilih Referensi PPBJ</label>
          <select name="ppbj_id" class="form-control" onchange="if(this.value){window.location='index.php?page=po_form&ppbj_id='+this.value;}">
            <?php foreach ($ppbjList as $p): ?>
              <option value="<?= (int)$p['id'] ?>" <?= $prePpbjId === (int)$p['id'] ? 'selected' : '' ?>>
                <?= h($p['request_no']) ?> — <?= h($p['division_subdivision']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
    <?php else: ?>
      <input type="hidden" name="ppbj_id" value="<?= (int)$existingPo['ppbj_id'] ?>">
      <input type="hidden" name="bid_id" value="<?= (int)($existingPo['bid_id'] ?? 0) ?>">
    <?php endif; ?>

    <div class="grid-4">
      <div class="form-group">
        <label class="form-label">Jenis Dokumen *</label>
        <select name="order_type" class="form-control">
          <option value="PURCHASE ORDER" <?= $defaultOrderType === 'PURCHASE ORDER' ? 'selected' : '' ?>>PURCHASE ORDER (PO)</option>
          <option value="WORK ORDER" <?= $defaultOrderType === 'WORK ORDER' ? 'selected' : '' ?>>WORK ORDER (WO)</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">PBS Order No *</label>
        <input type="text" name="po_no" class="form-control" required value="<?= h($defaultPoNo) ?>">
      </div>
      <div class="form-group">
        <label class="form-label">Date *</label>
        <input type="date" name="po_date" class="form-control" required value="<?= h($defaultPoDate) ?>">
      </div>
      <div class="form-group">
        <label class="form-label">Status Order</label>
        <select name="status" class="form-control">
          <option value="DRAFT" <?= $defaultStatus === 'DRAFT' ? 'selected' : '' ?>>Draft PO</option>
          <option value="TERBIT" <?= $defaultStatus === 'TERBIT' ? 'selected' : '' ?>>PO Terbit</option>
          <option value="DALAM_PENGIRIMAN" <?= $defaultStatus === 'DALAM_PENGIRIMAN' ? 'selected' : '' ?>>Dalam Pengiriman</option>
          <option value="SELESAI_FTB" <?= $defaultStatus === 'SELESAI_FTB' ? 'selected' : '' ?>>Selesai (FTB)</option>
        </select>
      </div>
    </div>

    <div class="grid-2">
      <!-- Blok Seller -->
      <div class="disp-box">
        <h4>Seller (Penjual / Vendor)</h4>
        <div class="form-group">
          <label class="form-label">Pilih Vendor / Seller *</label>
          <select name="vendor_id" id="vendorSelect" class="form-control" required onchange="onVendorChange()">
            <?php foreach ($vendors as $v): ?>
              <option value="<?= (int)$v['id'] ?>" <?= $defaultVendorId === (int)$v['id'] ? 'selected' : '' ?>>
                <?= h($v['nama_vendor']) ?> (<?= h($v['kategori']) ?>)
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Alamat Seller</label>
          <input type="text" name="seller_address" id="sellerAddress" class="form-control" value="<?= h($defaultSellerAddr) ?>">
        </div>
        <div class="grid-2" style="margin-bottom:8px;">
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label">Contact person</label>
            <input type="text" name="seller_contact" id="sellerContact" class="form-control" value="<?= h($defaultSellerContact) ?>">
          </div>
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label">Email</label>
            <input type="text" name="seller_email" id="sellerEmail" class="form-control" value="<?= h($defaultSellerEmail) ?>">
          </div>
        </div>
        <div class="grid-2" style="margin-bottom:8px;">
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label">Terms of Payment</label>
            <select name="termin_pembayaran_select" id="terminSelect" class="form-control" onchange="toggleCustomTermin()">
              <?php foreach ($paymentTermsOpts as $ptOpt): ?>
                <option value="<?= h($ptOpt) ?>" <?= (!$isCustomTermin && $defaultTermin === $ptOpt) ? 'selected' : '' ?>>
                  <?= h($ptOpt) ?>
                </option>
              <?php endforeach; ?>
              <option value="__CUSTOM__" <?= $isCustomTermin ? 'selected' : '' ?>>Lainnya (Isi Manual)...</option>
            </select>
            <input type="text" name="termin_pembayaran_custom" id="terminCustomInput" class="form-control"
                   style="margin-top:6px;display:<?= $isCustomTermin ? 'block' : 'none' ?>;"
                   value="<?= h($isCustomTermin ? $defaultTermin : '') ?>" placeholder="Tulis Terms of Payment manual...">
          </div>
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label">Terms of Delivery</label>
            <input type="text" name="terms_of_delivery" class="form-control" value="<?= h($defaultTermsDeliv) ?>" placeholder="Franco PBS Site / Self Pick Up">
          </div>
        </div>
        <div class="grid-2" style="margin-bottom:0;">
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label">Lead time delivery</label>
            <input type="text" name="lead_time_delivery" class="form-control" value="<?= h($defaultLeadTime) ?>" placeholder="14 Days">
          </div>
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label">Quotation reference</label>
            <input type="text" name="quotation_ref" class="form-control" value="<?= h($defaultQuotRef) ?>" placeholder="011/TBU/XI/2026">
          </div>
        </div>
      </div>

      <!-- Blok Consignee & Delivery Address -->
      <div class="disp-box">
        <h4>Consignee &amp; Delivery Address</h4>
        <div style="background:#fff;border:1px solid #e2e8f0;border-radius:8px;padding:10px;font-size:12px;margin-bottom:10px;line-height:1.5;">
          <strong>PT. POTENSI BUMI SAKTI</strong><br>
          Sahid Sudirman Center 50th Floor Jl. Jend. Sudirman Kav 86,<br>
          Kel. Karet Tengsin Kec. Tanah Abang, Jakarta Pusat 10220<br>
          Phone no.: +62 21 5790 5519 / 5790 5520 &bull; NPWP: <strong>02.398.925.4-022.000</strong>
        </div>
        <div class="form-group">
          <label class="form-label">Delivery address *</label>
          <input type="text" name="delivery_location" class="form-control" required value="<?= h($defaultLoc) ?>">
        </div>
        <div class="grid-2" style="margin-bottom:8px;">
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label">Contact Person (Penerima Site)</label>
            <input type="text" name="delivery_contact" class="form-control" value="<?= h($defaultDelivContact) ?>">
          </div>
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label">Estimasi Tiba</label>
            <input type="date" name="estimasi_kirim" class="form-control" value="<?= h($defaultEst) ?>">
          </div>
        </div>
        <div class="grid-3" style="margin-bottom:0;">
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label">Purchase reference</label>
            <input type="text" name="purchase_reference" class="form-control" value="<?= h($defaultPurchaseRef) ?>">
          </div>
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label">Division / Department</label>
            <input type="text" name="division_dept" class="form-control" value="<?= h($defaultDivDept) ?>">
          </div>
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label">Penandatangan PBS</label>
            <input type="text" name="pbs_signer_name" class="form-control" value="<?= h($defaultPbsSigner) ?>">
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header">
      <div>
        <h2 class="card-title">Rincian Item, Delivery Fee, Discount &amp; VAT 11%</h2>
        <div style="font-size:12px;color:#64748b;">Centang item yang masuk ke PO ini. Anda dapat menambah item, menyesuaikan Qty, Price, Delivery Fee, Discount, dan VAT.</div>
      </div>
      <button type="button" onclick="addPoItemRow()" class="btn btn-green btn-sm">+ Tambah Baris Item</button>
    </div>

    <div class="table-wrap">
      <table class="data-table">
        <thead>
          <tr>
            <th style="width:45px;text-align:center;">Pilih</th>
            <th>Description</th>
            <th style="width:95px;">Qty</th>
            <th style="width:95px;">Unit</th>
            <th style="width:165px;">Price (Rp)</th>
            <th style="width:165px;text-align:right;">Amount (Rp)</th>
          </tr>
        </thead>
        <tbody id="poItemsBody">
          <?php foreach ($formItems as $idx => $fi): ?>
            <tr class="po-item-row">
              <td style="text-align:center;">
                <input type="checkbox" name="item_pick[]" value="<?= $idx ?>" <?= $fi['checked'] ? 'checked' : '' ?> class="po-chk" onchange="recalcPo()">
                <input type="hidden" name="item_ppbj_id[<?= $idx ?>]" value="<?= (int)$fi['ppbj_item_id'] ?>">
              </td>
              <td><input type="text" name="item_nama[<?= $idx ?>]" class="form-control" value="<?= h($fi['nama_barang_jasa']) ?>" required></td>
              <td><input type="number" step="0.01" min="0.01" name="item_qty[<?= $idx ?>]" class="form-control po-qty" value="<?= h((string)$fi['qty']) ?>" oninput="recalcPo()"></td>
              <td><input type="text" name="item_satuan[<?= $idx ?>]" class="form-control" value="<?= h($fi['satuan']) ?>"></td>
              <td><input type="number" step="100" min="0" name="item_harga[<?= $idx ?>]" class="form-control po-price" value="<?= h((string)$fi['harga_satuan']) ?>" oninput="recalcPo()"></td>
              <td class="po-sub" style="text-align:right;font-weight:700;white-space:nowrap;"><?= rupiah($fi['qty'] * $fi['harga_satuan']) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <div class="grid-2" style="margin-top:16px;align-items:start;">
      <div class="form-group">
        <label class="form-label">Catatan Tambahan Internal / Spesifikasi</label>
        <textarea name="catatan" class="form-control" rows="4" placeholder="Catatan tambahan (opsional)..."><?= h($existingPo['catatan'] ?? '') ?></textarea>
      </div>

      <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;padding:14px;">
        <div style="display:flex;justify-content:space-between;margin-bottom:8px;font-size:13px;">
          <strong>Sub Total</strong>
          <strong id="poSubTotal">Rp 0</strong>
        </div>
        <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:8px;font-size:13px;">
          <span>Delivery Fee (Rp)</span>
          <input type="number" step="1000" min="0" name="delivery_fee" id="delivFeeInput" class="form-control" style="max-width:170px;text-align:right;" value="<?= h((string)$defaultDelivFee) ?>" oninput="recalcPo()">
        </div>
        <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:8px;font-size:13px;">
          <span>Discount (Rp)</span>
          <input type="number" step="1000" min="0" name="discount_amount" id="discountInput" class="form-control" style="max-width:170px;text-align:right;" value="<?= h((string)$defaultDiscount) ?>" oninput="recalcPo()">
        </div>
        <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:8px;font-size:13px;">
          <span>VAT (%) <button type="button" class="btn btn-outline btn-sm" style="padding:2px 6px;font-size:11px;" onclick="setVat(11)">Set 11%</button> <button type="button" class="btn btn-outline btn-sm" style="padding:2px 6px;font-size:11px;" onclick="setVat(0)">0%</button></span>
          <div style="display:flex;align-items:center;gap:6px;">
            <input type="number" step="0.1" min="0" max="100" name="vat_percent" id="vatPctInput" class="form-control" style="width:75px;text-align:right;" value="<?= h((string)$defaultVatPct) ?>" oninput="recalcPo()">
            <span id="poVatAmt" style="min-width:110px;text-align:right;font-weight:600;">Rp 0</span>
          </div>
        </div>
        <div style="margin-bottom:10px;padding-top:8px;border-top:1px dashed #cbd5e1;">
          <label class="form-label" style="font-size:12.5px;margin-bottom:4px;display:block;">Opsi PPh (Estimated Withholding Tax)</label>
          <select name="pph_option_code" id="pphSelect" class="form-control" style="font-size:12px;margin-bottom:6px;" onchange="onPphChange()">
            <?php foreach ($pphOpts as $poOpt): ?>
              <option value="<?= h($poOpt['code']) ?>" data-rate="<?= h((string)$poOpt['rate']) ?>" <?= $defaultPphCode === $poOpt['code'] ? 'selected' : '' ?>>
                <?= h($poOpt['label']) ?>
              </option>
            <?php endforeach; ?>
          </select>
          <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;font-size:12.5px;color:#475569;">
            <span>Rate PPh (%)</span>
            <div style="display:flex;align-items:center;gap:6px;">
              <input type="number" step="0.05" min="0" max="100" name="withholding_tax_pct" id="whtPctInput" class="form-control" style="width:85px;text-align:right;" value="<?= h((string)$defaultWhtPct) ?>" oninput="recalcPo()">
              <span id="poWhtAmt" style="min-width:110px;text-align:right;font-weight:600;color:#64748b;">Rp 0</span>
            </div>
          </div>
        </div>
        <div style="border-top:2px solid #cbd5e1;padding-top:10px;display:flex;justify-content:space-between;font-size:16px;font-weight:800;color:#007AB3;">
          <span>Grand Total</span>
          <span id="poGrandTotal">Rp 0</span>
        </div>
      </div>
    </div>

    <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:18px;">
      <a href="index.php?page=po_list" class="btn btn-outline">Batal</a>
      <button type="submit" class="btn btn-primary"><?= $existingPo ? 'Simpan Perubahan Order' : 'Terbitkan Order' ?></button>
    </div>
  </div>
</form>

<script>
const vendorMetaMap = <?= json_encode($vendorMetaMap, JSON_UNESCAPED_UNICODE) ?>;
let nextRowIdx = <?= count($formItems) ?>;

function onVendorChange() {
  const vid = document.getElementById('vendorSelect').value;
  const meta = vendorMetaMap[vid];
  if (!meta) return;
  document.getElementById('sellerAddress').value = meta.address;
  document.getElementById('sellerContact').value = meta.contact;
  document.getElementById('sellerEmail').value = meta.email;
}

function toggleCustomTermin() {
  const sel = document.getElementById('terminSelect');
  const inp = document.getElementById('terminCustomInput');
  if (!sel || !inp) return;
  inp.style.display = sel.value === '__CUSTOM__' ? 'block' : 'none';
}

function onPphChange() {
  const sel = document.getElementById('pphSelect');
  const inp = document.getElementById('whtPctInput');
  if (!sel || !inp) return;
  const opt = sel.options[sel.selectedIndex];
  const rate = opt ? parseFloat(opt.getAttribute('data-rate') || '0') : 0;
  inp.value = rate;
  recalcPo();
}

function setVat(pct) {
  document.getElementById('vatPctInput').value = pct;
  recalcPo();
}

function addPoItemRow() {
  const tbody = document.getElementById('poItemsBody');
  const idx = nextRowIdx++;
  const tr = document.createElement('tr');
  tr.className = 'po-item-row';
  tr.innerHTML = `
    <td style="text-align:center;">
      <input type="checkbox" name="item_pick[]" value="${idx}" checked class="po-chk" onchange="recalcPo()">
      <input type="hidden" name="item_ppbj_id[${idx}]" value="">
    </td>
    <td><input type="text" name="item_nama[${idx}]" class="form-control" required placeholder="Deskripsi barang/jasa"></td>
    <td><input type="number" step="0.01" min="0.01" name="item_qty[${idx}]" class="form-control po-qty" value="1" oninput="recalcPo()"></td>
    <td><input type="text" name="item_satuan[${idx}]" class="form-control" value="Pcs"></td>
    <td><input type="number" step="100" min="0" name="item_harga[${idx}]" class="form-control po-price" value="0" oninput="recalcPo()"></td>
    <td class="po-sub" style="text-align:right;font-weight:700;white-space:nowrap;">Rp 0</td>
  `;
  tbody.appendChild(tr);
  recalcPo();
}

function fmtRp(n) {
  return 'Rp ' + Math.round(n).toLocaleString('id-ID');
}

function recalcPo() {
  let subTotal = 0;
  document.querySelectorAll('.po-item-row').forEach(row => {
    const chk = row.querySelector('.po-chk').checked;
    const q = parseFloat(row.querySelector('.po-qty').value || 0);
    const p = parseFloat(row.querySelector('.po-price').value || 0);
    const lineAmt = q * p;
    if (chk) subTotal += lineAmt;
    row.querySelector('.po-sub').textContent = fmtRp(lineAmt);
    row.style.opacity = chk ? '1' : '0.45';
  });
  const deliv = parseFloat(document.getElementById('delivFeeInput').value || 0);
  const disc = parseFloat(document.getElementById('discountInput').value || 0);
  const vatPct = parseFloat(document.getElementById('vatPctInput').value || 0);
  const vatAmt = subTotal * (vatPct / 100);
  const whtPct = parseFloat((document.getElementById('whtPctInput') || {}).value || 0);
  const pphSel = document.getElementById('pphSelect');
  const pphCode = pphSel ? pphSel.value : 'NONE';
  const whtAmt = subTotal * (whtPct / 100);
  const grand = Math.max(0, subTotal + deliv - disc + vatAmt);

  document.getElementById('poSubTotal').textContent = fmtRp(subTotal);
  document.getElementById('poVatAmt').textContent = fmtRp(vatAmt);
  const whtEl = document.getElementById('poWhtAmt');
  if (whtEl) {
    if (pphCode === 'PPH21_PROG' && whtPct === 0) {
      whtEl.textContent = 'Progresif (PPh 21)';
    } else {
      whtEl.textContent = whtPct > 0 ? fmtRp(whtAmt) : 'Rp 0';
    }
  }
  document.getElementById('poGrandTotal').textContent = fmtRp(grand);
}
recalcPo();
</script>
