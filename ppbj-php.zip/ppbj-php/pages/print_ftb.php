<?php
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("SELECT * FROM ftb_receipts WHERE id = ?");
$stmt->execute([$id]);
$ftb = $stmt->fetch();
if (!$ftb) { die('Data FTB tidak ditemukan.'); }

$stmt2 = $pdo->prepare("SELECT * FROM ftb_items WHERE ftb_id = ? ORDER BY item_no ASC");
$stmt2->execute([$id]);
$items = $stmt2->fetchAll();
$logo = logo_src();
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <title>Cetak FTB <?= h($ftb['ftb_no']) ?></title>
  <style>
    body { font-family: Arial, Helvetica, sans-serif; color: #111; margin: 20px; font-size: 11px; }
    .toolbar { margin-bottom: 16px; display: flex; gap: 8px; }
    .btn { padding: 8px 14px; border-radius: 6px; border: 1px solid #cbd5e1; background: #fff; cursor: pointer; font-weight: 700; text-decoration: none; color: #111; font-size: 12px; }
    .btn-green { background: #008A3B; color: #fff; border-color: #008A3B; }
    .sheet { max-width: 920px; margin: 0 auto; border: 2px solid #000; padding: 14px; }
    table { width: 100%; border-collapse: collapse; }
    th, td { border: 1px solid #000; padding: 6px 8px; vertical-align: top; }
    .check-box { display: inline-block; width: 12px; height: 12px; border: 1px solid #000; text-align: center; line-height: 11px; font-weight: 700; margin-right: 5px; }
    @media print { .toolbar { display: none; } body { margin: 0; } .sheet { border-width: 1px; } }
  </style>
</head>
<body>
<div class="toolbar">
  <button onclick="window.print()" class="btn btn-green">Cetak FTB / Simpan PDF</button>
  <a href="index.php?page=ftb_list" class="btn">&larr; Kembali ke Daftar FTB</a>
</div>

<div class="sheet">
  <table style="margin-bottom:8px;">
    <tr>
      <td rowspan="4" style="width:95px;text-align:center;vertical-align:middle;">
        <img src="<?= h($logo) ?>" alt="Logo PBS" style="width:74px;height:74px;object-fit:contain;">
      </td>
      <td rowspan="2" style="text-align:center;vertical-align:middle;font-size:15px;font-weight:800;">
        PT. POTENSI BUMI SAKTI
      </td>
      <td style="width:110px;">Nomor</td>
      <td style="width:140px;">: <strong><?= h($ftb['ftb_no']) ?></strong></td>
    </tr>
    <tr>
      <td>Tanggal Terbit</td>
      <td>: <?= h($ftb['doc_issue_date']) ?></td>
    </tr>
    <tr>
      <td rowspan="2" style="text-align:center;vertical-align:middle;font-size:13px;font-weight:800;">
        FORMULIR TERIMA BARANG/JASA (FTB)
      </td>
      <td>Revisi</td>
      <td>: <?= h($ftb['doc_revision']) ?></td>
    </tr>
    <tr>
      <td>Tanggal Revisi</td>
      <td>: -</td>
    </tr>
  </table>

  <div style="display:flex;justify-content:space-between;margin:8px 2px;font-weight:700;">
    <span>Telah diterima sebagai berikut / We have received as follows</span>
    <span>Tgl / Date of FTB : <?= tgl_indo($ftb['ftb_date']) ?></span>
  </div>

  <table style="margin-bottom:8px;">
    <tr>
      <td colspan="2" style="background:#f1f5f9;font-weight:700;">
        <span class="check-box"><?= $ftb['sumber_penerimaan'] === 'PEMBELIAN_BARU' ? '&#10003;' : '&nbsp;' ?></span>
        PEMBELIAN BARU DARI / NEW PURCHASE FROM
      </td>
    </tr>
    <tr>
      <td style="width:55%;">Penjual / Seller : <strong><?= h($ftb['penjual_seller'] ?: '-') ?></strong></td>
      <td>PO no. : <strong><?= h($ftb['po_no'] ?: '-') ?></strong></td>
    </tr>
    <tr>
      <td>SJ no. / DO no. : <strong><?= h($ftb['sj_do_no'] ?: '-') ?></strong></td>
      <td>Tgl PO / PO Date : <strong><?= tgl_indo($ftb['po_date']) ?></strong></td>
    </tr>
    <tr>
      <td colspan="2" style="background:#f1f5f9;font-weight:700;">
        <span class="check-box"><?= $ftb['sumber_penerimaan'] === 'BARANG_RETUR' ? '&#10003;' : '&nbsp;' ?></span>
        BARANG RETUR DARI / RETURNED GOODS FROM
      </td>
    </tr>
    <tr>
      <td>Divisi Pemakai / User Div. : <strong><?= h($ftb['retur_divisi'] ?: '-') ?></strong></td>
      <td>Nama / Name : <strong><?= h($ftb['retur_nama'] ?: '-') ?></strong></td>
    </tr>
    <tr>
      <td colspan="2">Di Lokasi Gudang / At Warehouse Location : <strong><?= h($ftb['lokasi_gudang']) ?></strong></td>
    </tr>
  </table>

  <div style="font-weight:700;margin:6px 2px;">Perincian Barang atau Jasa / Description of Goods or Services:</div>
  <table style="margin-bottom:6px;">
    <thead>
      <tr style="background:#f1f5f9;text-align:center;">
        <th style="width:35px;">No.</th>
        <th>Perincian*) / Description*)</th>
        <th style="width:65px;">Jml / Qty</th>
        <th style="width:65px;">Unit</th>
        <th style="width:190px;">Catatan Kondisi /<br>Remarks of Condition</th>
        <th style="width:125px;">Accepted / Rejected</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($items as $it): ?>
        <tr>
          <td style="text-align:center;"><?= (int)$it['item_no'] ?></td>
          <td><strong><?= h($it['perincian']) ?></strong></td>
          <td style="text-align:center;"><?= rtrim(rtrim((string)$it['qty'], '0'), '.') ?></td>
          <td style="text-align:center;"><?= h($it['unit']) ?></td>
          <td><?= h($it['catatan_kondisi']) ?></td>
          <td style="text-align:center;">
            <strong><?= h($it['status_penerimaan']) ?></strong>
            <div style="font-size:10px;color:#444;">
              Acc: <?= rtrim(rtrim((string)$it['qty_accepted'], '0'), '.') ?> |
              Rej: <?= rtrim(rtrim((string)$it['qty_rejected'], '0'), '.') ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php for ($b = count($items); $b < 10; $b++): ?>
        <tr><td>&nbsp;</td><td></td><td></td><td></td><td></td><td></td></tr>
      <?php endfor; ?>
    </tbody>
  </table>

  <div style="font-size:10px;margin-bottom:14px;">*) Nama &amp; spesifikasi barang / Name &amp; specification of goods</div>

  <table>
    <tr style="background:#f1f5f9;text-align:center;font-weight:700;">
      <td style="width:50%;">Pemakai (User) / Gudang (Warehouse)</td>
      <td style="width:50%;">Procurement</td>
    </tr>
    <tr>
      <td style="text-align:center;">
        <div style="height:54px;"></div>
        <div>( <strong><?= h($ftb['pemakai_gudang_nama']) ?></strong> )</div>
        <div style="margin-top:4px;font-size:10px;">Jabatan / Position : <?= h($ftb['pemakai_gudang_jabatan']) ?></div>
      </td>
      <td style="text-align:center;">
        <div style="height:54px;"></div>
        <div>( <strong><?= h($ftb['procurement_nama']) ?></strong> )</div>
        <div style="margin-top:4px;font-size:10px;">Jabatan / Position : <?= h($ftb['procurement_jabatan']) ?></div>
      </td>
    </tr>
  </table>
</div>
</body>
</html>
