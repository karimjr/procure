<?php
$vendors = $pdo->query("SELECT * FROM vendors WHERE aktif = 1 ORDER BY id ASC")->fetchAll();
$logoData = logo_src();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Formulir Daftar Penyedia Eksternal Terpilih - PT. Potensi Bumi Sakti</title>
<style>
  @page { size: A4 landscape; margin: 10mm; }
  * { box-sizing: border-box; }
  body { font-family: Arial, Helvetica, sans-serif; color: #111; font-size: 10px; margin: 0; padding: 14px; background: #f1f5f9; }
  .toolbar { max-width: 1120px; margin: 0 auto 10px; display: flex; justify-content: space-between; align-items: center; }
  .btn { padding: 7px 14px; border-radius: 6px; border: 1px solid #cbd5e1; background: #fff; font-weight: 700; font-size: 12px; cursor: pointer; text-decoration: none; color: #0f172a; }
  .btn-print { background: #007AB3; color: #fff; border-color: #007AB3; }
  .sheet { max-width: 1120px; margin: 0 auto; background: #fff; padding: 14px; border: 1px solid #cbd5e1; }
  table.hdr { width: 100%; border-collapse: collapse; margin-bottom: 10px; }
  table.hdr td { border: 1px solid #000; padding: 4px 8px; }
  table.list { width: 100%; border-collapse: collapse; }
  table.list th, table.list td { border: 1px solid #000; padding: 4px 6px; vertical-align: top; }
  table.list th { background: #e2e8f0; text-align: center; font-weight: 700; font-size: 9.5px; }
  @media print {
    body { background: #fff; padding: 0; }
    .toolbar { display: none; }
    .sheet { border: none; padding: 0; max-width: none; }
  }
</style>
</head>
<body>
<div class="toolbar">
  <a href="index.php?page=vendors" class="btn">&larr; Kembali ke Master Vendor</a>
  <button onclick="window.print()" class="btn btn-print">Cetak / Simpan PDF</button>
</div>
<div class="sheet">
  <table class="hdr">
    <tr>
      <td rowspan="4" style="width:18%;text-align:center;vertical-align:middle;">
        <?php if ($logoData): ?>
          <img src="<?= h($logoData) ?>" alt="PT Potensi Bumi Sakti" style="max-height:54px;max-width:150px;">
        <?php endif; ?>
      </td>
      <td rowspan="2" style="text-align:center;font-weight:700;font-size:13px;">PT POTENSI BUMI SAKTI</td>
      <td style="width:11%;font-weight:700;">No.Dokumen</td>
      <td style="width:13%;">FRM.APR.01.0?</td>
    </tr>
    <tr>
      <td style="font-weight:700;">Tgl. Terbit</td>
      <td>27/05/2026</td>
    </tr>
    <tr>
      <td rowspan="2" style="text-align:center;font-weight:700;font-size:12px;">FORMULIR DAFTAR PENYEDIA EKSTERNAL TERPILIH</td>
      <td style="font-weight:700;">Revisi</td>
      <td>00</td>
    </tr>
    <tr>
      <td style="font-weight:700;">Tgl. Revisi</td>
      <td>-</td>
    </tr>
  </table>

  <table class="list">
    <thead>
      <tr>
        <th style="width:28px;">NO.</th>
        <th style="width:150px;">NAMA PENYEDIA EKSTERNAL</th>
        <th style="width:95px;">NO. REKENING</th>
        <th style="width:120px;">AN. REKENING BANK</th>
        <th style="width:105px;">NAMA BANK</th>
        <th style="width:215px;">ALAMAT TOKO</th>
        <th style="width:125px;">NO. TELP PENYEDIA EKSTERNAL</th>
        <th>ITEM YANG DIJUAL</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($vendors as $i => $v): ?>
        <tr>
          <td style="text-align:center;"><?= $i + 1 ?></td>
          <td><strong><?= h($v['nama_vendor']) ?></strong></td>
          <td><?= h($v['no_rekening'] ?: '-') ?></td>
          <td><?= h($v['an_rekening'] ?: '-') ?></td>
          <td><?= h($v['nama_bank'] ?: '-') ?></td>
          <td><?= h($v['alamat'] ?: '-') ?></td>
          <td><?= h($v['telepon'] ?: '-') ?></td>
          <td><?= h($v['item_dijual'] ?: $v['kategori']) ?></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
</body>
</html>
