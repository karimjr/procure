<?php
$role = $user['role'];
$canManageDiv = ($role === 'ADMIN');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$canManageDiv) {
        set_flash('Akses Ditolak: Pengelolaan Master Divisi hanya dapat dilakukan oleh Super Admin.', 'error');
        redirect_to('index.php?page=divisions');
    }
    $act = $_POST['act'] ?? 'add';
    try {
        if ($act === 'add') {
            $kode = normalize_div_code($_POST['kode_divisi'] ?? '');
            $nama = trim($_POST['nama_divisi'] ?? '');
            $lokasi = trim($_POST['lokasi_default'] ?? 'Dusun Pintu Rimba Glee Siblah Woyla Aceh');
            if ($kode === '' || $nama === '') {
                throw new RuntimeException('Kode Divisi dan Nama Divisi wajib diisi.');
            }
            $pdo->prepare("INSERT INTO divisions (kode_divisi, nama_divisi, lokasi_default, aktif) VALUES (?, ?, ?, 1)")
                ->execute([$kode, $nama, $lokasi]);
            set_flash("Divisi {$nama} (kode: PBS-{$kode}) berhasil ditambahkan. Penomoran PPBJ otomatis dimulai dari 001/PPBJ/.../PBS-{$kode}.");
        } elseif ($act === 'edit') {
            $divId = (int)($_POST['div_id'] ?? 0);
            $kode = normalize_div_code($_POST['kode_divisi'] ?? '');
            $nama = trim($_POST['nama_divisi'] ?? '');
            $lokasi = trim($_POST['lokasi_default'] ?? '');
            $aktif = isset($_POST['aktif']) ? 1 : 0;
            if ($divId <= 0 || $kode === '' || $nama === '') {
                throw new RuntimeException('Data divisi tidak valid.');
            }
            $pdo->prepare("UPDATE divisions SET kode_divisi = ?, nama_divisi = ?, lokasi_default = ?, aktif = ? WHERE id = ?")
                ->execute([$kode, $nama, $lokasi, $aktif, $divId]);
            set_flash("Divisi {$nama} berhasil diperbarui.");
        } elseif ($act === 'toggle') {
            $divId = (int)($_POST['div_id'] ?? 0);
            $pdo->prepare("UPDATE divisions SET aktif = IF(aktif = 1, 0, 1) WHERE id = ?")->execute([$divId]);
            set_flash('Status aktif divisi berhasil diubah.');
        }
        redirect_to('index.php?page=divisions');
    } catch (Throwable $e) {
        set_flash('Gagal memproses divisi: ' . $e->getMessage(), 'error');
    }
}

$editDiv = null;
if ($canManageDiv && isset($_GET['edit_id'])) {
    $st = $pdo->prepare("SELECT * FROM divisions WHERE id = ?");
    $st->execute([(int)$_GET['edit_id']]);
    $editDiv = $st->fetch();
}

$divisions = $pdo->query("SELECT * FROM divisions ORDER BY id ASC")->fetchAll();
?>

<?php if ($canManageDiv): ?>
<div class="card">
  <div class="card-header">
    <div>
      <h1 class="card-title" style="font-size:18px;">
        <?= $editDiv ? 'Edit Divisi: ' . h($editDiv['nama_divisi']) : 'Kelola Master Divisi (Dikelola Super Admin)' ?>
      </h1>
      <div style="font-size:12px;color:#64748b;">
        Setiap divisi memiliki urutan nomor PPBJ otomatis sendiri (contoh: <code>001/PPBJ/XI-2026/PBS-OIT</code> untuk IT, dan <code>001/PPBJ/XI-2026/PBS-FIN</code> untuk Finance).
      </div>
    </div>
    <?php if ($editDiv): ?>
      <a href="index.php?page=divisions" class="btn btn-outline btn-sm">Batal Edit</a>
    <?php endif; ?>
  </div>

  <form method="post">
    <input type="hidden" name="act" value="<?= $editDiv ? 'edit' : 'add' ?>">
    <?php if ($editDiv): ?>
      <input type="hidden" name="div_id" value="<?= (int)$editDiv['id'] ?>">
    <?php endif; ?>

    <div class="grid-3">
      <div class="form-group">
        <label class="form-label">Kode Divisi (Akhiran No. PPBJ) *</label>
        <input type="text" name="kode_divisi" class="form-control" required maxlength="20"
               value="<?= h($editDiv['kode_divisi'] ?? '') ?>"
               placeholder="Misal: OIT, FIN, HRD, OPS, WKS"
               style="text-transform:uppercase;">
        <div style="font-size:11px;color:#64748b;margin-top:4px;">Otomatis menjadi akhiran <code>/PBS-KODE</code> (contoh: <code>OIT</code> &rarr; <code>PBS-OIT</code>).</div>
      </div>
      <div class="form-group">
        <label class="form-label">Nama Divisi &amp; Sub Divisi *</label>
        <input type="text" name="nama_divisi" class="form-control" required
               value="<?= h($editDiv['nama_divisi'] ?? '') ?>"
               placeholder="Misal: Divisi IT &amp; Operational IT">
      </div>
      <div class="form-group">
        <label class="form-label">Lokasi Pengiriman Default</label>
        <input type="text" name="lokasi_default" class="form-control"
               value="<?= h($editDiv['lokasi_default'] ?? 'Dusun Pintu Rimba Glee Siblah Woyla Aceh') ?>">
      </div>
    </div>

    <?php if ($editDiv): ?>
      <div class="form-group">
        <label style="display:inline-flex;align-items:center;gap:8px;font-size:13px;font-weight:600;cursor:pointer;">
          <input type="checkbox" name="aktif" value="1" <?= (int)$editDiv['aktif'] === 1 ? 'checked' : '' ?>>
          Divisi Aktif (muncul di pilihan Ajukan PPBJ)
        </label>
      </div>
    <?php endif; ?>

    <button type="submit" class="btn btn-primary"><?= $editDiv ? 'Simpan Perubahan Divisi' : '+ Tambah Divisi Baru' ?></button>
  </form>
</div>
<?php else: ?>
<div class="card">
  <div class="flash" style="background:#eff6ff;color:#1e40af;border:1px solid #bfdbfe;margin-bottom:0;">
    Master Divisi dikelola oleh tim <strong>Procurement</strong>. Penambahan atau perubahan divisi dilakukan melalui akun Procurement.
  </div>
</div>
<?php endif; ?>

<div class="card">
  <div class="card-header">
    <div>
      <h2 class="card-title">Daftar Divisi &amp; Penomoran PPBJ Otomatis Per Divisi</h2>
      <div style="font-size:12px;color:#64748b;">Masing-masing divisi berjalan berurutan dari <code>001</code> tanpa mengikuti nomor divisi lain.</div>
    </div>
  </div>

  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th>Kode</th>
          <th>Nama Divisi &amp; Sub Divisi</th>
          <th>Lokasi Pengiriman Default</th>
          <th style="text-align:center;">PPBJ Terbit</th>
          <th>Nomor PPBJ Otomatis Berikutnya</th>
          <th>Status</th>
          <?php if ($canManageDiv): ?><th>Aksi</th><?php endif; ?>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($divisions as $d):
            $code = $d['kode_divisi'];
            $cntSt = $pdo->prepare("SELECT COUNT(*) FROM ppbj_requests WHERE division_code = ? OR request_no LIKE ?");
            $cntSt->execute([$code, '%/PBS-' . $code]);
            $cnt = (int)$cntSt->fetchColumn();
            $nextNo = next_ppbj_no($pdo, $code);
        ?>
          <tr>
            <td><span class="badge badge-blue">PBS-<?= h($code) ?></span></td>
            <td><strong><?= h($d['nama_divisi']) ?></strong></td>
            <td style="font-size:12.5px;color:#475569;"><?= h($d['lokasi_default']) ?></td>
            <td style="text-align:center;font-weight:700;"><?= $cnt ?></td>
            <td><code style="background:#f1f5f9;padding:4px 8px;border-radius:6px;font-weight:700;color:#007AB3;"><?= h($nextNo) ?></code></td>
            <td>
              <?php if ((int)$d['aktif'] === 1): ?>
                <span class="badge badge-green">Aktif</span>
              <?php else: ?>
                <span class="badge badge-slate">Nonaktif</span>
              <?php endif; ?>
            </td>
            <?php if ($canManageDiv): ?>
            <td style="white-space:nowrap;">
              <a href="index.php?page=divisions&edit_id=<?= (int)$d['id'] ?>" class="btn btn-outline btn-sm">Edit</a>
              <form method="post" style="display:inline;">
                <input type="hidden" name="act" value="toggle">
                <input type="hidden" name="div_id" value="<?= (int)$d['id'] ?>">
                <button type="submit" class="btn btn-outline btn-sm"><?= (int)$d['aktif'] === 1 ? 'Nonaktifkan' : 'Aktifkan' ?></button>
              </form>
            </td>
            <?php endif; ?>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
