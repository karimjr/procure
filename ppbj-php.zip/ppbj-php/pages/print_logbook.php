<?php
$filters = [
    'q' => trim($_GET['q'] ?? ''),
    'divisi' => trim($_GET['divisi'] ?? ''),
    'status' => trim($_GET['status'] ?? ''),
    'jalur' => trim($_GET['jalur'] ?? ''),
    'date_from' => trim($_GET['date_from'] ?? ''),
    'date_to' => trim($_GET['date_to'] ?? ''),
];
$rows = fetch_logbook_rows($pdo, $user, $filters);
$logoData = logo_src();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Logbook Procurement - PT. Potensi Bumi Sakti</title>
<style>
  @page { size: A4 landscape; margin: 10mm; }
  * { box-sizing: border-box; }
  body { font-family: Arial, Helvetica, sans-serif; color: #111; font-size: 9.5px; margin: 0; padding: 14px; background: #f1f5f9; }
  .toolbar { max-width: 1180px; margin: 0 auto 10px; display: flex; justify-content: space-between; align-items: center; }
  .btn { padding: 7px 14px; border-radius: 6px; border: 1px solid #cbd5e1; background: #fff; font-weight: 700; font-size: 12px; cursor: pointer; text-decoration: none; color: #0f172a; }
  .btn-print { background: #007AB3; color: #fff; border-color: #007AB3; }
  .sheet { max-width: 1180px; margin: 0 auto; background: #fff; padding: 14px; border: 1px solid #cbd5e1; }
  table.hdr { width: 100%; border-collapse: collapse; margin-bottom: 10px; }
  table.hdr td { border: 1px solid #000; padding: 4px 8px; }
  table.list { width: 100%; border-collapse: collapse; }
  table.list th, table.list td { border: 1px solid #000; padding: 4px 5px; vertical-align: top; }
  table.list th { background: #e2e8f0; text-align: center; font-weight: 700; font-size: 9px; }
  @media print {
    body { background: #fff; padding: 0; }
    .toolbar { display: none; }
    .sheet { border: none; padding: 0; max-width: none; }
  }
</style>
</head>
<body>
<div class="toolbar">
  <a href="index.php?page=logbook" class="btn">&larr; Kembali ke Logbook Procurement</a>
  <button onclick="window.print()" class="btn btn-print">Cetak / Simpan PDF</button>
</div>
<div class="sheet">
  <table class="hdr">
    <tr>
      <td rowspan="3" style="width:16%;text-align:center;vertical-align:middle;">
        <?php if ($logoData): ?>
          <img src="<?= h($logoData) ?>" alt="PT Potensi Bumi Sakti" style="max-height:48px;max-width:140px;">
        <?php endif; ?>
      </td>
      <td style="text-align:center;font-weight:700;font-size:13px;">PT. POTENSI BUMI SAKTI</td>
      <td style="width:12%;font-weight:700;">Tanggal Cetak</td>
      <td style="width:14%;"><?= h(tgl_indo(date('Y-m-d'))) ?></td>
    </tr>
    <tr>
      <td rowspan="2" style="text-align:center;font-weight:700;font-size:12px;">LOGBOOK MONITORING PROCUREMENT (PPBJ &rarr; APPROVAL &rarr; BID &rarr; PO &rarr; FTB)</td>
      <td style="font-weight:700;">Dicetak Oleh</td>
      <td><?= h($user['nama_lengkap']) ?></td>
    </tr>
    <tr>
      <td style="font-weight:700;">Total Baris</td>
      <td><?= count($rows) ?> item</td>
    </tr>
  </table>

  <table class="list">
    <thead>
      <tr>
        <th>No</th>
        <th>No. PPBJ &amp; Tgl</th>
        <th>Divisi / Pemohon</th>
        <th>Nama Barang / Jasa</th>
        <th>Qty</th>
        <th>Jalur</th>
        <th>Tgl Appr (Mgr / Ops / Keu)</th>
        <th>No. Bid</th>
        <th>No. PO &amp; Tgl</th>
        <th>Vendor Pemenang</th>
        <th>Budget (Rp)</th>
        <th>Realisasi (Rp)</th>
        <th>No. FTB &amp; Tgl</th>
        <th>Status</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($rows as $i => $r):
        [$sLabel] = status_meta($r['ppbj_status']);
        $vendor = $r['po_vendor_name'] ?: ($r['bid_winner_vendor'] ?: '-');
        $real = $r['po_subtotal'] !== null ? (float)$r['po_subtotal'] : ((float)($r['bid_winner_total'] ?? 0));
      ?>
        <tr>
          <td style="text-align:center;"><?= $i + 1 ?></td>
          <td><strong><?= h($r['request_no']) ?></strong><br><?= h(tgl_indo($r['request_date'])) ?></td>
          <td><?= h($r['division_code'] ?: $r['division_subdivision']) ?><br><?= h($r['applied_by_name']) ?></td>
          <td><?= h($r['nama_barang_jasa']) ?></td>
          <td style="white-space:nowrap;"><?= rtrim(rtrim((string)$r['jumlah'], '0'), '.') ?> <?= h($r['satuan']) ?></td>
          <td style="text-align:center;"><?= ($r['jalur_pengadaan'] ?? 'PO') === 'NON_PO' ? 'Non PO' : 'PO' ?></td>
          <td style="white-space:nowrap;">
            M: <?= $r['manager_date'] ? h(date('d/m/y', strtotime($r['manager_date']))) : '-' ?><br>
            O: <?= $r['dir_ops_date'] ? h(date('d/m/y', strtotime($r['dir_ops_date']))) : '-' ?><br>
            K: <?= $r['dir_keu_date'] ? h(date('d/m/y', strtotime($r['dir_keu_date']))) : '-' ?>
          </td>
          <td><?= h($r['bid_no'] ?: '-') ?></td>
          <td><?= h($r['po_no'] ?: (($r['jalur_pengadaan'] ?? 'PO') === 'NON_PO' ? 'NON-PO' : '-')) ?><?= $r['po_date'] ? '<br>' . h(tgl_indo($r['po_date'])) : '' ?></td>
          <td><?= h($vendor) ?></td>
          <td style="text-align:right;white-space:nowrap;"><?= number_format((float)$r['harga_anggaran'], 0, ',', '.') ?></td>
          <td style="text-align:right;white-space:nowrap;"><?= $real > 0 ? number_format($real, 0, ',', '.') : '-' ?></td>
          <td><?= h($r['ftb_no'] ?: '-') ?><?= $r['ftb_date'] ? '<br>' . h(tgl_indo($r['ftb_date'])) : '' ?></td>
          <td><strong><?= h($sLabel) ?></strong></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
</body>
</html>
