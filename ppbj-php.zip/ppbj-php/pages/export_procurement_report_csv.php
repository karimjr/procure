<?php
if ($user['role'] === 'PEMOHON') {
    die('Akses Ditolak.');
}

$filters = [
    'date_from' => trim($_GET['date_from'] ?? ''),
    'date_to' => trim($_GET['date_to'] ?? ''),
    'divisi' => trim($_GET['divisi'] ?? ''),
    'target_saving_pct' => $_GET['target_saving_pct'] ?? 5,
    'target_otd_pct' => $_GET['target_otd_pct'] ?? 95,
    'target_acc_pct' => $_GET['target_acc_pct'] ?? 98,
    'target_sla_days' => $_GET['target_sla_days'] ?? 7,
    'gov_threshold' => $_GET['gov_threshold'] ?? 10000000,
];

$rep = build_procurement_report_data($pdo, $filters);
$f = $rep['filters'];

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="Laporan-KPI-Procurement-PBS-' . date('Y-m-d') . '.csv"');
$out = fopen('php://output', 'w');
fprintf($out, chr(0xEF) . chr(0xBB) . chr(0xBF));

// Section 1
fputcsv($out, ['1. KEY HIGHLIGHT - COST SAVING & KPI']);
fputcsv($out, ['No', 'Key highlight', 'Total spent', 'Target', 'Achievement (in IDR)', 'Achievement (in %)', 'Note']);
foreach ($rep['catStats'] as $catName => $cs) {
    $cTarget = $cs['budget'] * ($f['target_saving_pct'] / 100);
    $cPct = $cs['budget'] > 0 ? ($cs['saving'] / $cs['budget']) * 100 : 0;
    fputcsv($out, ['', $catName, $cs['spent'], $cTarget, $cs['saving'], round($cPct, 2) . '%', $cs['items'] . ' item']);
}
fputcsv($out, ['2', 'Cost Avoidance', $rep['costAvoidance']['spent'], $rep['costAvoidance']['target'], $rep['costAvoidance']['idr'], round($rep['costAvoidance']['pct'], 2) . '%', 'Bid max quote minus winning quote']);
fputcsv($out, ['3', 'On-Time Delivery (OTD) Rate', $rep['otd']['ontime'] . '/' . $rep['otd']['received'] . ' PO', $rep['otd']['target_pct'] . '%', $rep['otd']['ontime'] . ' PO', $rep['otd']['pct'] . '%', 'FTB <= Estimasi Tiba']);
fputcsv($out, ['4', 'Order Fulfillment Accuracy', $rep['accuracy']['recv_qty'] . '/' . $rep['accuracy']['order_qty'], $rep['accuracy']['target_pct'] . '%', $rep['accuracy']['recv_qty'], $rep['accuracy']['pct'] . '%', 'Order Accuracy Rate']);
fputcsv($out, ['5', 'SLA Lead Time Pengadaan (PR to PO)', $rep['sla']['avg_days'] . ' hari', '<= ' . $rep['sla']['target_days'] . ' hari', $rep['sla']['met_count'] . '/' . $rep['sla']['total_po'] . ' PO', $rep['sla']['pct'] . '%', 'PPBJ to PO']);
fputcsv($out, []);

// Section 2
fputcsv($out, ['2. TOP 10 THE BIGGEST TRANSACTION']);
fputcsv($out, ['No', 'Vendor name', 'Detail items', 'Value in IDR', '% From Total Spent', 'Saving Cost', '% From Total Saving']);
foreach ($rep['top10'] as $i => $row) {
    $pctSpent = $rep['totalAllPoSpent'] > 0 ? ($row['total_po'] / $rep['totalAllPoSpent']) * 100 : 0;
    $pctSav = $rep['totalAllSaving'] != 0 ? ($row['saving_idr'] / $rep['totalAllSaving']) * 100 : 0;
    fputcsv($out, [$i + 1, $row['vendor_name'], $row['detail_items'], $row['total_po'], round($pctSpent, 2) . '%', $row['saving_idr'], round($pctSav, 2) . '%']);
}
fputcsv($out, []);

// Section 3
fputcsv($out, ['3. PAYMENT TERM']);
fputcsv($out, ['No', 'Payment term', 'Qty', 'Qty %', 'Total Value (IDR)', 'Value %']);
$totalPayQty = array_sum(array_column($rep['payTerms'], 'qty'));
$totalPayVal = array_sum(array_column($rep['payTerms'], 'value'));
$n = 1;
foreach ($rep['payTerms'] as $pt) {
    $qP = $totalPayQty > 0 ? ($pt['qty'] / $totalPayQty) * 100 : 0;
    $vP = $totalPayVal > 0 ? ($pt['value'] / $totalPayVal) * 100 : 0;
    fputcsv($out, [$pt['label'] === 'etc' ? '' : $n++, $pt['label'], $pt['qty'], round($qP, 1) . '%', $pt['value'], round($vP, 1) . '%']);
}
fputcsv($out, []);

// Section 4
fputcsv($out, ['4. ORDER TRACKING']);
fputcsv($out, ['No', 'PO / WO number', 'Vendor name', 'Detail Items/Services', 'Order Qty', 'Total Value', 'Received Qty', 'Reject Qty']);
foreach ($rep['orderTracking'] as $i => $ot) {
    fputcsv($out, [$i + 1, $ot['po_no'], $ot['vendor_name'], $ot['detail_items'], $ot['order_qty'], $ot['total_po'], $ot['received_qty'], $ot['reject_qty']]);
}
fputcsv($out, []);

// Section 5
fputcsv($out, ['5. VENDOR PERFORMANCE & COMPLIANCE HIGHLIGHTS']);
fputcsv($out, ['Top Performing Vendors', !empty($rep['topVendors']) ? implode('; ', array_map(fn($v) => $v['vendor_name'], $rep['topVendors'])) : '-']);
fputcsv($out, ['Vendor Under Watch', !empty($rep['watchVendors']) ? implode('; ', array_map(fn($v) => $v['vendor_name'] . ' (' . $v['watch_reason'] . ')', $rep['watchVendors'])) : 'Tidak ada']);
fputcsv($out, ['Governance (>= Rp ' . $rep['governance']['threshold'] . ')', $rep['governance']['pct'] . '% (' . $rep['governance']['compliant'] . '/' . $rep['governance']['eligible'] . ' PO dengan >= 3 penawaran)']);

fclose($out);
exit;
