<?php
$q = trim($_GET['q'] ?? '');
$statusFilter = trim($_GET['status'] ?? '');
$isPemohon = ($user['role'] === 'PEMOHON');

$sql = "SELECT p.*, COALESCE(SUM(i.harga_anggaran),0) AS total_anggaran, COUNT(i.id) AS jml_item
        FROM ppbj_requests p
        LEFT JOIN ppbj_items i ON i.ppbj_id = p.id
        WHERE 1=1 ";
$params = [];

if ($isPemohon) {
    $sql .= " AND p.user_id = ? ";
    $params[] = (int)$user['id'];
}

if ($statusFilter !== '') {
    $sql .= " AND p.status = ? ";
    $params[] = $statusFilter;
}
if ($q !== '') {
    $sql .= " AND (p.request_no LIKE ? OR p.division_subdivision LIKE ? OR p.applied_by_name LIKE ? OR EXISTS (SELECT 1 FROM ppbj_items pi WHERE pi.ppbj_id = p.id AND pi.nama_barang_jasa LIKE ?)) ";
    $like = "%{$q}%";
    $params = array_merge($params, [$like, $like, $like, $like]);
}
$sql .= " GROUP BY p.id ORDER BY p.id DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

$statuses = [
    '' => 'Semua Status',
    'MENUNGGU_MANAGER' => 'Menunggu Approval Manager',
    'MENUNGGU_DIR_OPS' => 'Menunggu Approval Dir. Operasional',
    'MENUNGGU_DIR_KEU' => 'Menunggu Approval Dir. Keuangan',
    'SIAP_BID' => 'Disetujui Final (Siap Bid Summary)',
    'PO_TERBIT' => 'PO Terbit (Menunggu FTB)',
    'NON_PO' => 'Non PO (Langsung ke FTB)',
    'SELESAI_FTB' => 'Selesai (FTB Diterima)',
    'REVISI' => 'Perlu Revisi',
    'DITOLAK' => 'Ditolak',
    'DRAFT' => 'Draft',
];
?>

<div class="card">
  <div class="card-header">
    <div>
      <h1 class="card-title" style="font-size:18px;"><?= $isPemohon ? 'Daftar PPBJ yang Anda Ajukan' : 'Daftar Permintaan Pengadaan Barang/Jasa (PPBJ)' ?></h1>
      <div style="font-size:12px;color:#64748b;"><?= $isPemohon ? 'Menampilkan khusus PPBJ milik ' . h($user['nama_lengkap']) . ' beserta status approval masing-masing.' : 'Formulir Standar FRM.APR.01.00 — PT. Potensi Bumi Sakti' ?></div>
    </div>
    <div style="display:flex;gap:8px;">
      <a href="index.php?page=export_csv" class="btn btn-outline btn-sm">Export CSV</a>
      <a href="index.php?page=ppbj_form" class="btn btn-primary btn-sm">+ Ajukan PPBJ Baru</a>
    </div>
  </div>

  <form method="get" action="index.php" style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:16px;">
    <input type="hidden" name="page" value="ppbj_list">
    <input type="text" name="q" value="<?= h($q) ?>" placeholder="Cari No. PPBJ, divisi, pemohon, atau nama barang/jasa..." class="form-control" style="flex:1;min-width:240px;">
    <select name="status" class="form-control" style="width:auto;min-width:240px;">
      <?php foreach ($statuses as $k => $lbl): ?>
        <option value="<?= h($k) ?>" <?= $statusFilter === $k ? 'selected' : '' ?>><?= h($lbl) ?></option>
      <?php endforeach; ?>
    </select>
    <button type="submit" class="btn btn-primary btn-sm">Cari / Filter</button>
    <?php if ($q !== '' || $statusFilter !== ''): ?>
      <a href="index.php?page=ppbj_list" class="btn btn-outline btn-sm">Reset</a>
    <?php endif; ?>
  </form>

  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th>No. PPBJ &amp; Pemohon</th>
          <th>Tgl Request / Target</th>
          <th>Divisi &amp; Lokasi Pengiriman</th>
          <th>Jenis Permintaan</th>
          <th>Item</th>
          <th style="text-align:right;">Total Anggaran</th>
          <th>Status</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($rows)): ?>
          <tr><td colspan="8" style="text-align:center;padding:32px;color:#64748b;">Tidak ada data PPBJ yang sesuai filter.</td></tr>
        <?php else: foreach ($rows as $r): [$sLabel, $sClass] = status_meta($r['status']); ?>
          <tr>
            <td>
              <a href="index.php?page=ppbj_detail&id=<?= (int)$r['id'] ?>" style="font-weight:700;color:#007AB3;">
                <?= h($r['request_no']) ?>
              </a>
              <div style="font-size:11.5px;color:#64748b;">Pemohon: <?= h($r['applied_by_name']) ?></div>
              <?php if ($r['po_no']): ?>
                <div style="font-size:11px;color:#1e40af;font-weight:600;">PO: <?= h($r['po_no']) ?></div>
              <?php endif; ?>
            </td>
            <td style="white-space:nowrap;">
              <div><?= tgl_indo($r['request_date']) ?></div>
              <div style="font-size:11px;color:#64748b;">Terima: <?= tgl_indo($r['received_date']) ?></div>
            </td>
            <td>
              <div style="font-weight:600;"><?= h($r['division_subdivision']) ?></div>
              <div style="font-size:11.5px;color:#64748b;"><?= h($r['delivery_location']) ?></div>
            </td>
            <td style="font-size:12px;max-width:190px;"><?= h($r['request_types']) ?></td>
            <td style="text-align:center;font-weight:700;"><?= (int)$r['jml_item'] ?></td>
            <td style="text-align:right;font-weight:700;white-space:nowrap;"><?= rupiah($r['total_anggaran']) ?></td>
            <td><span class="badge <?= h($sClass) ?>"><?= h($sLabel) ?></span></td>
            <td style="white-space:nowrap;">
              <a href="index.php?page=ppbj_detail&id=<?= (int)$r['id'] ?>" class="btn btn-primary btn-sm">Detail</a>
              <?php if ($r['status'] === 'SIAP_BID'): ?>
                <a href="index.php?page=bid_summary_form&ppbj_id=<?= (int)$r['id'] ?>" class="btn btn-outline btn-sm">Bid Summary</a>
              <?php elseif ($r['status'] === 'PO_TERBIT'): ?>
                <a href="index.php?page=ftb_list" class="btn btn-green btn-sm">Isi FTB</a>
              <?php elseif ($r['status'] === 'NON_PO'): ?>
                <a href="index.php?page=ftb_form&ppbj_id=<?= (int)$r['id'] ?>" class="btn btn-green btn-sm">Isi FTB</a>
              <?php endif; ?>
              <a href="index.php?page=print_ppbj&id=<?= (int)$r['id'] ?>" target="_blank" class="btn btn-outline btn-sm">Cetak</a>
            </td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>
