<?php
// Dipanggil dari index.php (page=export_report&report=...) sebelum layout dirender.
report_guard($user);
$period = report_period();
$rep = (string)($_GET['report'] ?? '');
$slug = preg_replace('/[^a-z0-9_]/', '', $rep);

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="Laporan-' . $slug . '-' . $period['year'] . ($period['month'] ? sprintf('-%02d', $period['month']) : '') . '.csv"');
$out = fopen('php://output', 'w');
fprintf($out, chr(0xEF) . chr(0xBB) . chr(0xBF));
fputcsv($out, ['PT. Potensi Bumi Sakti - Periode ' . $period['label']]);

switch ($rep) {
    case 'cost_saving':
        $d = report_cost_saving($pdo, $period);
        fputcsv($out, ['No', 'Key highlight', 'Total spent', 'Target', 'Achievement (IDR)', 'Achievement (%)', 'Note']);
        foreach ($d['rows'] as $r) {
            fputcsv($out, [
                $r['no'], $r['label'], round($r['spent']),
                $r['target_fmt'] === 'pct' ? $r['target'] . '%' : round($r['target']),
                $r['ach'] === null ? '' : round($r['ach']),
                $r['pct'] === null ? '' : round($r['pct'], 1) . '%', $r['note'],
            ]);
        }
        break;
    case 'top_transactions':
        $d = report_top_transactions($pdo, $period, 10);
        fputcsv($out, ['No', 'Vendor name', 'PO/WO', 'Detail items', 'Value in IDR', '% From Total Spent', 'Saving Cost', '% From Total Saving']);
        foreach ($d['rows'] as $i => $r) {
            fputcsv($out, [
                $i + 1, $r['vendor_name'], $r['po_no'] ?: 'Non-PO', $r['detail'], round($r['actual']),
                $r['pct_spent'] === null ? '' : round($r['pct_spent'], 1) . '%', round($r['saving']),
                $r['pct_saving'] === null ? '' : round($r['pct_saving'], 1) . '%',
            ]);
        }
        break;
    case 'payment_terms':
        $d = report_payment_terms($pdo, $period);
        fputcsv($out, ['No', 'Payment term', 'Number of order (Qty)', 'Number of order (%)', 'Total value (IDR)', 'Total value (%)']);
        foreach ($d['rows'] as $r) {
            fputcsv($out, [
                $r['no'], $r['label'], $r['qty'], $r['qty_pct'] === null ? '' : round($r['qty_pct'], 1) . '%',
                round($r['value']), $r['value_pct'] === null ? '' : round($r['value_pct'], 1) . '%',
            ]);
        }
        fputcsv($out, ['', 'Total', $d['total_qty'], '', round($d['total_value']), '']);
        break;
    case 'order_tracking':
        $q = strtolower(trim((string)($_GET['q'] ?? '')));
        $sf = trim((string)($_GET['status'] ?? ''));
        fputcsv($out, ['No', 'PO / WO number', 'Tipe', 'Vendor name', 'Detail Items/Services', 'Satuan', 'Order Qty', 'Total Value', 'Received Qty', 'Reject Qty', 'Status']);
        $i = 0;
        foreach (report_order_lines($pdo, $period['from'], $period['to']) as $r) {
            if ($sf !== '' && $r['track_status'] !== $sf) continue;
            if ($q !== '' && strpos(strtolower($r['po_no'] . ' ' . $r['vendor_name'] . ' ' . $r['nama_barang_jasa']), $q) === false) continue;
            [$lbl] = report_track_status_meta($r['track_status']);
            fputcsv($out, [++$i, $r['po_no'], $r['order_type'], $r['vendor_name'], $r['nama_barang_jasa'], $r['satuan'],
                $r['ordered'], round($r['subtotal']), $r['received'], $r['rejected'], $lbl]);
        }
        break;
    case 'vendor_compliance':
        $perf = report_vendor_performance($pdo, $period);
        foreach (report_vendor_highlights($perf) as $line) {
            fputcsv($out, [$line]);
        }
        fputcsv($out, []);
        fputcsv($out, ['Vendor', 'Jumlah order', 'Nilai (IDR)', 'PO dievaluasi', 'PO tepat waktu', 'OTD (%)', 'PO terlambat', 'Reject qty', 'Catatan insiden', 'Status', 'Alasan']);
        foreach ($perf['vendors'] as $r) {
            fputcsv($out, [
                $r['vendor'], $r['orders'], round($r['spent']), $r['eval'], $r['ontime'],
                $r['otd'] === null ? '' : round($r['otd'], 1), $r['late'], $r['rej'], $r['incidents'],
                ['TOP' => 'Top Performing', 'WATCH' => 'Under Watch', 'NORMAL' => 'Normal'][$r['status']], implode('; ', $r['reasons']),
            ]);
        }
        fputcsv($out, []);
        fputcsv($out, ['Governance: PO/WO', 'Vendor', 'Nilai (IDR)', 'Jumlah penawaran', 'Status']);
        foreach ($perf['governance']['rows'] as $g) {
            fputcsv($out, [$g['po_no'], $g['vendor'], round($g['value']), $g['quotes'], $g['ok'] ? 'Sesuai' : 'Belum memenuhi']);
        }
        break;
    default:
        fputcsv($out, ['Jenis laporan tidak dikenal.']);
}
fclose($out);
