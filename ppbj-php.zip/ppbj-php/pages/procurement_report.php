<?php
if ($user['role'] === 'PEMOHON') {
    echo '<div class="card"><div class="flash flash-error">Akses Ditolak: Laporan &amp; KPI Procurement hanya dapat diakses oleh tim Procurement, Manager, Direksi, dan Super Admin.</div><a href="index.php" class="btn btn-outline btn-sm">&larr; Kembali ke Dashboard</a></div>';
    return;
}

$filters = [
    'date_from' => trim($_GET['date_from'] ?? ''),
    'date_to' => trim($_GET['date_to'] ?? ''),
    'divisi' => trim($_GET['divisi'] ?? ''),
    'target_saving_pct' => $_GET['target_saving_pct'] ?? 5,
    'target_otd_pct' => $_GET['target_otd_pct'] ?? 95,
    'target_acc_pct' => $_GET['target_acc_pct'] ?? 98,
    'target_sla_days' => $_GET['target_sla_days'] ?? 7,
    'gov_threshold' => $_GET['gov_threshold'] ?? 10000000,
];

$rep = build_procurement_report_data($pdo, $filters);
$f = $rep['filters'];
$divisions = $pdo->query("SELECT kode_divisi, nama_divisi FROM divisions ORDER BY kode_divisi ASC")->fetchAll();

$qs = http_build_query(array_filter($filters, fn($v) => $v !== ''));
$exportUrl = 'index.php?page=export_procurement_report_csv' . ($qs ? '&' . $qs : '');
$printUrl = 'index.php?page=print_procurement_report' . ($qs ? '&' . $qs : '');

$totalCatSpent = array_sum(array_column($rep['catStats'], 'spent'));
$totalCatBudget = array_sum(array_column($rep['catStats'], 'budget'));
$totalCatSaving = array_sum(array_column($rep['catStats'], 'saving'));
$totalCatTargetSavingIdr = $totalCatBudget * ($f['target_saving_pct'] / 100);
$totalCatSavingPct = $totalCatBudget > 0 ? ($totalCatSaving / $totalCatBudget) * 100 : 0;

$totalPayQty = array_sum(array_column($rep['payTerms'], 'qty'));
$totalPayVal = array_sum(array_column($rep['payTerms'], 'value'));
?>
<style>
  .kpi-tbl { width: 100%; border-collapse: collapse; font-size: 12.5px; }
  .kpi-tbl th, .kpi-tbl td { border: 1px solid #cbd5e1; padding: 7px 10px; vertical-align: middle; }
  .kpi-tbl thead th { background: #16365C; color: #fff; font-weight: 700; text-align: center; }
  .kpi-tbl tbody tr:nth-child(even) { background: #f8fafc; }
  .kpi-tbl .num { text-align: right; white-space: nowrap; }
  .kpi-tbl .ctr { text-align: center; white-space: nowrap; }
  .kpi-sec-title { font-size: 15px; font-weight: 800; color: #0f172a; margin: 0 0 10px; }
  .hl-row { background: #eff6ff !important; font-weight: 700; }
</style>

<div class="card">
  <div class="card-header">
    <div>
      <h1 class="card-title" style="font-size:18px;">Laporan &amp; KPI Procurement (Cost Saving, Transaction, Payment Term, Order Tracking &amp; Vendor)</h1>
      <div style="font-size:12px;color:#64748b;">
        Dihitung otomatis langsung dari data <strong>PPBJ</strong>, <strong>Bid Summary</strong>, <strong>Purchase Order / Work Order</strong>, dan <strong>FTB</strong> pada database.
      </div>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;">
      <a href="<?= h($exportUrl) ?>" class="btn btn-outline btn-sm">Export Laporan (.CSV)</a>
      <a href="<?= h($printUrl) ?>" target="_blank" class="btn btn-primary btn-sm">Cetak Laporan KPI</a>
    </div>
  </div>

  <!-- Filter & Target Parameters -->
  <form method="get" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;padding:12px;margin-bottom:4px;">
    <input type="hidden" name="page" value="procurement_report">
    <div class="grid-4" style="margin-bottom:8px;">
      <div class="form-group" style="margin-bottom:0;">
        <label style="font-size:11px;">Tgl PO Dari</label>
        <input type="date" name="date_from" class="form-control" value="<?= h($f['date_from']) ?>">
      </div>
      <div class="form-group" style="margin-bottom:0;">
        <label style="font-size:11px;">Tgl PO Sampai</label>
        <input type="date" name="date_to" class="form-control" value="<?= h($f['date_to']) ?>">
      </div>
      <div class="form-group" style="margin-bottom:0;">
        <label style="font-size:11px;">Divisi</label>
        <select name="divisi" class="form-control">
          <option value="">Semua Divisi</option>
          <?php foreach ($divisions as $d): ?>
            <option value="<?= h($d['kode_divisi']) ?>" <?= $f['divisi'] === $d['kode_divisi'] ? 'selected' : '' ?>>
              <?= h($d['kode_divisi']) ?> — <?= h($d['nama_divisi']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group" style="margin-bottom:0;">
        <label style="font-size:11px;">Target Saving (%)</label>
        <input type="number" step="0.5" min="0" name="target_saving_pct" class="form-control" value="<?= h((string)$f['target_saving_pct']) ?>">
      </div>
    </div>
    <div class="grid-4" style="align-items:end;">
      <div class="form-group" style="margin-bottom:0;">
        <label style="font-size:11px;">Target OTD (%)</label>
        <input type="number" step="1" min="0" max="100" name="target_otd_pct" class="form-control" value="<?= h((string)$f['target_otd_pct']) ?>">
      </div>
      <div class="form-group" style="margin-bottom:0;">
        <label style="font-size:11px;">Target Order Accuracy (%)</label>
        <input type="number" step="1" min="0" max="100" name="target_acc_pct" class="form-control" value="<?= h((string)$f['target_acc_pct']) ?>">
      </div>
      <div class="form-group" style="margin-bottom:0;">
        <label style="font-size:11px;">Target SLA PR to PO (Hari) &amp; Threshold Gov (Rp)</label>
        <div style="display:flex;gap:6px;">
          <input type="number" step="1" min="1" name="target_sla_days" class="form-control" style="max-width:75px;" value="<?= h((string)$f['target_sla_days']) ?>" title="Target Hari PR ke PO">
          <input type="number" step="1000000" min="0" name="gov_threshold" class="form-control" value="<?= h((string)$f['gov_threshold']) ?>" title="Nilai Minimum Wajib 3 Penawaran">
        </div>
      </div>
      <div style="display:flex;gap:8px;">
        <button type="submit" class="btn btn-primary btn-sm">Hitung Ulang KPI</button>
        <a href="index.php?page=procurement_report" class="btn btn-outline btn-sm">Reset</a>
      </div>
    </div>
  </form>
</div>

<!-- 1. KEY HIGHLIGHT (COST SAVING BY CATEGORY, COST AVOIDANCE, OTD, ORDER ACCURACY, SLA PR TO PO) -->
<div class="card">
  <h2 class="kpi-sec-title">1. Key Highlight — Cost Saving &amp; KPI Pengadaan</h2>
  <div class="table-wrap">
    <table class="kpi-tbl">
      <thead>
        <tr>
          <th rowspan="2" style="width:42px;">No</th>
          <th rowspan="2" style="min-width:250px;">Key highlight</th>
          <th rowspan="2" style="min-width:130px;">Total spent</th>
          <th rowspan="2" style="min-width:130px;">Target</th>
          <th colspan="2">Achievement</th>
          <th rowspan="2" style="min-width:230px;">Note</th>
        </tr>
        <tr>
          <th style="min-width:125px;">in IDR</th>
          <th style="min-width:80px;">in %</th>
        </tr>
      </thead>
      <tbody>
        <tr class="hl-row">
          <td class="ctr">1</td>
          <td>Saving cost by Category :</td>
          <td class="num"><?= rupiah($totalCatSpent) ?></td>
          <td class="num"><?= rupiah($totalCatTargetSavingIdr) ?> <span style="font-weight:400;color:#475569;font-size:11px;">(<?= h((string)$f['target_saving_pct']) ?>% budget)</span></td>
          <td class="num" style="color:<?= $totalCatSaving >= 0 ? '#008A3B' : '#dc2626' ?>;"><?= rupiah($totalCatSaving) ?></td>
          <td class="ctr" style="color:<?= $totalCatSavingPct >= $f['target_saving_pct'] ? '#008A3B' : '#0f172a' ?>;"><?= number_format($totalCatSavingPct, 2, ',', '.') ?>%</td>
          <td style="font-weight:400;font-size:11.5px;color:#475569;">Selisih Budget PPBJ (<?= rupiah($totalCatBudget) ?>) vs Realisasi PO.</td>
        </tr>
        <?php foreach ($rep['catStats'] as $catName => $cs):
          $cTarget = $cs['budget'] * ($f['target_saving_pct'] / 100);
          $cPct = $cs['budget'] > 0 ? ($cs['saving'] / $cs['budget']) * 100 : 0;
        ?>
        <tr>
          <td></td>
          <td style="padding-left:18px;"><?= h($catName) ?></td>
          <td class="num"><?= $cs['spent'] > 0 ? rupiah($cs['spent']) : '-' ?></td>
          <td class="num"><?= $cs['budget'] > 0 ? rupiah($cTarget) : '-' ?></td>
          <td class="num" style="color:<?= $cs['saving'] > 0 ? '#008A3B' : ($cs['saving'] < 0 ? '#dc2626' : '#64748b') ?>;">
            <?= $cs['items'] > 0 ? rupiah($cs['saving']) : '-' ?>
          </td>
          <td class="ctr"><?= $cs['budget'] > 0 ? number_format($cPct, 2, ',', '.') . '%' : '-' ?></td>
          <td style="font-size:11.5px;color:#64748b;"><?= $cs['items'] > 0 ? $cs['items'] . ' item PO (Budget: ' . rupiah($cs['budget']) . ')' : '' ?></td>
        </tr>
        <?php endforeach; ?>

        <tr class="hl-row">
          <td class="ctr">2</td>
          <td>Cost Avoidance</td>
          <td class="num"><?= rupiah($rep['costAvoidance']['spent']) ?></td>
          <td class="num"><?= rupiah($rep['costAvoidance']['target']) ?></td>
          <td class="num" style="color:#008A3B;"><?= rupiah($rep['costAvoidance']['idr']) ?></td>
          <td class="ctr"><?= number_format($rep['costAvoidance']['pct'], 2, ',', '.') ?>%</td>
          <td style="font-weight:400;font-size:11.5px;color:#475569;">Penawaran tertinggi di Bid Summary minus harga pemenang terpilih.</td>
        </tr>
        <tr>
          <td class="ctr"><strong>3</strong></td>
          <td><strong>On-Time Delivery (OTD) Rate</strong></td>
          <td class="ctr"><?= (int)$rep['otd']['ontime'] ?> / <?= (int)$rep['otd']['received'] ?> PO</td>
          <td class="ctr"><?= number_format($rep['otd']['target_pct'], 0) ?>%</td>
          <td class="ctr"><?= (int)$rep['otd']['ontime'] ?> PO tepat waktu</td>
          <td class="ctr"><strong><?= number_format($rep['otd']['pct'], 1, ',', '.') ?>%</strong></td>
          <td style="font-size:11.5px;color:#475569;">Tanggal FTB &le; Estimasi Tiba / Received Date pada PO.</td>
        </tr>
        <tr>
          <td class="ctr"><strong>4</strong></td>
          <td><strong>Order Fulfillment Accuracy (Order Accuracy Rate)</strong></td>
          <td class="ctr"><?= rtrim(rtrim((string)$rep['accuracy']['recv_qty'], '0'), '.') ?: '0' ?> / <?= rtrim(rtrim((string)$rep['accuracy']['order_qty'], '0'), '.') ?: '0' ?> Qty</td>
          <td class="ctr"><?= number_format($rep['accuracy']['target_pct'], 0) ?>%</td>
          <td class="ctr"><?= rtrim(rtrim((string)$rep['accuracy']['recv_qty'], '0'), '.') ?: '0' ?> unit diterima baik</td>
          <td class="ctr"><strong><?= number_format($rep['accuracy']['pct'], 1, ',', '.') ?>%</strong></td>
          <td style="font-size:11.5px;color:#334155;">Mengukur persentase pesanan yang diterima dengan benar (tepat jenis, spesifikasi, dan jumlah) dibandingkan dengan total order yang dirilis.</td>
        </tr>
        <tr>
          <td class="ctr"><strong>5</strong></td>
          <td><strong>SLA Lead Time Pengadaan (PR to PO)</strong></td>
          <td class="ctr">Rata-rata <?= number_format($rep['sla']['avg_days'], 1, ',', '.') ?> hari</td>
          <td class="ctr">&le; <?= (int)$rep['sla']['target_days'] ?> hari</td>
          <td class="ctr"><?= (int)$rep['sla']['met_count'] ?> / <?= (int)$rep['sla']['total_po'] ?> PO</td>
          <td class="ctr"><strong><?= number_format($rep['sla']['pct'], 1, ',', '.') ?>%</strong></td>
          <td style="font-size:11.5px;color:#475569;">Selisih hari dari Tanggal PPBJ hingga Tanggal Terbit PO.</td>
        </tr>
      </tbody>
    </table>
  </div>
</div>

<!-- 2. TOP 10 THE BIGGEST TRANSACTION -->
<div class="card">
  <h2 class="kpi-sec-title">2. Top 10 The Biggest Transaction</h2>
  <div class="table-wrap">
    <table class="kpi-tbl">
      <thead>
        <tr>
          <th style="width:42px;">No</th>
          <th style="min-width:190px;">Vendor name</th>
          <th style="min-width:250px;">Detail items</th>
          <th style="min-width:140px;">Value in IDR</th>
          <th style="width:110px;">% From Total Spent</th>
          <th style="min-width:130px;">Saving Cost</th>
          <th style="width:110px;">% From Total Saving</th>
        </tr>
      </thead>
      <tbody>
        <?php for ($i = 0; $i < 10; $i++):
          $row = $rep['top10'][$i] ?? null;
          $pctSpent = ($row && $rep['totalAllPoSpent'] > 0) ? ((float)$row['total_po'] / $rep['totalAllPoSpent']) * 100 : 0;
          $pctSav = ($row && $rep['totalAllSaving'] != 0) ? ((float)$row['saving_idr'] / $rep['totalAllSaving']) * 100 : 0;
        ?>
        <tr>
          <td class="ctr"><strong><?= $i + 1 ?></strong></td>
          <td>
            <?php if ($row): ?>
              <strong><?= h($row['vendor_name']) ?></strong>
              <div style="font-size:11px;color:#64748b;"><?= h($row['po_no']) ?></div>
            <?php else: ?>
              <span style="color:#94a3b8;">-</span>
            <?php endif; ?>
          </td>
          <td style="font-size:12px;"><?= $row ? h($row['detail_items'] ?: '-') : '-' ?></td>
          <td class="num" style="font-weight:700;"><?= $row ? rupiah($row['total_po']) : '-' ?></td>
          <td class="ctr"><?= $row ? number_format($pctSpent, 2, ',', '.') . '%' : '-' ?></td>
          <td class="num" style="color:<?= ($row && $row['saving_idr'] >= 0) ? '#008A3B' : '#dc2626' ?>;">
            <?= $row ? rupiah($row['saving_idr']) : '-' ?>
          </td>
          <td class="ctr"><?= ($row && $rep['totalAllSaving'] != 0) ? number_format($pctSav, 2, ',', '.') . '%' : '-' ?></td>
        </tr>
        <?php endfor; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- 3. PAYMENT TERM -->
<div class="card">
  <h2 class="kpi-sec-title">3. Payment Term</h2>
  <div class="table-wrap">
    <table class="kpi-tbl">
      <thead>
        <tr>
          <th rowspan="2" style="width:42px;">No</th>
          <th rowspan="2" style="min-width:250px;">Payment term</th>
          <th colspan="2">Number of order</th>
          <th colspan="2">Total Value</th>
        </tr>
        <tr>
          <th style="width:100px;">Qty</th>
          <th style="width:100px;">in %</th>
          <th style="min-width:150px;">in IDR</th>
          <th style="width:100px;">in %</th>
        </tr>
      </thead>
      <tbody>
        <?php $ptNo = 1; foreach ($rep['payTerms'] as $pt):
          $qtyPct = $totalPayQty > 0 ? ($pt['qty'] / $totalPayQty) * 100 : 0;
          $valPct = $totalPayVal > 0 ? ($pt['value'] / $totalPayVal) * 100 : 0;
        ?>
        <tr>
          <td class="ctr"><?= $pt['label'] === 'etc' ? '' : $ptNo++ ?></td>
          <td><strong><?= h($pt['label']) ?></strong></td>
          <td class="ctr"><?= (int)$pt['qty'] ?></td>
          <td class="ctr"><?= number_format($qtyPct, 1, ',', '.') ?>%</td>
          <td class="num"><?= rupiah($pt['value']) ?></td>
          <td class="ctr"><?= number_format($valPct, 1, ',', '.') ?>%</td>
        </tr>
        <?php endforeach; ?>
        <tr class="hl-row">
          <td colspan="2" style="text-align:right;">Total</td>
          <td class="ctr"><?= $totalPayQty ?></td>
          <td class="ctr"><?= $totalPayQty > 0 ? '100,0%' : '0,0%' ?></td>
          <td class="num"><?= rupiah($totalPayVal) ?></td>
          <td class="ctr"><?= $totalPayVal > 0 ? '100,0%' : '0,0%' ?></td>
        </tr>
      </tbody>
    </table>
  </div>
</div>

<!-- 4. ORDER TRACKING -->
<div class="card">
  <h2 class="kpi-sec-title">4. Order Tracking</h2>
  <div class="table-wrap">
    <table class="kpi-tbl">
      <thead>
        <tr>
          <th style="width:42px;">No</th>
          <th style="min-width:150px;">PO / WO number</th>
          <th style="min-width:180px;">Vendor name</th>
          <th style="min-width:240px;">Detail Items/Services</th>
          <th style="width:95px;">Order Qty</th>
          <th style="min-width:130px;">Total Value</th>
          <th style="width:105px;">Received Qty</th>
          <th style="width:95px;">Reject Qty</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($rep['orderTracking'])): ?>
          <tr><td colspan="8" style="text-align:center;color:#64748b;padding:20px;">Belum ada data PO / WO pada periode ini.</td></tr>
        <?php else: ?>
          <?php foreach ($rep['orderTracking'] as $idx => $ot): ?>
          <tr>
            <td class="ctr"><?= $idx + 1 ?></td>
            <td>
              <a href="index.php?page=print_po&id=<?= (int)$ot['id'] ?>" target="_blank" style="font-weight:700;color:#007AB3;"><?= h($ot['po_no']) ?></a>
              <div style="font-size:11px;color:#64748b;"><?= h($ot['order_type']) ?></div>
            </td>
            <td><strong><?= h($ot['vendor_name']) ?></strong></td>
            <td style="font-size:12px;"><?= h($ot['detail_items'] ?: '-') ?></td>
            <td class="ctr"><strong><?= rtrim(rtrim((string)$ot['order_qty'], '0'), '.') ?></strong></td>
            <td class="num"><strong><?= rupiah($ot['total_po']) ?></strong></td>
            <td class="ctr" style="color:#008A3B;font-weight:700;"><?= rtrim(rtrim((string)$ot['received_qty'], '0'), '.') ?: '0' ?></td>
            <td class="ctr" style="color:<?= (float)$ot['reject_qty'] > 0 ? '#dc2626' : '#64748b' ?>;font-weight:700;"><?= rtrim(rtrim((string)$ot['reject_qty'], '0'), '.') ?: '0' ?></td>
          </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- 5. VENDOR PERFORMANCE & COMPLIANCE HIGHLIGHTS -->
<div class="card">
  <h2 class="kpi-sec-title">5. Vendor Performance &amp; Compliance Highlights</h2>
  <div class="table-wrap">
    <table class="kpi-tbl">
      <tbody>
        <tr>
          <td style="padding:12px 14px;background:#ecfdf5;">
            <strong>Top Performing Vendors:</strong>
            <?php if (!empty($rep['topVendors'])): ?>
              <?php
              $topStr = array_map(
                  fn($v) => $v['vendor_name'] . ' (Skor SLA ' . number_format($v['sla_score'], 1, ',', '.') . '%, 0 reject)',
                  $rep['topVendors']
              );
              echo h(implode('; ', $topStr));
              ?>
            <?php else: ?>
              <span style="color:#475569;">Belum ada vendor dengan transaksi FTB selesai pada periode ini.</span>
            <?php endif; ?>
          </td>
        </tr>
        <tr>
          <td style="padding:12px 14px;background:#fff7ed;">
            <strong>Vendor Under Watch (Dalam Pengawasan):</strong>
            <?php if (!empty($rep['watchVendors'])): ?>
              <?php
              $wStr = array_map(
                  fn($v) => $v['vendor_name'] . ' — ' . $v['watch_reason'],
                  $rep['watchVendors']
              );
              echo h(implode('; ', $wStr));
              ?>
            <?php else: ?>
              <span style="color:#008A3B;font-weight:600;">Tidak ada vendor bermasalah — seluruh pengiriman berjalan tepat waktu dan tanpa penolakan (0 reject).</span>
            <?php endif; ?>
          </td>
        </tr>
        <tr>
          <td style="padding:12px 14px;background:#eff6ff;">
            <strong>Kepatuhan &amp; Tata Kelola (Governance):</strong>
            <?= number_format($rep['governance']['pct'], 1, ',', '.') ?>% transaksi di atas <?= rupiah($rep['governance']['threshold']) ?>
            (<?= (int)$rep['governance']['compliant'] ?> dari <?= (int)$rep['governance']['eligible'] ?> PO) telah melalui proses komparasi minimal 3 penawaran di Bid Summary.
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</div>
