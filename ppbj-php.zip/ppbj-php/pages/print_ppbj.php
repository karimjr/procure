<?php
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("SELECT * FROM ppbj_requests WHERE id = ?");
$stmt->execute([$id]);
$pr = $stmt->fetch();
if (!$pr) { die('Data PPBJ tidak ditemukan.'); }

$stmt2 = $pdo->prepare("SELECT * FROM ppbj_items WHERE ppbj_id = ? ORDER BY item_no ASC");
$stmt2->execute([$id]);
$items = $stmt2->fetchAll();
$grandTotal = array_sum(array_map(fn($x) => (float)$x['harga_anggaran'], $items));
$selectedTypes = array_map('trim', explode(',', $pr['request_types']));
$logo = logo_src();
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <title>Cetak PPBJ <?= h($pr['request_no']) ?></title>
  <style>
    body { font-family: Arial, Helvetica, sans-serif; color: #111; margin: 20px; font-size: 11px; }
    .toolbar { margin-bottom: 16px; display: flex; gap: 8px; }
    .btn { padding: 8px 14px; border-radius: 6px; border: 1px solid #cbd5e1; background: #fff; cursor: pointer; font-weight: 700; text-decoration: none; color: #111; font-size: 12px; }
    .btn-blue { background: #009ADE; color: #fff; border-color: #009ADE; }
    .sheet { max-width: 960px; margin: 0 auto; border: 2px solid #000; padding: 14px; }
    table { width: 100%; border-collapse: collapse; }
    th, td { border: 1px solid #000; padding: 5px 7px; vertical-align: top; }
    .no-border td { border: none; }
    .title-main { font-size: 16px; font-weight: 800; letter-spacing: .5px; }
    .title-sub { font-size: 12px; font-weight: 700; font-style: italic; }
    .check-box { display: inline-block; width: 12px; height: 12px; border: 1px solid #000; text-align: center; line-height: 11px; font-weight: 700; margin-right: 4px; }
    @media print { .toolbar { display: none; } body { margin: 0; } .sheet { border-width: 1px; } }
  </style>
</head>
<body>
<div class="toolbar">
  <button onclick="window.print()" class="btn btn-blue">Cetak / Simpan PDF</button>
  <a href="index.php?page=ppbj_detail&id=<?= $id ?>" class="btn">&larr; Kembali ke Detail</a>
</div>

<div class="sheet">
  <table class="no-border" style="margin-bottom:8px;">
    <tr>
      <td style="width:90px;vertical-align:middle;">
        <img src="<?= h($logo) ?>" alt="Logo PBS" style="width:74px;height:74px;object-fit:contain;">
      </td>
      <td style="vertical-align:middle;">
        <div style="font-weight:800;font-size:13px;">PT. POTENSI BUMI SAKTI</div>
        <div class="title-main" style="margin-top:4px;">PERMINTAAN PENGADAAN BARANG/JASA</div>
        <div class="title-sub">PURCHASE / SERVICE REQUEST</div>
      </td>
      <td style="width:240px;padding:0;">
        <table>
          <tr><td>Nomor</td><td>: <strong><?= h($pr['doc_form_no']) ?></strong></td></tr>
          <tr><td>Tanggal Terbit</td><td>: <?= h($pr['doc_issue_date']) ?></td></tr>
          <tr><td>Revisi</td><td>: <?= h($pr['doc_revision']) ?></td></tr>
          <tr><td>Tanggal Revisi</td><td>: -</td></tr>
        </table>
      </td>
    </tr>
  </table>

  <table style="margin-bottom:8px;">
    <tr>
      <td style="width:36%;">Permintaan / Request No.<br><strong><?= h($pr['request_no']) ?></strong></td>
      <td style="width:32%;">Tanggal / Date<br><strong><?= tgl_indo($pr['request_date']) ?></strong></td>
      <td style="width:32%;">Tanggal Penerimaan / Received Date<br><strong><?= tgl_indo($pr['received_date']) ?></strong></td>
    </tr>
    <tr>
      <td>Divisi &amp; Sub Divisi / Division &amp; Sub Division<br><strong><?= h($pr['division_subdivision']) ?></strong></td>
      <td colspan="2">Lokasi pengiriman / Delivery location<br><strong><?= h($pr['delivery_location']) ?></strong></td>
    </tr>
  </table>

  <table style="margin-bottom:8px;">
    <tr>
      <td colspan="2" style="background:#f1f5f9;font-weight:700;">Jenis Permintaan / Type of Request :</td>
    </tr>
    <tr>
      <td style="width:50%;">
        <?php foreach (['1. Bahan baku' => 'Raw material', '2. Alat Produksi' => 'Production tools/machine', '3. Kendaraan' => 'Vehicle'] as $k => $e): ?>
          <div style="margin:3px 0;">
            <span class="check-box"><?= in_array($k, $selectedTypes, true) ? '&#10003;' : '&nbsp;' ?></span>
            <strong><?= h($k) ?></strong> <span style="font-style:italic;color:#444;">(<?= h($e) ?>)</span>
          </div>
        <?php endforeach; ?>
      </td>
      <td style="width:50%;">
        <?php foreach (['4. Suku cadang' => 'Spare parts', '5. Bahan bakar/Pelumas' => 'Fuel/Lubricant', '6. Lain-lain' => 'Others'] as $k => $e): ?>
          <div style="margin:3px 0;">
            <span class="check-box"><?= in_array($k, $selectedTypes, true) ? '&#10003;' : '&nbsp;' ?></span>
            <strong><?= h($k) ?></strong> <span style="font-style:italic;color:#444;">(<?= h($e) ?>)</span>
          </div>
        <?php endforeach; ?>
      </td>
    </tr>
  </table>

  <table style="margin-bottom:8px;">
    <thead>
      <tr style="background:#f1f5f9;text-align:center;">
        <th style="width:30px;">No.</th>
        <th style="width:55px;">Jumlah<br><em>Quantity</em></th>
        <th style="width:55px;">Satuan<br><em>Unit</em></th>
        <th style="width:85px;">No. Anggr<br><em>Budget No</em></th>
        <th>NAMA BARANG/JASA<br><em>Name of Goods/Service</em></th>
        <th style="width:110px;">Harga/unit<br><em>Price/unit</em></th>
        <th style="width:130px;">Harga (sesuai anggaran)<br><em>Price (as budgeted)</em></th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($items as $it): ?>
        <tr>
          <td style="text-align:center;"><?= (int)$it['item_no'] ?></td>
          <td style="text-align:center;"><?= rtrim(rtrim((string)$it['jumlah'], '0'), '.') ?></td>
          <td style="text-align:center;"><?= h($it['satuan']) ?></td>
          <td style="text-align:center;"><?= h($it['no_anggaran']) ?></td>
          <td>
            <strong><?= h($it['nama_barang_jasa']) ?></strong>
            <?php if ($it['peruntukan']): ?><div style="color:#444;font-size:10px;">Peruntukan: <?= h($it['peruntukan']) ?></div><?php endif; ?>
          </td>
          <td style="text-align:right;"><?= rupiah($it['harga_unit']) ?></td>
          <td style="text-align:right;font-weight:700;"><?= rupiah($it['harga_anggaran']) ?></td>
        </tr>
      <?php endforeach; ?>
      <?php for ($blank = count($items); $blank < 8; $blank++): ?>
        <tr><td>&nbsp;</td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
      <?php endfor; ?>
      <tr>
        <td colspan="6" style="text-align:right;font-weight:800;letter-spacing:2px;">T O T A L</td>
        <td style="text-align:right;font-weight:800;"><?= rupiah($grandTotal) ?></td>
      </tr>
    </tbody>
  </table>

  <!-- 3 Disposisi -->
  <table style="margin-bottom:8px;">
    <tr style="background:#f1f5f9;font-weight:700;">
      <td style="width:34%;">DISPOSISI MANAGER:</td>
      <td style="width:33%;">DISPOSISI DIREKTUR OPERASIONAL:</td>
      <td style="width:33%;">DISPOSISI DIREKTUR KEUANGAN:</td>
    </tr>
    <tr>
      <td style="height:56px;"><?= h($pr['manager_note'] ?: '-') ?></td>
      <td><?= h($pr['dir_ops_note'] ?: '-') ?></td>
      <td><?= h($pr['dir_keu_note'] ?: '-') ?></td>
    </tr>
  </table>

  <!-- 4 Kolom Tanda Tangan -->
  <table>
    <tr style="background:#f1f5f9;">
      <td style="width:25%;">Diajukan / Applied by:</td>
      <td style="width:25%;">Atasan / Manager:</td>
      <td style="width:25%;">Direktur Operasional:</td>
      <td style="width:25%;">Direktur Keuangan (Final):</td>
    </tr>
    <tr>
      <td style="text-align:center;">
        <div style="height:44px;"></div>
        <strong><?= h($pr['applied_by_name']) ?></strong><br>
        <span><?= tgl_indo($pr['applied_by_date']) ?></span>
        <div style="font-size:9px;color:#555;border-top:1px dotted #999;margin-top:3px;">Name &amp; Date</div>
      </td>
      <td style="text-align:center;">
        <div style="height:44px;"></div>
        <strong><?= h($pr['manager_name'] ?: '-') ?></strong><br>
        <span><?= tgl_indo($pr['manager_date']) ?></span>
        <div style="font-size:9px;color:#555;border-top:1px dotted #999;margin-top:3px;">Name &amp; Date</div>
      </td>
      <td style="text-align:center;">
        <div style="height:44px;"></div>
        <strong><?= h($pr['dir_ops_name'] ?: '-') ?></strong><br>
        <span><?= tgl_indo($pr['dir_ops_date']) ?></span>
        <div style="font-size:9px;color:#555;border-top:1px dotted #999;margin-top:3px;">Name &amp; Date</div>
      </td>
      <td style="text-align:center;">
        <div style="height:44px;"></div>
        <strong><?= h($pr['dir_keu_name'] ?: '-') ?></strong><br>
        <span><?= tgl_indo($pr['dir_keu_date']) ?></span>
        <div style="font-size:9px;color:#555;border-top:1px dotted #999;margin-top:3px;">Name &amp; Date</div>
      </td>
    </tr>
  </table>

  <div style="margin-top:6px;font-size:10px;">
    <strong>Catatan:</strong> <?= h($pr['catatan_umum'] ?: 'Lampirkan SPESIFIKASI BARANG/JASA') ?>
  </div>
</div>
</body>
</html>
