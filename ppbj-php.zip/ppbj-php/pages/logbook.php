<?php
$isPemohon = ($user['role'] === 'PEMOHON');
$tab = ($_GET['tab'] ?? 'monitoring') === 'aktivitas' ? 'aktivitas' : 'monitoring';

$filters = [
    'q' => trim($_GET['q'] ?? ''),
    'divisi' => trim($_GET['divisi'] ?? ''),
    'status' => trim($_GET['status'] ?? ''),
    'jalur' => trim($_GET['jalur'] ?? ''),
    'date_from' => trim($_GET['date_from'] ?? ''),
    'date_to' => trim($_GET['date_to'] ?? ''),
];

$rows = fetch_logbook_rows($pdo, $user, $filters);
$divisions = $pdo->query("SELECT kode_divisi, nama_divisi FROM divisions ORDER BY kode_divisi ASC")->fetchAll();

// Hitung ringkasan KPI dari hasil logbook yang tampil
$totalItems = count($rows);
$uniquePpbj = [];
$approvalCount = 0;
$prosesPoCount = 0;
$selesaiCount = 0;
$totalBudget = 0.0;
$totalRealisasiPo = 0.0;
$leadTimeSum = 0;
$leadTimeDone = 0;

foreach ($rows as $r) {
    $pid = (int)$r['ppbj_id'];
    if (!isset($uniquePpbj[$pid])) {
        $uniquePpbj[$pid] = true;
        if (in_array($r['ppbj_status'], ['MENUNGGU_MANAGER', 'MENUNGGU_DIR_OPS', 'MENUNGGU_DIR_KEU'], true)) {
            $approvalCount++;
        } elseif (in_array($r['ppbj_status'], ['SIAP_BID', 'PO_TERBIT', 'NON_PO'], true)) {
            $prosesPoCount++;
        } elseif ($r['ppbj_status'] === 'SELESAI_FTB') {
            $selesaiCount++;
        }
    }
    $totalBudget += (float)$r['harga_anggaran'];
    $real = $r['po_subtotal'] !== null ? (float)$r['po_subtotal'] : ((float)($r['bid_winner_total'] ?? 0));
    $totalRealisasiPo += $real;
    if (!empty($r['ftb_date']) && !empty($r['request_date'])) {
        $d1 = strtotime($r['request_date']);
        $d2 = strtotime($r['ftb_date']);
        if ($d1 && $d2 && $d2 >= $d1) {
            $leadTimeSum += (int)round(($d2 - $d1) / 86400);
            $leadTimeDone++;
        }
    }
}
$avgLeadTime = $leadTimeDone > 0 ? round($leadTimeSum / $leadTimeDone, 1) : 0;

// Query Log Aktivitas (ppbj_logs)
$logSql = "SELECT l.*, p.request_no, p.division_code, p.division_subdivision, p.status AS ppbj_status
           FROM ppbj_logs l
           JOIN ppbj_requests p ON l.ppbj_id = p.id
           WHERE 1=1";
$logParams = [];
if ($isPemohon) {
    $logSql .= " AND p.user_id = ?";
    $logParams[] = (int)$user['id'];
}
if ($filters['divisi'] !== '') {
    $logSql .= " AND p.division_code = ?";
    $logParams[] = $filters['divisi'];
}
if ($filters['status'] !== '') {
    $logSql .= " AND p.status = ?";
    $logParams[] = $filters['status'];
}
if ($filters['q'] !== '') {
    $like = '%' . $filters['q'] . '%';
    $logSql .= " AND (p.request_no LIKE ? OR l.actor_name LIKE ? OR l.aksi LIKE ? OR l.catatan LIKE ?)";
    $logParams = array_merge($logParams, [$like, $like, $like, $like]);
}
$logSql .= " ORDER BY l.created_at DESC, l.id DESC LIMIT 200";
$stLog = $pdo->prepare($logSql);
$stLog->execute($logParams);
$activityLogs = $stLog->fetchAll();

$qs = http_build_query(array_filter($filters, fn($v) => $v !== ''));
$exportUrl = 'index.php?page=export_logbook_csv' . ($qs ? '&' . $qs : '');
$printUrl = 'index.php?page=print_logbook' . ($qs ? '&' . $qs : '');
?>

<?php if (!$isPemohon): ?>
<div class="kpi-grid">
  <div class="kpi-card">
    <div class="kpi-label">Total PPBJ / Item Logbook</div>
    <div class="kpi-value" style="color:#007AB3;"><?= count($uniquePpbj) ?> <span style="font-size:14px;color:#64748b;font-weight:600;">PPBJ (<?= $totalItems ?> item)</span></div>
    <div class="kpi-sub">Proses Approval: <strong><?= $approvalCount ?></strong> | Siap Bid/PO: <strong><?= $prosesPoCount ?></strong></div>
  </div>
  <div class="kpi-card">
    <div class="kpi-label">Selesai Diterima (FTB)</div>
    <div class="kpi-value" style="color:#008A3B;"><?= $selesaiCount ?> <span style="font-size:14px;color:#64748b;font-weight:600;">PPBJ</span></div>
    <div class="kpi-sub">Rata-rata Lead Time: <strong><?= $avgLeadTime ?> hari</strong> (PPBJ &rarr; FTB)</div>
  </div>
  <div class="kpi-card">
    <div class="kpi-label">Total Anggaran PPBJ</div>
    <div class="kpi-value" style="font-size:20px;color:#0f172a;"><?= rupiah($totalBudget) ?></div>
    <div class="kpi-sub">Sesuai filter yang aktif</div>
  </div>
  <div class="kpi-card">
    <div class="kpi-label">Realisasi Bid / PO</div>
    <div class="kpi-value" style="font-size:20px;color:#0369a1;"><?= rupiah($totalRealisasiPo) ?></div>
    <?php $selisih = $totalBudget - $totalRealisasiPo; ?>
    <div class="kpi-sub">
      <?php if ($totalRealisasiPo > 0): ?>
        Selisih vs Budget: <strong style="color:<?= $selisih >= 0 ? '#008A3B' : '#dc2626' ?>;"><?= ($selisih >= 0 ? 'Hemat ' : '+ ') . rupiah(abs($selisih)) ?></strong>
      <?php else: ?>
        Belum ada PO/Bid terbit pada filter ini
      <?php endif; ?>
    </div>
  </div>
</div>
<?php endif; ?>

<div class="card">
  <div class="card-header">
    <div>
      <h1 class="card-title" style="font-size:18px;">Logbook Procurement (Monitoring End-to-End PPBJ &rarr; PO &rarr; FTB)</h1>
      <div style="font-size:12px;color:#64748b;">
        Catatan lengkap perjalanan setiap item pengadaan PT. Potensi Bumi Sakti beserta tanggal approval, pemenang Bid, nomor PO/Non-PO, dan penerimaan FTB.
      </div>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;">
      <a href="<?= h($exportUrl) ?>" class="btn btn-outline btn-sm">Export Logbook (.CSV)</a>
      <a href="<?= h($printUrl) ?>" target="_blank" class="btn btn-primary btn-sm">Cetak Logbook</a>
    </div>
  </div>

  <!-- Tabs -->
  <div style="display:flex;gap:8px;margin-bottom:14px;border-bottom:1px solid #e2e8f0;padding-bottom:10px;">
    <a href="index.php?page=logbook&tab=monitoring<?= $qs ? '&' . h($qs) : '' ?>"
       class="btn btn-sm <?= $tab === 'monitoring' ? 'btn-primary' : 'btn-outline' ?>">
      Monitoring Pengadaan per Item (<?= $totalItems ?>)
    </a>
    <a href="index.php?page=logbook&tab=aktivitas<?= $qs ? '&' . h($qs) : '' ?>"
       class="btn btn-sm <?= $tab === 'aktivitas' ? 'btn-primary' : 'btn-outline' ?>">
      Riwayat Aktivitas &amp; Approval (<?= count($activityLogs) ?>)
    </a>
  </div>

  <!-- Filter Bar -->
  <form method="get" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;padding:12px;margin-bottom:16px;">
    <input type="hidden" name="page" value="logbook">
    <input type="hidden" name="tab" value="<?= h($tab) ?>">
    <div class="grid-4" style="margin-bottom:8px;">
      <input type="text" name="q" class="form-control" placeholder="Cari No. PPBJ / PO / FTB / Barang / Vendor..." value="<?= h($filters['q']) ?>">
      <select name="divisi" class="form-control">
        <option value="">Semua Divisi</option>
        <?php foreach ($divisions as $d): ?>
          <option value="<?= h($d['kode_divisi']) ?>" <?= $filters['divisi'] === $d['kode_divisi'] ? 'selected' : '' ?>>
            <?= h($d['kode_divisi']) ?> — <?= h($d['nama_divisi']) ?>
          </option>
        <?php endforeach; ?>
      </select>
      <select name="status" class="form-control">
        <option value="">Semua Status Pengadaan</option>
        <?php foreach (['MENUNGGU_MANAGER', 'MENUNGGU_DIR_OPS', 'MENUNGGU_DIR_KEU', 'SIAP_BID', 'PO_TERBIT', 'NON_PO', 'SELESAI_FTB', 'DITOLAK'] as $stOpt):
          [$stLbl] = status_meta($stOpt);
        ?>
          <option value="<?= h($stOpt) ?>" <?= $filters['status'] === $stOpt ? 'selected' : '' ?>><?= h($stLbl) ?></option>
        <?php endforeach; ?>
      </select>
      <select name="jalur" class="form-control">
        <option value="">Semua Jalur (PO &amp; Non PO)</option>
        <option value="PO" <?= $filters['jalur'] === 'PO' ? 'selected' : '' ?>>Via PO</option>
        <option value="NON_PO" <?= $filters['jalur'] === 'NON_PO' ? 'selected' : '' ?>>Non PO (Langsung FTB)</option>
      </select>
    </div>
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
      <span style="font-size:12px;color:#475569;font-weight:600;">Tgl PPBJ:</span>
      <input type="date" name="date_from" class="form-control" style="max-width:165px;" value="<?= h($filters['date_from']) ?>">
      <span style="font-size:12px;color:#64748b;">s/d</span>
      <input type="date" name="date_to" class="form-control" style="max-width:165px;" value="<?= h($filters['date_to']) ?>">
      <button type="submit" class="btn btn-primary btn-sm">Terapkan Filter</button>
      <?php if ($qs !== ''): ?>
        <a href="index.php?page=logbook&tab=<?= h($tab) ?>" class="btn btn-outline btn-sm">Reset</a>
      <?php endif; ?>
    </div>
  </form>

  <?php if ($tab === 'monitoring'): ?>
    <div class="table-wrap">
      <table class="data-table">
        <thead>
          <tr>
            <th>No</th>
            <th style="min-width:170px;">No. PPBJ &amp; Divisi</th>
            <th style="min-width:210px;">Nama Barang / Jasa &amp; Jalur</th>
            <th style="min-width:190px;">Timeline Approval</th>
            <th style="min-width:175px;">Bid Summary &amp; PO / Non-PO</th>
            <th style="text-align:right;min-width:140px;">Budget vs Realisasi</th>
            <th style="min-width:165px;">Penerimaan (FTB)</th>
            <th>Lead Time</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($rows)): ?>
            <tr><td colspan="9" style="text-align:center;color:#64748b;padding:24px;">Belum ada data logbook yang sesuai filter.</td></tr>
          <?php else: ?>
            <?php foreach ($rows as $idx => $r):
              [$sLabel, $sBadge] = status_meta($r['ppbj_status']);
              $vendorShown = $r['po_vendor_name'] ?: ($r['bid_winner_vendor'] ?: '-');
              $realisasi = $r['po_subtotal'] !== null ? (float)$r['po_subtotal'] : ((float)($r['bid_winner_total'] ?? 0));
              $leadText = '-';
              if (!empty($r['ftb_date']) && !empty($r['request_date'])) {
                  $days = (int)round((strtotime($r['ftb_date']) - strtotime($r['request_date'])) / 86400);
                  $leadText = max(0, $days) . ' hari';
              } elseif (!empty($r['request_date']) && $r['ppbj_status'] !== 'DITOLAK') {
                  $days = (int)round((time() - strtotime($r['request_date'])) / 86400);
                  $leadText = max(0, $days) . ' hari (berjalan)';
              }
            ?>
              <tr>
                <td><?= $idx + 1 ?></td>
                <td style="font-size:12px;">
                  <a href="index.php?page=ppbj_detail&id=<?= (int)$r['ppbj_id'] ?>" style="font-weight:700;color:#007AB3;">
                    <?= h($r['request_no']) ?>
                  </a>
                  <div style="color:#475569;margin-top:2px;">Tgl: <?= h(tgl_indo($r['request_date'])) ?></div>
                  <div style="color:#64748b;">
                    <?php if ($r['division_code']): ?><span class="badge badge-sky"><?= h($r['division_code']) ?></span><?php endif; ?>
                    <?= h($r['applied_by_name']) ?>
                  </div>
                </td>
                <td style="font-size:12px;">
                  <strong><?= h($r['nama_barang_jasa']) ?></strong>
                  <div style="color:#334155;margin-top:2px;">
                    Qty: <strong><?= rtrim(rtrim((string)$r['jumlah'], '0'), '.') ?> <?= h($r['satuan']) ?></strong>
                    <?php if (($r['jalur_pengadaan'] ?? 'PO') === 'NON_PO'): ?>
                      <span class="badge badge-purple" style="margin-left:4px;">Non PO</span>
                    <?php else: ?>
                      <span class="badge badge-blue" style="margin-left:4px;">Via PO</span>
                    <?php endif; ?>
                  </div>
                  <div style="color:#64748b;font-size:11px;"><?= h($r['peruntukan']) ?></div>
                </td>
                <td style="font-size:11.5px;">
                  <div><strong>Mgr:</strong> <?= $r['manager_date'] ? h(tgl_indo($r['manager_date'])) . ' (' . h($r['manager_name']) . ')' : '<span style="color:#94a3b8;">Menunggu</span>' ?></div>
                  <div><strong>Dir.Ops:</strong> <?= $r['dir_ops_date'] ? h(tgl_indo($r['dir_ops_date'])) . ' (' . h($r['dir_ops_name']) . ')' : '<span style="color:#94a3b8;">Menunggu</span>' ?></div>
                  <div><strong>Dir.Keu:</strong> <?= $r['dir_keu_date'] ? h(tgl_indo($r['dir_keu_date'])) . ' (' . h($r['dir_keu_name']) . ')' : '<span style="color:#94a3b8;">Menunggu</span>' ?></div>
                </td>
                <td style="font-size:12px;">
                  <?php if (!empty($r['bid_no'])): ?>
                    <div>Bid: <a href="index.php?page=bid_summary_form&id=<?= (int)$r['bid_id'] ?>" style="font-weight:700;color:#0369a1;"><?= h($r['bid_no']) ?></a></div>
                  <?php else: ?>
                    <div style="color:#94a3b8;">Bid: Belum</div>
                  <?php endif; ?>

                  <?php if (!empty($r['po_no'])): ?>
                    <div style="margin-top:2px;">
                      PO: <a href="index.php?page=print_po&id=<?= (int)$r['po_id'] ?>" target="_blank" style="font-weight:700;color:#1e40af;"><?= h($r['po_no']) ?></a>
                      <span style="color:#64748b;">(<?= h(tgl_indo($r['po_date'])) ?>)</span>
                    </div>
                  <?php elseif (($r['jalur_pengadaan'] ?? 'PO') === 'NON_PO'): ?>
                    <div style="margin-top:2px;color:#6d28d9;font-weight:600;">Tanpa PO (Langsung FTB)</div>
                  <?php endif; ?>
                  <div style="color:#334155;margin-top:2px;">Vendor: <strong><?= h($vendorShown) ?></strong></div>
                </td>
                <td style="text-align:right;font-size:12px;white-space:nowrap;">
                  <div style="color:#64748b;">Budget: <?= rupiah($r['harga_anggaran']) ?></div>
                  <div style="font-weight:800;color:#0f172a;margin-top:2px;">
                    <?= $realisasi > 0 ? rupiah($realisasi) : '-' ?>
                  </div>
                </td>
                <td style="font-size:12px;">
                  <?php if (!empty($r['ftb_no'])): ?>
                    <a href="index.php?page=print_ftb&id=<?= (int)$r['ftb_id'] ?>" target="_blank" style="font-weight:700;color:#008A3B;">
                      <?= h($r['ftb_no']) ?>
                    </a>
                    <div style="color:#475569;">Tgl: <?= h(tgl_indo($r['ftb_date'])) ?></div>
                    <div style="color:#334155;">
                      Terima: <strong><?= rtrim(rtrim((string)$r['qty_accepted'], '0'), '.') ?></strong>
                      <?php if ((float)$r['qty_rejected'] > 0): ?>
                        <span style="color:#dc2626;">(Tolak <?= rtrim(rtrim((string)$r['qty_rejected'], '0'), '.') ?>)</span>
                      <?php endif; ?>
                      · <?= h($r['status_penerimaan']) ?>
                    </div>
                  <?php else: ?>
                    <span style="color:#94a3b8;">Belum diterima</span>
                  <?php endif; ?>
                </td>
                <td style="font-size:12px;white-space:nowrap;font-weight:600;color:#334155;"><?= h($leadText) ?></td>
                <td><span class="badge <?= h($sBadge) ?>"><?= h($sLabel) ?></span></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  <?php else: ?>
    <div class="table-wrap">
      <table class="data-table">
        <thead>
          <tr>
            <th>Waktu</th>
            <th>No. PPBJ</th>
            <th>Divisi</th>
            <th>Aktor &amp; Role</th>
            <th>Aktivitas / Keputusan</th>
            <th>Catatan</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($activityLogs)): ?>
            <tr><td colspan="6" style="text-align:center;color:#64748b;padding:24px;">Belum ada catatan aktivitas.</td></tr>
          <?php else: ?>
            <?php foreach ($activityLogs as $al): ?>
              <tr>
                <td style="white-space:nowrap;font-size:12px;color:#475569;"><?= h(date('d/m/Y H:i', strtotime($al['created_at']))) ?></td>
                <td style="white-space:nowrap;">
                  <a href="index.php?page=ppbj_detail&id=<?= (int)$al['ppbj_id'] ?>" style="font-weight:700;color:#007AB3;">
                    <?= h($al['request_no']) ?>
                  </a>
                </td>
                <td><?= $al['division_code'] ? '<span class="badge badge-sky">' . h($al['division_code']) . '</span>' : '-' ?></td>
                <td style="font-size:12px;">
                  <strong><?= h($al['actor_name']) ?></strong>
                  <div style="color:#64748b;"><?= h($al['actor_role']) ?></div>
                </td>
                <td><strong><?= h($al['aksi']) ?></strong></td>
                <td style="font-size:12px;color:#334155;"><?= h($al['catatan']) ?></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>
