<?php
$isPemohon = ($user['role'] === 'PEMOHON');
$uid = (int)$user['id'];

if ($isPemohon) {
    $stW = $pdo->prepare(
        "SELECT po.*, p.request_no
         FROM purchase_orders po
         JOIN ppbj_requests p ON po.ppbj_id = p.id
         WHERE po.status IN ('TERBIT', 'DALAM_PENGIRIMAN') AND p.user_id = ?
         ORDER BY po.id DESC"
    );
    $stW->execute([$uid]);
    $waitingPo = $stW->fetchAll();

    $stNonPo = $pdo->prepare(
        "SELECT p.*, COUNT(pi.id) AS jml_non_po_item, COALESCE(SUM(pi.harga_anggaran),0) AS total_non_po
         FROM ppbj_requests p
         JOIN ppbj_items pi ON pi.ppbj_id = p.id
         WHERE p.user_id = ?
           AND pi.jalur_pengadaan = 'NON_PO'
           AND NOT EXISTS (SELECT 1 FROM ftb_items fi WHERE fi.ppbj_item_id = pi.id)
         GROUP BY p.id ORDER BY p.id DESC"
    );
    $stNonPo->execute([$uid]);
    $waitingNonPo = $stNonPo->fetchAll();

    $stF = $pdo->prepare(
        "SELECT f.*, p.request_no,
                (SELECT COUNT(*) FROM ftb_items fi WHERE fi.ftb_id = f.id) AS jml_item,
                (SELECT COALESCE(SUM(fi.qty_accepted),0) FROM ftb_items fi WHERE fi.ftb_id = f.id) AS tot_acc,
                (SELECT COALESCE(SUM(fi.qty_rejected),0) FROM ftb_items fi WHERE fi.ftb_id = f.id) AS tot_rej
         FROM ftb_receipts f
         JOIN ppbj_requests p ON f.ppbj_id = p.id
         WHERE p.user_id = ?
         ORDER BY f.id DESC"
    );
    $stF->execute([$uid]);
    $ftbs = $stF->fetchAll();
} else {
    $waitingPo = $pdo->query(
        "SELECT po.*, p.request_no
         FROM purchase_orders po
         JOIN ppbj_requests p ON po.ppbj_id = p.id
         WHERE po.status IN ('TERBIT', 'DALAM_PENGIRIMAN')
         ORDER BY po.id DESC"
    )->fetchAll();

    $waitingNonPo = $pdo->query(
        "SELECT p.*, COUNT(pi.id) AS jml_non_po_item, COALESCE(SUM(pi.harga_anggaran),0) AS total_non_po
         FROM ppbj_requests p
         JOIN ppbj_items pi ON pi.ppbj_id = p.id
         WHERE pi.jalur_pengadaan = 'NON_PO'
           AND NOT EXISTS (SELECT 1 FROM ftb_items fi WHERE fi.ppbj_item_id = pi.id)
         GROUP BY p.id ORDER BY p.id DESC"
    )->fetchAll();

    $ftbs = $pdo->query(
        "SELECT f.*, p.request_no,
                (SELECT COUNT(*) FROM ftb_items fi WHERE fi.ftb_id = f.id) AS jml_item,
                (SELECT COALESCE(SUM(fi.qty_accepted),0) FROM ftb_items fi WHERE fi.ftb_id = f.id) AS tot_acc,
                (SELECT COALESCE(SUM(fi.qty_rejected),0) FROM ftb_items fi WHERE fi.ftb_id = f.id) AS tot_rej
         FROM ftb_receipts f
         LEFT JOIN ppbj_requests p ON f.ppbj_id = p.id
         ORDER BY f.id DESC"
    )->fetchAll();
}
?>

<?php if (!empty($waitingPo) || !empty($waitingNonPo)): ?>
<div class="card" style="border-color:#93c5fd;background:#eff6ff;">
  <div class="card-header" style="border-bottom-color:#bfdbfe;">
    <div>
      <h2 class="card-title" style="color:#1e40af;">PO Aktif &amp; Pengadaan Non-PO Menunggu Penerimaan Barang/Jasa (FTB)</h2>
      <div style="font-size:12px;color:#1e3a8a;">Pilih PO atau pengadaan Non-PO berikut untuk membuat Formulir Terima Barang/Jasa (FTB) di akhir alur.</div>
    </div>
  </div>
  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th>No. PO / Jalur</th>
          <th>Ref. PPBJ</th>
          <th>Penjual / Seller</th>
          <th>Lokasi Pengiriman</th>
          <th style="text-align:right;">Total</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($waitingPo as $w): ?>
          <tr>
            <td><strong><?= h($w['po_no']) ?></strong> (<?= tgl_indo($w['po_date']) ?>)</td>
            <td><a href="index.php?page=ppbj_detail&id=<?= (int)$w['ppbj_id'] ?>" style="font-weight:700;color:#007AB3;"><?= h($w['request_no']) ?></a></td>
            <td><?= h($w['vendor_name']) ?></td>
            <td><?= h($w['delivery_location']) ?></td>
            <td style="text-align:right;font-weight:700;"><?= rupiah($w['total_po']) ?></td>
            <td>
              <a href="index.php?page=ftb_form&po_id=<?= (int)$w['id'] ?>" class="btn btn-green btn-sm">
                Buat Form FTB &rarr;
              </a>
            </td>
          </tr>
        <?php endforeach; ?>
        <?php foreach ($waitingNonPo as $nw): ?>
          <tr>
            <td><span class="badge badge-purple">Non PO (<?= (int)$nw['jml_non_po_item'] ?> item)</span></td>
            <td><a href="index.php?page=ppbj_detail&id=<?= (int)$nw['id'] ?>" style="font-weight:700;color:#007AB3;"><?= h($nw['request_no']) ?></a></td>
            <td><?= h($nw['vendor_name'] ?: '-') ?></td>
            <td><?= h($nw['delivery_location']) ?></td>
            <td style="text-align:right;font-weight:700;"><?= rupiah($nw['total_non_po']) ?></td>
            <td>
              <a href="index.php?page=ftb_form&nonpo_ppbj_id=<?= (int)$nw['id'] ?>" class="btn btn-green btn-sm">
                Buat Form FTB (Non PO) &rarr;
              </a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<div class="card">
  <div class="card-header">
    <div>
      <h1 class="card-title" style="font-size:18px;">Daftar Formulir Terima Barang/Jasa (FTB)</h1>
      <div style="font-size:12px;color:#64748b;">Dokumentasi serah terima akhir pembelian baru maupun barang retur PT. Potensi Bumi Sakti.</div>
    </div>
    <a href="index.php?page=ftb_form" class="btn btn-green btn-sm">+ Isi Form FTB Baru</a>
  </div>

  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th>No. FTB &amp; Tanggal</th>
          <th>Sumber Penerimaan</th>
          <th>Penjual / Retur Dari</th>
          <th>No. PO / SJ / Lokasi Gudang</th>
          <th>Accepted / Rejected</th>
          <th>Penandatangan</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($ftbs)): ?>
          <tr><td colspan="7" style="text-align:center;padding:30px;color:#64748b;">Belum ada dokumen FTB.</td></tr>
        <?php else: foreach ($ftbs as $f): ?>
          <tr>
            <td>
              <strong><?= h($f['ftb_no']) ?></strong>
              <div style="font-size:11.5px;color:#64748b;"><?= tgl_indo($f['ftb_date']) ?></div>
              <?php if ($f['request_no']): ?>
                <div style="font-size:11px;color:#007AB3;">Ref: <?= h($f['request_no']) ?></div>
              <?php endif; ?>
            </td>
            <td>
              <?php if ($f['sumber_penerimaan'] === 'PEMBELIAN_BARU'): ?>
                <span class="badge badge-blue">Pembelian Baru</span>
              <?php else: ?>
                <span class="badge badge-orange">Barang Retur</span>
              <?php endif; ?>
            </td>
            <td>
              <?php if ($f['sumber_penerimaan'] === 'PEMBELIAN_BARU'): ?>
                <strong><?= h($f['penjual_seller']) ?></strong>
              <?php else: ?>
                <strong><?= h($f['retur_divisi']) ?></strong>
                <div style="font-size:11.5px;color:#64748b;">Nama: <?= h($f['retur_nama']) ?></div>
              <?php endif; ?>
            </td>
            <td style="font-size:12px;">
              <?php if ($f['po_no']): ?><div>PO: <strong><?= h($f['po_no']) ?></strong></div><?php endif; ?>
              <?php if ($f['sj_do_no']): ?><div>SJ/DO: <?= h($f['sj_do_no']) ?></div><?php endif; ?>
              <div style="color:#64748b;">Gudang: <?= h($f['lokasi_gudang']) ?></div>
            </td>
            <td style="font-size:12px;white-space:nowrap;">
              <span class="badge badge-green">Accepted: <?= rtrim(rtrim((string)$f['tot_acc'], '0'), '.') ?></span>
              <?php if ((float)$f['tot_rej'] > 0): ?>
                <span class="badge badge-red">Rejected: <?= rtrim(rtrim((string)$f['tot_rej'], '0'), '.') ?></span>
              <?php endif; ?>
            </td>
            <td style="font-size:12px;">
              <div>User/Gdg: <strong><?= h($f['pemakai_gudang_nama']) ?></strong></div>
              <div>Proc: <strong><?= h($f['procurement_nama']) ?></strong></div>
            </td>
            <td style="white-space:nowrap;">
              <a href="index.php?page=print_ftb&id=<?= (int)$f['id'] ?>" target="_blank" class="btn btn-primary btn-sm">Cetak FTB</a>
              <?php if ($f['ppbj_id']): ?>
                <a href="index.php?page=ppbj_detail&id=<?= (int)$f['ppbj_id'] ?>" class="btn btn-outline btn-sm">Lihat PPBJ</a>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>
