<?php
ob_start();
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/helpers.php';

$pdo = get_db();

if (current_user()) {
    header('Location: index.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = (string)($_POST['password'] ?? '');

    if ($username === '' || $password === '') {
        $error = 'Username dan password wajib diisi.';
    } else {
        $stmt = $pdo->prepare(
            "SELECT u.*, d.kode_divisi AS division_code, d.nama_divisi AS division_name
             FROM users u
             LEFT JOIN divisions d ON u.division_id = d.id
             WHERE u.username = ? AND u.aktif = 1 LIMIT 1"
        );
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        if ($user && password_verify($password, $user['password_hash'])) {
            unset($user['password_hash']);
            $_SESSION['user'] = $user;
            set_flash('Selamat datang, ' . $user['nama_lengkap'] . ' (' . role_label($user['role']) . ').');
            header('Location: index.php');
            exit;
        } else {
            $error = 'Username atau password salah.';
        }
    }
}

$demoAccounts = $pdo->query(
    "SELECT u.username, u.nama_lengkap, u.jabatan, u.role, d.kode_divisi
     FROM users u
     LEFT JOIN divisions d ON u.division_id = d.id
     WHERE u.aktif = 1 ORDER BY u.id ASC"
)->fetchAll();
$logo = logo_src();
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login — Sistem Informasi PPBJ &amp; FTB | PT. Potensi Bumi Sakti</title>
  <link rel="icon" type="image/jpeg" href="<?= h($logo) ?>">
  <style>
    * { box-sizing: border-box; }
    body {
      margin: 0;
      min-height: 100vh;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
      background: linear-gradient(135deg, #f0f9ff 0%, #f8fafc 50%, #ecfdf5 100%);
      color: #0f172a;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }
    .login-wrap {
      width: 100%;
      max-width: 920px;
      display: grid;
      grid-template-columns: 1.05fr 0.95fr;
      background: #fff;
      border-radius: 20px;
      border: 1px solid #e2e8f0;
      box-shadow: 0 20px 50px rgba(15, 23, 42, .08);
      overflow: hidden;
    }
    .left-pane {
      padding: 36px;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }
    .right-pane {
      background: linear-gradient(155deg, #007AB3 0%, #009ADE 55%, #008A3B 100%);
      color: #fff;
      padding: 32px;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }
    .brand {
      display: flex;
      align-items: center;
      gap: 14px;
      margin-bottom: 24px;
    }
    .brand img {
      width: 56px;
      height: 56px;
      object-fit: contain;
      border-radius: 12px;
      border: 1px solid #e2e8f0;
      padding: 4px;
      background: #fff;
    }
    .brand-co { font-size: 11px; font-weight: 800; color: #008A3B; text-transform: uppercase; letter-spacing: .06em; }
    .brand-app { font-size: 18px; font-weight: 800; color: #0f172a; line-height: 1.2; }
    h1 { margin: 0 0 6px; font-size: 22px; font-weight: 800; }
    .sub { margin: 0 0 22px; font-size: 13px; color: #64748b; }
    .form-group { margin-bottom: 15px; }
    label { display: block; font-size: 12px; font-weight: 700; color: #334155; margin-bottom: 6px; }
    input[type=text], input[type=password] {
      width: 100%;
      padding: 11px 13px;
      border: 1px solid #cbd5e1;
      border-radius: 10px;
      font-size: 14px;
      font-family: inherit;
    }
    input:focus {
      outline: none;
      border-color: #009ADE;
      box-shadow: 0 0 0 3px rgba(0,154,222,.15);
    }
    .btn-login {
      width: 100%;
      padding: 12px;
      border: none;
      border-radius: 10px;
      background: #009ADE;
      color: #fff;
      font-size: 14px;
      font-weight: 700;
      cursor: pointer;
      margin-top: 4px;
    }
    .btn-login:hover { background: #007AB3; }
    .err {
      background: #fef2f2;
      border: 1px solid #fecaca;
      color: #991b1b;
      padding: 10px 12px;
      border-radius: 10px;
      font-size: 12.5px;
      font-weight: 600;
      margin-bottom: 16px;
    }
    .flow-title { font-size: 13px; font-weight: 800; text-transform: uppercase; letter-spacing: .05em; opacity: .9; margin-bottom: 10px; }
    .flow-list { list-style: none; padding: 0; margin: 0 0 20px; font-size: 12.5px; }
    .flow-list li {
      padding: 6px 0;
      border-bottom: 1px solid rgba(255,255,255,.15);
      display: flex;
      gap: 8px;
      align-items: center;
    }
    .flow-num {
      width: 20px; height: 20px; border-radius: 999px;
      background: rgba(255,255,255,.22); font-weight: 800; font-size: 11px;
      display: inline-flex; align-items: center; justify-content: center; flex-shrink: 0;
    }
    .demo-box {
      background: rgba(15, 23, 42, .22);
      border: 1px solid rgba(255,255,255,.2);
      border-radius: 12px;
      padding: 12px;
    }
    .demo-head { font-size: 11.5px; font-weight: 700; margin-bottom: 8px; }
    .demo-btn {
      width: 100%;
      text-align: left;
      background: rgba(255,255,255,.13);
      border: 1px solid rgba(255,255,255,.2);
      color: #fff;
      padding: 7px 10px;
      border-radius: 8px;
      font-size: 11.5px;
      cursor: pointer;
      margin-bottom: 5px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .demo-btn:hover { background: rgba(255,255,255,.24); }
    @media (max-width: 780px) {
      .login-wrap { grid-template-columns: 1fr; }
    }
  </style>
</head>
<body>
  <div class="login-wrap">
    <div class="left-pane">
      <div class="brand">
        <img src="<?= h($logo) ?>" alt="Logo PT Potensi Bumi Sakti">
        <div>
          <div class="brand-co">PT. Potensi Bumi Sakti</div>
          <div class="brand-app">Sistem Informasi PPBJ &amp; FTB</div>
        </div>
      </div>

      <h1>Masuk ke Sistem</h1>
      <p class="sub">Silakan login sesuai akun peran Anda untuk mengajukan atau menyetujui PPBJ &amp; FTB.</p>

      <?php if ($error !== ''): ?>
        <div class="err"><?= h($error) ?></div>
      <?php endif; ?>

      <form method="post">
        <div class="form-group">
          <label for="username">Username</label>
          <input type="text" id="username" name="username" required placeholder="Masukkan username..." value="<?= h($_POST['username'] ?? '') ?>">
        </div>
        <div class="form-group">
          <label for="password">Password</label>
          <input type="password" id="password" name="password" required placeholder="Masukkan password...">
        </div>
        <button type="submit" class="btn-login">Login ke Portal Procurement</button>
      </form>
    </div>

    <div class="right-pane">
      <div>
        <div class="flow-title">Alur Resmi PPBJ &amp; FTB</div>
        <ul class="flow-list">
          <li><span class="flow-num">1</span> <span><strong>User / Pemohon</strong> mengajukan Form PPBJ</span></li>
          <li><span class="flow-num">2</span> <span><strong>Atasan / Manager</strong> melakukan approval awal</span></li>
          <li><span class="flow-num">3</span> <span><strong>Direktur Operasional</strong> menyetujui operasional</span></li>
          <li><span class="flow-num">4</span> <span><strong>Direktur Keuangan</strong> approval final anggaran</span></li>
          <li><span class="flow-num">5</span> <span><strong>Procurement</strong> menerbitkan Purchase Order (PO)</span></li>
          <li><span class="flow-num">6</span> <span><strong>Form Terima Barang (FTB)</strong> di akhir pengadaan</span></li>
        </ul>
      </div>

      <div class="demo-box">
        <div class="demo-head">Klik Akun untuk Mengisi Login (Default: <code>123456</code> | Super Admin: <code>admin123</code>):</div>
        <?php foreach ($demoAccounts as $acc):
          $pwdHint = ($acc['username'] === 'superadmin') ? 'admin123' : '123456';
        ?>
          <button type="button" class="demo-btn" onclick="fillLogin('<?= h($acc['username']) ?>', '<?= h($pwdHint) ?>')">
            <span><strong><?= h(role_label($acc['role'])) ?><?= !empty($acc['kode_divisi']) ? ' (' . h($acc['kode_divisi']) . ')' : '' ?></strong> — <?= h($acc['nama_lengkap']) ?></span>
            <code><?= h($acc['username']) ?></code>
          </button>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <script>
    function fillLogin(u, p) {
      document.getElementById('username').value = u;
      document.getElementById('password').value = p || '123456';
    }
  </script>
</body>
</html>
