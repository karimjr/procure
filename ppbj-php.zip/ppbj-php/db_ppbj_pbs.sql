-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 25 Nov 2026 pada 05.08
-- Versi server: 10.4.32-MariaDB-log
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_ppbj_pbs`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `bid_items`
--

CREATE TABLE `bid_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `bid_id` int(10) UNSIGNED NOT NULL,
  `ppbj_item_id` int(10) UNSIGNED NOT NULL,
  `bid_vendor_id` int(10) UNSIGNED NOT NULL,
  `harga_penawaran` decimal(16,2) NOT NULL DEFAULT 0.00,
  `total_penawaran` decimal(16,2) NOT NULL DEFAULT 0.00,
  `jalur_pengadaan` enum('PO','NON_PO') NOT NULL DEFAULT 'PO',
  `is_selected` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `bid_items`
--

INSERT INTO `bid_items` (`id`, `bid_id`, `ppbj_item_id`, `bid_vendor_id`, `harga_penawaran`, `total_penawaran`, `jalur_pengadaan`, `is_selected`) VALUES
(1, 1, 1, 1, 21000000.00, 21000000.00, 'PO', 1),
(2, 1, 1, 2, 22200000.00, 22200000.00, 'PO', 0),
(3, 1, 2, 1, 15250000.00, 30500000.00, 'PO', 1),
(4, 1, 2, 2, 15900000.00, 31800000.00, 'PO', 0),
(5, 1, 3, 1, 1200000.00, 2400000.00, 'PO', 1),
(6, 1, 3, 2, 1350000.00, 2700000.00, 'PO', 0),
(7, 2, 4, 3, 825000.00, 4950000.00, 'PO', 1),
(8, 2, 4, 4, 910000.00, 5460000.00, 'PO', 0),
(9, 2, 5, 3, 7950000.00, 31800000.00, 'PO', 0),
(10, 2, 5, 4, 7650000.00, 30600000.00, 'PO', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `bid_summaries`
--

CREATE TABLE `bid_summaries` (
  `id` int(10) UNSIGNED NOT NULL,
  `bid_no` varchar(60) NOT NULL,
  `bid_date` date NOT NULL,
  `ppbj_id` int(10) UNSIGNED NOT NULL,
  `judul` varchar(200) NOT NULL,
  `proses_mode` enum('PO','NON_PO') NOT NULL DEFAULT 'PO',
  `catatan_rekomendasi` text DEFAULT NULL,
  `dibuat_oleh` varchar(120) NOT NULL,
  `status` enum('DRAFT','FINAL') NOT NULL DEFAULT 'FINAL',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `bid_summaries`
--

INSERT INTO `bid_summaries` (`id`, `bid_no`, `bid_date`, `ppbj_id`, `judul`, `proses_mode`, `catatan_rekomendasi`, `dibuat_oleh`, `status`, `created_at`, `updated_at`) VALUES
(1, '001/BID/XI-2026/PBS', '2026-11-06', 1, 'Perbandingan Harga Perangkat IT Site Woyla', 'PO', 'PT Mitra Teknika Nusantara menawarkan harga terendah & garansi on-site.', 'Noviani Nuzulia', 'FINAL', '2026-11-25 03:55:22', '2026-11-25 03:55:22'),
(2, '002/BID/XI-2026/PBS', '2026-11-13', 2, 'Bid Summary Suku Cadang & Pelumas Workshop', 'PO', 'Split order: Item 1 ke PT Traktor & Sparepart, Item 2 ke PT Energi Pelumas untuk harga terbaik.', 'Noviani Nuzulia', 'FINAL', '2026-11-25 03:55:22', '2026-11-25 03:55:22');

-- --------------------------------------------------------

--
-- Struktur dari tabel `bid_vendors`
--

CREATE TABLE `bid_vendors` (
  `id` int(10) UNSIGNED NOT NULL,
  `bid_id` int(10) UNSIGNED NOT NULL,
  `vendor_id` int(10) UNSIGNED DEFAULT NULL,
  `vendor_name` varchar(150) NOT NULL,
  `termin_pembayaran` varchar(120) DEFAULT 'TOP 30 Hari setelah BAST/FTB',
  `estimasi_kirim` varchar(100) DEFAULT '7 Hari Kerja',
  `catatan_penawaran` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `bid_vendors`
--

INSERT INTO `bid_vendors` (`id`, `bid_id`, `vendor_id`, `vendor_name`, `termin_pembayaran`, `estimasi_kirim`, `catatan_penawaran`) VALUES
(1, 1, 1, 'PT Mitra Teknika Nusantara', 'TOP 30 Hari setelah FTB', '5 Hari Kerja', NULL),
(2, 1, 2, 'CV Bumi Karya Mandiri', 'DP 30% + 70% setelah FTB', '7 Hari Kerja', NULL),
(3, 2, 3, 'PT Traktor & Sparepart Sejahtera', 'TOP 30 Hari', '4 Hari Kerja', NULL),
(4, 2, 4, 'PT Energi Pelumas Indonesia', 'TOP 14 Hari', '3 Hari Kerja', NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `divisions`
--

CREATE TABLE `divisions` (
  `id` int(10) UNSIGNED NOT NULL,
  `kode_divisi` varchar(20) NOT NULL,
  `nama_divisi` varchar(150) NOT NULL,
  `lokasi_default` varchar(255) DEFAULT 'Dusun Pintu Rimba Glee Siblah Woyla Aceh',
  `aktif` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `divisions`
--

INSERT INTO `divisions` (`id`, `kode_divisi`, `nama_divisi`, `lokasi_default`, `aktif`, `created_at`) VALUES
(1, 'OIT', 'Divisi IT & Operational IT (OIT)', 'Dusun Pintu Rimba Glee Siblah Woyla Aceh', 1, '2026-11-25 03:55:22'),
(2, 'WKS', 'Workshop & Mekanik Site Woyla', 'Workshop Utama Dusun Pintu Rimba Woyla Aceh', 1, '2026-11-25 03:55:22'),
(3, 'HSE', 'HSE / Keselamatan Kerja (K3)', 'Kantor & Site Operasional Woyla Aceh', 1, '2026-11-25 03:55:22'),
(4, 'OPS', 'Operational Site Woyla Aceh', 'Dusun Pintu Rimba Glee Siblah Woyla Aceh', 1, '2026-11-25 03:55:22'),
(5, 'GA', 'General Affairs & Kendaraan', 'Kantor Operational Site Woyla Aceh', 1, '2026-11-25 03:55:22'),
(6, 'FIN', 'Finance & Accounting', 'Head Office Jakarta / Site Woyla', 1, '2026-11-25 03:55:22');

-- --------------------------------------------------------

--
-- Struktur dari tabel `ftb_items`
--

CREATE TABLE `ftb_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `ftb_id` int(10) UNSIGNED NOT NULL,
  `ppbj_item_id` int(10) UNSIGNED DEFAULT NULL,
  `item_no` int(11) NOT NULL DEFAULT 1,
  `perincian` varchar(255) NOT NULL,
  `qty` decimal(12,2) NOT NULL DEFAULT 1.00,
  `unit` varchar(30) NOT NULL DEFAULT 'Unit',
  `catatan_kondisi` varchar(255) DEFAULT 'Baik / Lengkap',
  `qty_accepted` decimal(12,2) NOT NULL DEFAULT 1.00,
  `qty_rejected` decimal(12,2) NOT NULL DEFAULT 0.00,
  `status_penerimaan` enum('Accepted','Partial','Rejected') NOT NULL DEFAULT 'Accepted'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `ftb_items`
--

INSERT INTO `ftb_items` (`id`, `ftb_id`, `ppbj_item_id`, `item_no`, `perincian`, `qty`, `unit`, `catatan_kondisi`, `qty_accepted`, `qty_rejected`, `status_penerimaan`) VALUES
(1, 1, 1, 1, 'Laptop Core i7, RAM 16 GB, 512 GB SSD, RTX4050 Merek HP', 1.00, 'Unit', 'Segel utuh, normal', 1.00, 0.00, 'Accepted'),
(2, 1, 2, 2, 'Laptop Core i7, RAM 16 GB, 512 GB SSD Merek HP', 2.00, 'Unit', 'Lengkap tas & charger', 2.00, 0.00, 'Accepted'),
(3, 1, 3, 3, 'Jasa perbaikan sparepart IT', 2.00, 'Unit', 'Selesai & diuji', 2.00, 0.00, 'Accepted');

-- --------------------------------------------------------

--
-- Struktur dari tabel `ftb_receipts`
--

CREATE TABLE `ftb_receipts` (
  `id` int(10) UNSIGNED NOT NULL,
  `ftb_no` varchar(60) NOT NULL,
  `ftb_date` date NOT NULL,
  `doc_form_no` varchar(30) NOT NULL DEFAULT 'FRM.LOG.02.00',
  `doc_issue_date` varchar(30) NOT NULL DEFAULT '27 Mei 2025',
  `doc_revision` varchar(10) NOT NULL DEFAULT '01',
  `ppbj_id` int(10) UNSIGNED DEFAULT NULL,
  `po_id` int(10) UNSIGNED DEFAULT NULL,
  `bid_id` int(10) UNSIGNED DEFAULT NULL,
  `sumber_penerimaan` enum('PEMBELIAN_BARU','BARANG_RETUR') NOT NULL DEFAULT 'PEMBELIAN_BARU',
  `penjual_seller` varchar(150) DEFAULT NULL,
  `po_no` varchar(60) DEFAULT NULL,
  `po_date` date DEFAULT NULL,
  `sj_do_no` varchar(80) DEFAULT NULL,
  `retur_divisi` varchar(120) DEFAULT NULL,
  `retur_nama` varchar(120) DEFAULT NULL,
  `lokasi_gudang` varchar(200) NOT NULL,
  `pemakai_gudang_nama` varchar(120) NOT NULL,
  `pemakai_gudang_jabatan` varchar(100) NOT NULL,
  `procurement_nama` varchar(120) NOT NULL,
  `procurement_jabatan` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `ftb_receipts`
--

INSERT INTO `ftb_receipts` (`id`, `ftb_no`, `ftb_date`, `doc_form_no`, `doc_issue_date`, `doc_revision`, `ppbj_id`, `po_id`, `bid_id`, `sumber_penerimaan`, `penjual_seller`, `po_no`, `po_date`, `sj_do_no`, `retur_divisi`, `retur_nama`, `lokasi_gudang`, `pemakai_gudang_nama`, `pemakai_gudang_jabatan`, `procurement_nama`, `procurement_jabatan`, `created_at`) VALUES
(1, '001/FTB/XI-2026/PBS', '2026-11-13', 'FRM.LOG.02.00', '27 Mei 2025', '01', 1, 1, NULL, 'PEMBELIAN_BARU', 'PT Mitra Teknika Nusantara', '001/PO/XI-2026/PBS', '2026-11-07', 'SJ-MTN-20261112', NULL, NULL, 'Gudang Site Woyla Aceh (Dusun Pintu Rimba)', 'Abdul Karim', 'IT & Operational Site', 'Noviani Nuzulia', 'Procurement & Gudang', '2026-11-25 03:55:22');

-- --------------------------------------------------------

--
-- Struktur dari tabel `po_items`
--

CREATE TABLE `po_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `po_id` int(10) UNSIGNED NOT NULL,
  `ppbj_item_id` int(10) UNSIGNED DEFAULT NULL,
  `item_no` int(11) NOT NULL DEFAULT 1,
  `nama_barang_jasa` varchar(255) NOT NULL,
  `qty` decimal(12,2) NOT NULL DEFAULT 1.00,
  `satuan` varchar(30) NOT NULL DEFAULT 'Unit',
  `harga_satuan` decimal(16,2) NOT NULL DEFAULT 0.00,
  `subtotal` decimal(16,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `po_items`
--

INSERT INTO `po_items` (`id`, `po_id`, `ppbj_item_id`, `item_no`, `nama_barang_jasa`, `qty`, `satuan`, `harga_satuan`, `subtotal`) VALUES
(1, 1, 1, 1, 'Laptop Core i7, RAM 16 GB, 512 GB SSD, RTX4050 Merek HP', 1.00, 'Unit', 21000000.00, 21000000.00),
(2, 1, 2, 2, 'Laptop Core i7, RAM 16 GB, 512 GB SSD Merek HP', 2.00, 'Unit', 15250000.00, 30500000.00),
(3, 1, 3, 3, 'Jasa perbaikan sparepart IT', 2.00, 'Unit', 1200000.00, 2400000.00),
(4, 2, 4, 1, 'Filter Hidrolik & Filter Solar Excavator PC200', 6.00, 'PCS', 825000.00, 4950000.00),
(5, 3, 5, 1, 'Oli Mesin Diesel SAE 15W-40 (209 Liter/Drum)', 4.00, 'Drum', 7650000.00, 30600000.00);

-- --------------------------------------------------------

--
-- Struktur dari tabel `ppbj_items`
--

CREATE TABLE `ppbj_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `ppbj_id` int(10) UNSIGNED NOT NULL,
  `item_no` int(11) NOT NULL DEFAULT 1,
  `jumlah` decimal(12,2) NOT NULL DEFAULT 1.00,
  `satuan` varchar(30) NOT NULL DEFAULT 'Unit',
  `no_anggaran` varchar(50) DEFAULT '',
  `nama_barang_jasa` varchar(255) NOT NULL,
  `kategori_pengadaan` varchar(100) NOT NULL DEFAULT 'Parts & Consumables',
  `peruntukan` text DEFAULT NULL,
  `foto_path` varchar(255) DEFAULT NULL,
  `harga_unit` decimal(16,2) NOT NULL DEFAULT 0.00,
  `harga_anggaran` decimal(16,2) NOT NULL DEFAULT 0.00,
  `jalur_pengadaan` enum('PO','NON_PO') NOT NULL DEFAULT 'PO'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `ppbj_items`
--

INSERT INTO `ppbj_items` (`id`, `ppbj_id`, `item_no`, `jumlah`, `satuan`, `no_anggaran`, `nama_barang_jasa`, `kategori_pengadaan`, `peruntukan`, `foto_path`, `harga_unit`, `harga_anggaran`, `jalur_pengadaan`) VALUES
(1, 1, 1, 1.00, 'Unit', 'ANG-IT-01', 'Laptop Core i7, RAM 16 GB, 512 GB SSD, RTX4050 Merek HP', 'Information Technology & Communication', 'Untuk SPV Workshop AutoCAD/Sketchup', NULL, 21500000.00, 21500000.00, 'PO'),
(2, 1, 2, 2.00, 'Unit', 'ANG-IT-02', 'Laptop Core i7, RAM 16 GB, 512 GB SSD Merek HP', 'Information Technology & Communication', 'Untuk Manager Pembelian & PA Dir. Ops', NULL, 15500000.00, 31000000.00, 'PO'),
(3, 1, 3, 2.00, 'Unit', 'ANG-IT-03', 'Jasa perbaikan sparepart IT', 'Service', 'Perbaikan perangkat IT site', NULL, 1250000.00, 2500000.00, 'PO'),
(4, 2, 1, 6.00, 'PCS', 'ANG-WKS-11', 'Filter Hidrolik & Filter Solar Excavator PC200', 'Parts & Consumables', 'Maintenance 500 HM Excavator', NULL, 850000.00, 5100000.00, 'PO'),
(5, 2, 2, 4.00, 'Drum', 'ANG-WKS-12', 'Oli Mesin Diesel SAE 15W-40 (209 Liter/Drum)', 'Lubricant', 'Pelumas alat berat & genset 250 kVA', NULL, 7800000.00, 31200000.00, 'PO'),
(6, 3, 1, 20.00, 'Pasang', 'ANG-HSE-03', 'Sepatu Safety Steel Toe Anti-Slip SNI', 'Kesehatan, Keselamatan Kerja & Lingkungan', 'Tim lapangan & workshop site', NULL, 620000.00, 12400000.00, 'PO'),
(7, 3, 2, 25.00, 'PCS', 'ANG-HSE-03', 'Helm Safety Proyek + Rompi High-Vis 3M', 'Kesehatan, Keselamatan Kerja & Lingkungan', 'Personel operasional baru', NULL, 280000.00, 7000000.00, 'PO'),
(8, 4, 1, 1.00, 'Paket', 'ANG-OPS-09', 'Jasa Kalibrasi Panel ATS & Load Bank Test Genset 250 kVA', 'Mechanical Electrical Plumbing', 'Menjamin keandalan listrik cadangan site', NULL, 14500000.00, 14500000.00, 'PO'),
(9, 4, 2, 10.00, 'Unit', 'ANG-OPS-10', 'Material Bahan Baku Pendukung Uji Produksi', 'Chemical', 'Kebutuhan uji coba produksi site Q4', NULL, 950000.00, 9500000.00, 'PO'),
(10, 5, 1, 4.00, 'PCS', 'ANG-GA-04', 'Ban Mobil Off-Road All Terrain 265/65 R17', 'Vehicles', 'Unit Hilux Operasional Site BK 8821 PB', NULL, 2450000.00, 9800000.00, 'PO'),
(11, 5, 2, 1.00, 'Paket', 'ANG-GA-04', 'Jasa Spooring, Balancing & Servis Rem', 'Service', 'Keamanan kendaraan operasional lapangan', NULL, 1200000.00, 1200000.00, 'PO');

-- --------------------------------------------------------

--
-- Struktur dari tabel `ppbj_logs`
--

CREATE TABLE `ppbj_logs` (
  `id` int(10) UNSIGNED NOT NULL,
  `ppbj_id` int(10) UNSIGNED NOT NULL,
  `actor_name` varchar(120) NOT NULL,
  `actor_role` varchar(80) NOT NULL,
  `aksi` varchar(120) NOT NULL,
  `catatan` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `ppbj_logs`
--

INSERT INTO `ppbj_logs` (`id`, `ppbj_id`, `actor_name`, `actor_role`, `aksi`, `catatan`, `created_at`) VALUES
(1, 1, 'Abdul Karim', 'Pemohon', 'Mengajukan PPBJ', 'Pengajuan perangkat IT Site Woyla Aceh.', '2026-11-25 03:55:22'),
(2, 1, 'Bambang Sebastiar', 'Atasan / Manager', 'Disetujui Manager', 'Lanjut.', '2026-11-25 03:55:22'),
(3, 1, 'Hendra Wijaya', 'Direktur Operasional', 'Disetujui Direktur Operasional', 'Setuju.', '2026-11-25 03:55:22'),
(4, 1, 'Wesly Marugan Simatupang', 'Direktur Keuangan', 'Disetujui Direktur Keuangan (Final)', 'Anggaran tersedia.', '2026-11-25 03:55:22'),
(5, 1, 'Noviani Nuzulia', 'Procurement', 'Bid Summary & PO Terbit (001/PO/XI-2026/PBS)', 'Pemenang: PT Mitra Teknika Nusantara.', '2026-11-25 03:55:22'),
(6, 1, 'Abdul Karim & Noviani Nuzulia', 'Gudang & Procurement', 'FTB Diterbitkan (001/FTB/XI-2026/PBS)', 'Selesai diterima.', '2026-11-25 03:55:22'),
(7, 2, 'Abdul Karim', 'Pemohon', 'Mengajukan PPBJ', 'Suku cadang & oli workshop.', '2026-11-25 03:55:22'),
(8, 2, 'Bambang Sebastiar', 'Atasan / Manager', 'Disetujui Manager', 'Lanjut.', '2026-11-25 03:55:22'),
(9, 2, 'Hendra Wijaya', 'Direktur Operasional', 'Disetujui Direktur Operasional', 'Lanjut.', '2026-11-25 03:55:22'),
(10, 2, 'Wesly Marugan Simatupang', 'Direktur Keuangan', 'Disetujui Direktur Keuangan (Final)', 'Siap Bid Summary.', '2026-11-25 03:55:22'),
(11, 2, 'Noviani Nuzulia', 'Procurement', 'Bid Summary & 2 PO Terbit', 'Filter ke PT Traktor & Sparepart; Oli ke PT Energi Pelumas.', '2026-11-25 03:55:22'),
(12, 3, 'Abdul Karim', 'Pemohon', 'Mengajukan PPBJ', 'Pengadaan APD wajib K3.', '2026-11-25 03:55:22'),
(13, 3, 'Bambang Sebastiar', 'Atasan / Manager', 'Disetujui Manager', 'Sesuai standar K3.', '2026-11-25 03:55:22'),
(14, 3, 'Hendra Wijaya', 'Direktur Operasional', 'Disetujui Direktur Operasional', 'Lanjut.', '2026-11-25 03:55:22'),
(15, 3, 'Wesly Marugan Simatupang', 'Direktur Keuangan', 'Disetujui Direktur Keuangan (Final)', 'Siap dibuatkan Bid Summary oleh Procurement.', '2026-11-25 03:55:22'),
(16, 4, 'Abdul Karim', 'Pemohon', 'Mengajukan PPBJ', 'Kalibrasi genset akhir November.', '2026-11-25 03:55:22'),
(17, 4, 'Bambang Sebastiar', 'Atasan / Manager', 'Disetujui Manager', 'Diteruskan ke Dir. Ops.', '2026-11-25 03:55:22'),
(18, 4, 'Hendra Wijaya', 'Direktur Operasional', 'Disetujui Direktur Operasional', 'Diteruskan ke Direktur Keuangan.', '2026-11-25 03:55:22'),
(19, 5, 'Abdul Karim', 'Pemohon', 'Mengajukan PPBJ', 'Menunggu persetujuan Atasan / Manager.', '2026-11-25 03:55:22');

-- --------------------------------------------------------

--
-- Struktur dari tabel `ppbj_requests`
--

CREATE TABLE `ppbj_requests` (
  `id` int(10) UNSIGNED NOT NULL,
  `request_no` varchar(60) NOT NULL,
  `doc_form_no` varchar(30) NOT NULL DEFAULT 'FRM.APR.01.00',
  `doc_issue_date` varchar(30) NOT NULL DEFAULT '27 Mei 2025',
  `doc_revision` varchar(10) NOT NULL DEFAULT '00',
  `request_date` date NOT NULL,
  `received_date` date DEFAULT NULL,
  `division_id` int(10) UNSIGNED DEFAULT NULL,
  `division_code` varchar(20) DEFAULT NULL,
  `division_subdivision` varchar(150) NOT NULL,
  `delivery_location` varchar(255) NOT NULL,
  `request_types` varchar(255) NOT NULL,
  `catatan_umum` text DEFAULT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `applied_by_name` varchar(120) NOT NULL,
  `applied_by_date` date DEFAULT NULL,
  `manager_name` varchar(120) DEFAULT NULL,
  `manager_note` text DEFAULT NULL,
  `manager_date` date DEFAULT NULL,
  `dir_ops_name` varchar(120) DEFAULT NULL,
  `dir_ops_note` text DEFAULT NULL,
  `dir_ops_date` date DEFAULT NULL,
  `dir_keu_name` varchar(120) DEFAULT NULL,
  `dir_keu_note` text DEFAULT NULL,
  `dir_keu_date` date DEFAULT NULL,
  `po_no` varchar(150) DEFAULT NULL,
  `po_date` date DEFAULT NULL,
  `vendor_id` int(10) UNSIGNED DEFAULT NULL,
  `vendor_name` varchar(255) DEFAULT NULL,
  `status` enum('DRAFT','MENUNGGU_MANAGER','MENUNGGU_DIR_OPS','MENUNGGU_DIR_KEU','SIAP_BID','PO_TERBIT','NON_PO','SELESAI_FTB','REVISI','DITOLAK') NOT NULL DEFAULT 'MENUNGGU_MANAGER',
  `catatan_revisi_tolak` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `ppbj_requests`
--

INSERT INTO `ppbj_requests` (`id`, `request_no`, `doc_form_no`, `doc_issue_date`, `doc_revision`, `request_date`, `received_date`, `division_id`, `division_code`, `division_subdivision`, `delivery_location`, `request_types`, `catatan_umum`, `user_id`, `applied_by_name`, `applied_by_date`, `manager_name`, `manager_note`, `manager_date`, `dir_ops_name`, `dir_ops_note`, `dir_ops_date`, `dir_keu_name`, `dir_keu_note`, `dir_keu_date`, `po_no`, `po_date`, `vendor_id`, `vendor_name`, `status`, `catatan_revisi_tolak`, `created_at`, `updated_at`) VALUES
(1, '001/PPBJ/XI-2026/PBS-OIT', 'FRM.APR.01.00', '27 Mei 2025', '00', '2026-11-03', '2026-11-13', 1, 'OIT', 'Divisi IT & Operational IT (OIT)', 'Dusun Pintu Rimba Glee Siblah Woyla Aceh', '2. Alat Produksi, 4. Suku cadang, 6. Lain-lain', 'Lampirkan SPESIFIKASI BARANG/JASA sesuai daftar peruntukan.', 1, 'Abdul Karim', '2026-11-03', 'Bambang Sebastiar', 'Disetujui atasan divisi.', '2026-11-04', 'Hendra Wijaya', 'Disetujui Direktur Operasional.', '2026-11-05', 'Wesly Marugan Simatupang', 'Anggaran tersedia, disetujui Direktur Keuangan.', '2026-11-06', '001/PO/XI-2026/PBS', '2026-11-07', 1, 'PT Mitra Teknika Nusantara', 'SELESAI_FTB', NULL, '2026-11-25 03:55:22', '2026-11-25 03:55:22'),
(2, '001/PPBJ/XI-2026/PBS-WKS', 'FRM.APR.01.00', '27 Mei 2025', '00', '2026-11-10', '2026-11-22', 2, 'WKS', 'Workshop & Mekanik Site Woyla', 'Workshop Utama Dusun Pintu Rimba Woyla Aceh', '4. Suku cadang, 5. Bahan bakar/Pelumas', 'Suku cadang & pelumas rutin excavator dan genset utama.', 1, 'Abdul Karim', '2026-11-10', 'Bambang Sebastiar', 'Stok filter kritis.', '2026-11-10', 'Hendra Wijaya', 'Disetujui Direktur Operasional.', '2026-11-11', 'Wesly Marugan Simatupang', 'Budget November tersedia.', '2026-11-12', '002/PO/XI-2026/PBS, 003/PO/XI-2026/PBS', '2026-11-13', NULL, 'PT Traktor & Sparepart Sejahtera, PT Energi Pelumas Indonesia', 'PO_TERBIT', NULL, '2026-11-25 03:55:22', '2026-11-25 03:55:22'),
(3, '001/PPBJ/XI-2026/PBS-HSE', 'FRM.APR.01.00', '27 Mei 2025', '00', '2026-11-15', '2026-11-28', 3, 'HSE', 'HSE / Keselamatan Kerja (K3)', 'Kantor & Site Operasional Woyla Aceh', '6. Lain-lain', 'Perlengkapan APD standar SNI/ANSI untuk tim lapangan.', 1, 'Abdul Karim', '2026-11-15', 'Bambang Sebastiar', 'Wajib dipenuhi sebelum inspeksi K3.', '2026-11-15', 'Hendra Wijaya', 'Disetujui Direktur Operasional.', '2026-11-16', 'Wesly Marugan Simatupang', 'Anggaran K3 disetujui, silakan Procurement buat Bid Summary.', '2026-11-17', NULL, NULL, NULL, NULL, 'SIAP_BID', NULL, '2026-11-25 03:55:22', '2026-11-25 03:55:22'),
(4, '001/PPBJ/XI-2026/PBS-OPS', 'FRM.APR.01.00', '27 Mei 2025', '00', '2026-11-16', '2026-11-30', 4, 'OPS', 'Operational Site Woyla Aceh', 'Dusun Pintu Rimba Glee Siblah Woyla Aceh', '1. Bahan baku, 2. Alat Produksi', 'Jasa kalibrasi panel & bahan pendukung operasional.', 1, 'Abdul Karim', '2026-11-16', 'Bambang Sebastiar', 'Layak dilanjutkan.', '2026-11-17', 'Hendra Wijaya', 'Disetujui Direktur Operasional.', '2026-11-17', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MENUNGGU_DIR_KEU', NULL, '2026-11-25 03:55:22', '2026-11-25 03:55:22'),
(5, '001/PPBJ/XI-2026/PBS-GA', 'FRM.APR.01.00', '27 Mei 2025', '00', '2026-11-18', '2026-12-02', 5, 'GA', 'General Affairs & Kendaraan', 'Kantor Operational Site Woyla Aceh', '3. Kendaraan', 'Penggantian ban kendaraan operasional double cabin.', 1, 'Abdul Karim', '2026-11-18', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MENUNGGU_MANAGER', NULL, '2026-11-25 03:55:22', '2026-11-25 03:55:22');

-- --------------------------------------------------------

--
-- Struktur dari tabel `purchase_orders`
--

CREATE TABLE `purchase_orders` (
  `id` int(10) UNSIGNED NOT NULL,
  `order_type` enum('PURCHASE ORDER','WORK ORDER') NOT NULL DEFAULT 'PURCHASE ORDER',
  `po_no` varchar(60) NOT NULL,
  `po_date` date NOT NULL,
  `ppbj_id` int(10) UNSIGNED NOT NULL,
  `bid_id` int(10) UNSIGNED DEFAULT NULL,
  `vendor_id` int(10) UNSIGNED DEFAULT NULL,
  `vendor_name` varchar(150) NOT NULL,
  `seller_address` varchar(255) DEFAULT '-',
  `seller_contact` varchar(150) DEFAULT '-',
  `seller_email` varchar(120) DEFAULT '-',
  `termin_pembayaran` varchar(200) DEFAULT 'Credit, 30 days after receipt of the invoice and BAST / Delivery Note',
  `terms_of_delivery` varchar(120) DEFAULT 'Franco PBS Site',
  `lead_time_delivery` varchar(120) DEFAULT '14 Days',
  `quotation_ref` varchar(150) DEFAULT '-',
  `estimasi_kirim` date DEFAULT NULL,
  `delivery_location` varchar(255) NOT NULL,
  `delivery_contact` varchar(150) DEFAULT 'T Safril Nizam TM (082213151408)',
  `purchase_reference` varchar(255) DEFAULT NULL,
  `division_dept` varchar(100) DEFAULT NULL,
  `subtotal_po` decimal(16,2) NOT NULL DEFAULT 0.00,
  `delivery_fee` decimal(16,2) NOT NULL DEFAULT 0.00,
  `discount_amount` decimal(16,2) NOT NULL DEFAULT 0.00,
  `vat_percent` decimal(5,2) NOT NULL DEFAULT 0.00,
  `vat_amount` decimal(16,2) NOT NULL DEFAULT 0.00,
  `withholding_tax_pct` decimal(5,2) NOT NULL DEFAULT 0.00,
  `withholding_tax_label` varchar(200) DEFAULT NULL,
  `catatan` text DEFAULT NULL,
  `total_po` decimal(16,2) NOT NULL DEFAULT 0.00,
  `pbs_signer_name` varchar(120) DEFAULT NULL,
  `status` enum('DRAFT','TERBIT','DALAM_PENGIRIMAN','SELESAI_FTB') NOT NULL DEFAULT 'TERBIT',
  `dibuat_oleh` varchar(120) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `purchase_orders`
--

INSERT INTO `purchase_orders` (`id`, `order_type`, `po_no`, `po_date`, `ppbj_id`, `bid_id`, `vendor_id`, `vendor_name`, `seller_address`, `seller_contact`, `seller_email`, `termin_pembayaran`, `terms_of_delivery`, `lead_time_delivery`, `quotation_ref`, `estimasi_kirim`, `delivery_location`, `delivery_contact`, `purchase_reference`, `division_dept`, `subtotal_po`, `delivery_fee`, `discount_amount`, `vat_percent`, `vat_amount`, `withholding_tax_pct`, `withholding_tax_label`, `catatan`, `total_po`, `pbs_signer_name`, `status`, `dibuat_oleh`, `created_at`, `updated_at`) VALUES
(1, 'PURCHASE ORDER', '001/PO/XI-2026/PBS', '2026-11-07', 1, 1, 1, 'PT Mitra Teknika Nusantara', 'Jl. TB Simatupang Kav. 18, Cilandak, Jakarta Selatan', 'Budi Santoso (0812-8890-1122)', 'sales@mitrateknika.co.id', 'Credit TOP 30 Days After Receipt', 'Franco PBS Site', '5 Days', '011/MTN/XI/2026', '2026-11-13', 'Dusun Pintu Rimba, Desa Glee Siblah, Kec. Woyla Induk, Meulaboh, Kab. Aceh Barat 23654', 'T Safril Nizam TM (082213151408)', '001/PPBJ/XI-2026/PBS-OIT', 'OIT', 53900000.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, 'Generate otomatis dari Bid Summary 001/BID/XI-2026/PBS.', 53900000.00, 'Noviani Nuzulia', 'SELESAI_FTB', 'Noviani Nuzulia', '2026-11-25 03:55:22', '2026-11-25 03:55:22'),
(2, 'PURCHASE ORDER', '002/PO/XI-2026/PBS', '2026-11-13', 2, 2, 3, 'PT Traktor & Sparepart Sejahtera', 'Jl. Gatot Subroto Km. 6 No. 12, Medan', 'Dewi Lestari (0811-9023-556)', 'cs@traktorsejahtera.co.id', 'Credit TOP 15 Days After Receipt', 'Franco PBS Site', '4 Days', '022/TSS/XI/2026', '2026-11-20', 'Dusun Pintu Rimba, Desa Glee Siblah, Kec. Woyla Induk, Meulaboh, Kab. Aceh Barat 23654', 'T Safril Nizam TM (082213151408)', '001/PPBJ/XI-2026/PBS-WKS', 'WKS', 4950000.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, 'PO khusus item suku cadang filter dari Bid Summary 002.', 4950000.00, 'Noviani Nuzulia', 'TERBIT', 'Noviani Nuzulia', '2026-11-25 03:55:22', '2026-11-25 03:55:22'),
(3, 'PURCHASE ORDER', '003/PO/XI-2026/PBS', '2026-11-13', 2, 2, 4, 'PT Energi Pelumas Indonesia', 'Jl. Jend. Ahmad Yani Kav. 42, Jakarta Pusat', 'Haryanto (0812-1198-7700)', 'order@energipelumas.co.id', 'Transfer/Cash', 'Franco PBS Site', '7 Days', '089/EPI/XI/2026', '2026-11-21', 'Dusun Pintu Rimba, Desa Glee Siblah, Kec. Woyla Induk, Meulaboh, Kab. Aceh Barat 23654', 'T Safril Nizam TM (082213151408)', '001/PPBJ/XI-2026/PBS-WKS', 'WKS', 30600000.00, 500000.00, 0.00, 11.00, 3366000.00, 0.00, NULL, 'PO khusus item oli mesin dari Bid Summary 002.', 34466000.00, 'Noviani Nuzulia', 'DALAM_PENGIRIMAN', 'Noviani Nuzulia', '2026-11-25 03:55:22', '2026-11-25 03:55:22');

-- --------------------------------------------------------

--
-- Struktur dari tabel `report_settings`
--

CREATE TABLE `report_settings` (
  `skey` varchar(60) NOT NULL,
  `svalue` varchar(255) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `report_settings`
--

INSERT INTO `report_settings` (`skey`, `svalue`, `updated_at`) VALUES
('compliance_min_quotes', '3', '2026-11-25 04:00:56'),
('compliance_threshold', '10000000', '2026-11-25 04:00:56'),
('sla_pr_po_days', '7', '2026-11-25 04:00:56'),
('sla_start_basis', 'FINAL_APPROVAL', '2026-11-25 04:00:56'),
('target_accuracy_pct', '98', '2026-11-25 04:00:56'),
('target_otd_pct', '95', '2026-11-25 04:00:56'),
('target_sla_pct', '90', '2026-11-25 04:00:56'),
('top_vendor_min_otd', '95', '2026-11-25 04:00:56'),
('watch_otd_below', '80', '2026-11-25 04:00:56');

-- --------------------------------------------------------

--
-- Struktur dari tabel `saving_targets`
--

CREATE TABLE `saving_targets` (
  `id` int(10) UNSIGNED NOT NULL,
  `periode` varchar(7) NOT NULL COMMENT 'YYYY (setahun) atau YYYY-MM (sebulan)',
  `kategori` varchar(120) NOT NULL,
  `target_amount` decimal(16,2) NOT NULL DEFAULT 0.00,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `nama_lengkap` varchar(120) NOT NULL,
  `jabatan` varchar(120) NOT NULL,
  `division_id` int(10) UNSIGNED DEFAULT NULL,
  `divisi` varchar(120) NOT NULL,
  `role` enum('PEMOHON','MANAGER','DIREKTUR_OPS','DIREKTUR_KEUANGAN','PROCUREMENT','ADMIN') NOT NULL DEFAULT 'PEMOHON',
  `aktif` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `username`, `password_hash`, `nama_lengkap`, `jabatan`, `division_id`, `divisi`, `role`, `aktif`, `created_at`) VALUES
(1, 'pemohon', '$2y$12$FM8RE34PTG0vOxgooO65dOXxFEDKZumNoXC8O1ChlJ.GT8W/LC61G', 'Abdul Karim', 'Staff IT & Operational IT', 1, 'Divisi IT & Operational IT (OIT)', 'PEMOHON', 1, '2026-11-25 03:55:22'),
(2, 'desrika', '$2y$12$FM8RE34PTG0vOxgooO65dOXxFEDKZumNoXC8O1ChlJ.GT8W/LC61G', 'Desrika', 'Staff Workshop & Mekanik', 2, 'Workshop & Mekanik Site Woyla', 'PEMOHON', 1, '2026-11-25 03:55:22'),
(3, 'manager', '$2y$12$FM8RE34PTG0vOxgooO65dOXxFEDKZumNoXC8O1ChlJ.GT8W/LC61G', 'Bambang Sebastiar', 'Manager Operational', 4, 'Operational Site Woyla Aceh', 'MANAGER', 1, '2026-11-25 03:55:22'),
(4, 'dirops', '$2y$12$FM8RE34PTG0vOxgooO65dOXxFEDKZumNoXC8O1ChlJ.GT8W/LC61G', 'Hendra Wijaya', 'Direktur Operasional', NULL, 'Direksi', 'DIREKTUR_OPS', 1, '2026-11-25 03:55:22'),
(5, 'dirkeu', '$2y$12$FM8RE34PTG0vOxgooO65dOXxFEDKZumNoXC8O1ChlJ.GT8W/LC61G', 'Wesly Marugan Simatupang', 'Direktur Keuangan', NULL, 'Direksi Keuangan', 'DIREKTUR_KEUANGAN', 1, '2026-11-25 03:55:22'),
(6, 'noviani', '$2y$12$FM8RE34PTG0vOxgooO65dOXxFEDKZumNoXC8O1ChlJ.GT8W/LC61G', 'Noviani Nuzulia', 'Procurement', NULL, 'Procurement & Logistik', 'PROCUREMENT', 1, '2026-11-25 03:55:22'),
(7, 'safril', '$2y$12$FM8RE34PTG0vOxgooO65dOXxFEDKZumNoXC8O1ChlJ.GT8W/LC61G', 'Safril Nizam', 'Procurement', NULL, 'Procurement & Logistik', 'PROCUREMENT', 1, '2026-11-25 03:55:22'),
(8, 'ichsan', '$2y$12$FM8RE34PTG0vOxgooO65dOXxFEDKZumNoXC8O1ChlJ.GT8W/LC61G', 'Ichsan Husada', 'Procurement', NULL, 'Procurement & Logistik', 'PROCUREMENT', 1, '2026-11-25 03:55:22'),
(9, 'superadmin', '$2y$12$aMmZOoYs8ZVQssybL.QBMewe5hxA9o9UK0pxDMKtlYGwfMOWZq0Ya', 'Super Admin', 'System Super Administrator', NULL, 'IT & Sistem Admin', 'ADMIN', 1, '2026-11-25 03:55:22');

-- --------------------------------------------------------

--
-- Struktur dari tabel `vendors`
--

CREATE TABLE `vendors` (
  `id` int(10) UNSIGNED NOT NULL,
  `kode_vendor` varchar(20) NOT NULL,
  `nama_vendor` varchar(180) NOT NULL,
  `jenis_penyedia` enum('Barang','Jasa','Barang & Jasa') NOT NULL DEFAULT 'Barang',
  `kategori` varchar(255) NOT NULL DEFAULT 'Umum',
  `item_dijual` text DEFAULT NULL,
  `no_rekening` varchar(80) DEFAULT '-',
  `an_rekening` varchar(150) DEFAULT '-',
  `nama_bank` varchar(150) DEFAULT '-',
  `npwp` varchar(40) DEFAULT '-',
  `pic` varchar(120) DEFAULT '-',
  `telepon` varchar(150) DEFAULT '-',
  `email` varchar(120) DEFAULT '-',
  `alamat` text DEFAULT NULL,
  `kota` varchar(80) DEFAULT 'Indonesia',
  `aktif` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `vendors`
--

INSERT INTO `vendors` (`id`, `kode_vendor`, `nama_vendor`, `jenis_penyedia`, `kategori`, `item_dijual`, `no_rekening`, `an_rekening`, `nama_bank`, `npwp`, `pic`, `telepon`, `email`, `alamat`, `kota`, `aktif`, `created_at`) VALUES
(1, 'VND-001', 'PT Mitra Teknika Nusantara', 'Barang & Jasa', 'Perangkat IT & Jasa Perbaikan', 'Perangkat IT & Jasa Perbaikan', '124-00-0987654-3', 'PT Mitra Teknika Nusantara', 'Mandiri', '01.345.678.9-412.000', 'Budi Santoso', '0812-8890-1122', 'sales@mitrateknika.co.id', 'Jl. TB Simatupang Kav. 18, Cilandak', 'Jakarta Selatan', 1, '2026-11-25 03:55:22'),
(2, 'VND-002', 'CV Bumi Karya Mandiri', 'Jasa', 'Alat Produksi & Workshop', 'Alat Produksi & Workshop', '7100229911', 'CV Bumi Karya Mandiri', 'BSI', '02.771.229.1-215.000', 'Agus Setiawan', '0813-7700-4451', 'project@bumikaryamandiri.id', 'Jl. Teuku Nyak Arief No. 88', 'Banda Aceh / Batam', 1, '2026-11-25 03:55:22'),
(3, 'VND-003', 'PT Traktor & Sparepart Sejahtera', 'Barang', 'Suku Cadang & Alat Berat', 'Suku Cadang & Alat Berat', '0081-01-002345-30-1', 'PT Traktor & Sparepart Sejahtera', 'BRI', '01.908.114.3-041.000', 'Dewi Lestari', '0811-9023-556', 'cs@traktorsejahtera.co.id', 'Jl. Gatot Subroto Km. 6 No. 12', 'Medan', 1, '2026-11-25 03:55:22'),
(4, 'VND-004', 'PT Energi Pelumas Indonesia', 'Barang', 'Bahan Bakar & Pelumas', 'Bahan Bakar & Pelumas', '5410-8899-11', 'PT Energi Pelumas Indonesia', 'BCA', '03.442.891.5-012.000', 'Haryanto', '0812-1198-7700', 'order@energipelumas.co.id', 'Jl. Jend. Ahmad Yani Kav. 42', 'Jakarta Pusat', 1, '2026-11-25 03:55:22'),
(5, 'VND-005', 'PT Prima Safety Nusantara', 'Barang', 'Alat Pelindung Diri (K3)', 'Alat Pelindung Diri (K3)', '8820-4411-99', 'PT Prima Safety Nusantara', 'BCA', '02.661.994.2-014.000', 'Rian Hidayat', '0813-5501-8899', 'sales@primasafety.co.id', 'Jl. Daan Mogot Km. 11 No. 25', 'Jakarta Barat', 1, '2026-11-25 03:55:22'),
(6, 'VND-006', 'PT Horas Bangun Persada', 'Barang & Jasa', 'General contractor, MEP applicator truss & roof aluminium work, finishing ceiling & partition work supplier & trading', 'General contractor, MEP applicator truss & roof aluminium work, finishing ceiling & partition work supplier & trading', '5657 998 877', 'PT Horas Bangun Persada', 'BNI KCP Cemara Asri Cabang KIM Medan', '-', '-', 'Hp. +62 812-6050-659 | Surijandi (Asoen)', '-', 'Jl. Kalingga no. 33 Simpang Mahayana Medan. Telp. 061-4524333 | Jl. Nyak Adam Kamil III, Gampong Neusu Jaya Kec. Baiturrahman, Banda Aceh', 'Medan', 1, '2026-11-25 03:55:22'),
(7, 'VND-007', 'CV Sumber Inti Komputer', 'Barang', 'Komputer, Perlengkapan IT, Barang Elektronik', 'Komputer, Perlengkapan IT, Barang Elektronik', '7141785731', 'CV Sumber Inti Komputer', 'BSI Cabang Meulaboh', '-', 'Hasyimi', 'Hasyimi (0852-7613-5181)', '-', 'Jl. Manek Roo No. 349, Meulaboh, Aceh Barat', 'Aceh Barat', 1, '2026-11-25 03:55:22'),
(8, 'VND-008', 'PT Paraz Bangun Berjaya', 'Barang', 'Furniture', 'Furniture', '2044444405', 'PT Paraz Bangun Berjaya', 'BSI KCP Teuku Umar BNA', '-', 'Faisal', 'Faisal (0821-9975-5600)', '-', 'Jl. Tgk. Direuleung, Ilie, Ulee Kareng, Banda Aceh, Aceh', 'Banda Aceh', 1, '2026-11-25 03:55:22'),
(9, 'VND-009', 'PT Murni Dharma Karya', 'Barang', 'Bahan Kimia, Instrumen Laboratorium', 'Bahan Kimia, Instrumen Laboratorium', '342-3018956', 'PT Murni Dharma Karya', 'BCA Cab. Matraman', '-', 'Isna', 'Isna (0895-3344-62083) | Telp : (021) 4683 3636', '-', 'Bizpark Commercial Estate, Blok A.01 Kav.17, Jl. Raya Bekasi, Cakung, Jakarta Timur 13920', 'Jakarta Timur', 1, '2026-11-25 03:55:22'),
(10, 'VND-010', 'PT Smart Lab Indonesia', 'Barang', 'Bahan Kimia, Instrumen Laboratorium', 'Bahan Kimia, Instrumen Laboratorium', '1368.0000.9955', 'PT Smart Lab Indonesia', 'OCBC NISP Cab Kantor Bumi Serpong Damai', '-', 'Loren', 'Loren (0811-1200-8461) | Telp : (021) 75880205', '-', 'Ruko Boulevard Taman Tekno Blok E 10-11 ; BSD Sektor XI Serpong, Tangerang', 'Tangerang', 1, '2026-11-25 03:55:22'),
(11, 'VND-011', 'PT Mitra Lab Indonesia', 'Barang', 'Vendor peralatan laboratorium dan bahan kimia', 'Vendor peralatan laboratorium dan bahan kimia', '2293167788', 'PT Mitra Lab Indonesia', 'BCA Cab. Palmerah', '-', '-', 'Telp : (021) 2212 3635', '-', 'Jl. Raya Kebon Jeruk No. 19C; Jakarta Barat', 'Jakarta Barat', 1, '2026-11-25 03:55:22'),
(12, 'VND-012', 'CV Mitra Lestari Plastik', 'Barang', 'Plastik SIR, Cetak Label Plastik SIR', 'Plastik SIR, Cetak Label Plastik SIR', '37103397', 'CV Mitra Lestari Plastik', 'Bank Danamon', '-', 'Lukman', 'Lukman (0812-1521-5621)', '-', 'Jl. Pelita II Blok A No. 22 (KIM Star), Tanjung Morowa, Deli Serdang, Sumatera Utara', 'Deli Serdang', 1, '2026-11-25 03:55:22'),
(13, 'VND-013', 'PT Melakim Inti Perkasa', 'Barang', 'Bahan Kimia, Instrumen Laboratorium', 'Bahan Kimia, Instrumen Laboratorium', '860015021300', 'Melakim inti Perkasa', 'Bank CIMB', '-', 'William', 'William (0811-6591-988) | Telp : (021) 5698 0459', '-', 'Jl. Prof. Dr. Latumenten, Kompleks Grogol Permai Blok-B No. 30, Jakarta', 'Jakarta', 1, '2026-11-25 03:55:22'),
(14, 'VND-014', 'PT Mutuagung Lestari', 'Jasa', 'Laboratorium pengujian kualitas lingkungan', 'Laboratorium pengujian kualitas lingkungan', '7243269697', 'Pt. Mutuagung Lestari Tbk', 'BSI KCP Depok Dua', '-', 'Ryan Edo', 'Ryan Edo (0853-2009-7301) | Telp. 0651-7312155', '-', 'Jl. Raya Bogor Km 33,5 No. 19, Cimanggis-Depok 16953 | Jl. Dr.Mr. Mohd Hasan no. 235 Batoh, Lueng Bata, Banda Aceh.', 'Depok', 1, '2026-11-25 03:55:22'),
(15, 'VND-015', 'Toko Global Bordir', 'Barang', 'Seragam, Konveksi', 'Seragam, Konveksi', '6790264914', 'Yunaldi', 'BCA', '-', 'Andi', 'Andi (0813-7187-3511)', '-', 'Blok M Square Lt. Basement Blok D No. 05-06; Kebayoran Baru, Jakarta Selatan', 'Jakarta Selatan', 1, '2026-11-25 03:55:22'),
(16, 'VND-016', 'Adi Garden', 'Barang', 'Bibit Tanaman Hias', 'Bibit Tanaman Hias', '7174866877', 'Supriadi', 'BSI', '-', 'Supriadi', 'Supriadi (0822-9830-4532)', '-', 'Jl. Meulaboh, Cot Darat, Samatiga, Aceh Barat', 'Aceh Barat', 1, '2026-11-25 03:55:22'),
(17, 'VND-017', 'Toko Eropa Baru Perabot', 'Barang', 'Perabot RumahTangga, Furniture', 'Perabot RumahTangga, Furniture', '1056430497', 'Hendri Dirgantara', 'BSI', '-', 'Hendri', 'Hendri (0852-7737-8428)', '-', 'Jl. Teuku Umar, Meulaboh, Aceh Barat, Aceh', 'Aceh Barat', 1, '2026-11-25 03:55:22'),
(18, 'VND-018', 'Toko Mitra Perabot', 'Barang', 'Perabot Rumah Tangga, Furniture', 'Perabot Rumah Tangga, Furniture', '1021229136', 'Hendra Satria', 'BSI', '-', 'Hendra', 'Hendra (0853-6004-9251)', '-', 'Jl. Teuku Umar, Meulaboh, Aceh Barat, Aceh', 'Aceh Barat', 1, '2026-11-25 03:55:22'),
(19, 'VND-019', 'Toko Mandiri CCTV & Safety', 'Barang', 'Perlengkapan Safety, Safety Shoes, Vest, Helmet', 'Perlengkapan Safety, Safety Shoes, Vest, Helmet', '7000655451', 'Indriyani', 'BCA', '-', 'Indri', 'Indri (0838-0331-6154)', '-', 'LTC Glodok Lt. 2 Blok B15 No. 2; Jl. Hayam Wuruk No.127, Jakarta Barat', 'Jakarta Barat', 1, '2026-11-25 03:55:22'),
(20, 'VND-020', 'Koperasi Konsumen Wadah Titian Harapan', 'Jasa', 'Rental Mobil; ATK', 'Rental Mobil; ATK', '122 0011754481', 'Koperasi konsumen Wadah Titian harapan', 'Mandiri KCP Midplaza', '-', 'Yanti', 'Yanti (0816-954-459)', '-', 'Jalan Penjernihan 2 No 7, Bendungan Hilir, Tanah Abang, Jakarta Pusat', 'Jakarta Pusat', 1, '2026-11-25 03:55:22'),
(21, 'VND-021', 'Almahira Konveksi', 'Barang', 'Konvensi, Seragam', 'Konvensi, Seragam', '5220990461', 'Reza Oktavian', 'BCA KCU Lippo Cikarang', '-', 'Vian', 'Vian (0858-8090-8986)', '-', 'Puri Nirwana Residences Blok PN No. 25, | Sukaraya, Karang Bahagia, Bekasi', 'Bekasi', 1, '2026-11-25 03:55:22'),
(22, 'VND-022', 'CV Pangeran Dzacky', 'Barang', 'Konvensi, Seragam', 'Konvensi, Seragam', '1057565809', 'Putri Diah Anggraeni', 'BSI', '-', 'Putri', 'Putri (+62 852-7076-1981)', '-', 'Jl. Nasional no. 415, Simp. 4 Rundeng, | Drien Rampak, kec. Johan Pahlawan, Meulaboh - Aceh Barat 23617', 'Aceh Barat', 1, '2026-11-25 03:55:22'),
(23, 'VND-023', 'Jaya Interior', 'Barang', 'Perabot RumahTangga, Furniture', 'Perabot RumahTangga, Furniture', '1052967135', 'Agus Mawati', 'BSI', '-', 'Bustami', 'Bustami (0822-5458-4677)', '-', 'Jl. Teuku Umar, Meulaboh, Aceh Barat, Aceh', 'Aceh Barat', 1, '2026-11-25 03:55:22'),
(24, 'VND-024', 'Buns Tailor', 'Barang', 'Tailor, Seragam', 'Tailor, Seragam', '8800727406', 'Muhammad Andi', 'BCA', '-', 'Andi', 'Andi (0895-3643-36069)', '-', 'Komplek Parung Permata Indah Blok E4 No. 3, Kali Suren, Tajur Halang, Bogor', 'Bogor', 1, '2026-11-25 03:55:22'),
(25, 'VND-025', 'Toko Surabaya Gorden', 'Barang', 'Gorden, Vertical Blind, Roller Blind', 'Gorden, Vertical Blind, Roller Blind', '1053681138', 'Effendi', 'BSI', '-', 'Effendi', 'Effendi (0813-7716-4888)', '-', 'Jl. Nasional No. 8, Aceh Barat, Aceh', 'Aceh Barat', 1, '2026-11-25 03:55:22'),
(26, 'VND-026', 'CV Mutiara Cemerlang', 'Jasa', 'Rental Alat Berat', 'Rental Alat Berat', '7147446459', 'Ali Candra', 'BSI', '-', 'Cut Jaranah', 'Cut Jaranah (0852-9799-3999) | Candra (0813-6060-6910)', '-', 'Jalan Nasional Jeuram - Beutong, Kel. Keude Seumot, Kec. Beutong, Kab. Nagan Raya, Provinsi Aceh', 'Nagan Raya', 1, '2026-11-25 03:55:22'),
(27, 'VND-027', 'CV Audio Technics', 'Barang', 'Barang Elektronik', 'Barang Elektronik', '7183989434', 'Felix Fredie', 'BSI', '-', 'Felix', 'Felix (0813-6633-3315) | Telp : (0651) 22748', '-', 'Jl. K. H. A. Dahlan No. 72, Banda Aceh', 'Banda Aceh', 1, '2026-11-25 03:55:22'),
(28, 'VND-028', 'Toko Nyo Hoka', 'Barang', 'Perabot RumahTangga, Furniture', 'Perabot RumahTangga, Furniture', '1147493070', 'Iswadi', 'BSI', '-', 'Khaidir', 'Khaidir (0895-1977-8985)', '-', 'Jl Nasional Meulaboh, Meulaboh, Aceh Barat', 'Aceh Barat', 1, '2026-11-25 03:55:22'),
(29, 'VND-029', 'PT IKN', 'Barang', 'Bahan olah karet (Bokar)', 'Bahan olah karet (Bokar)', '7314799431', 'PT Ilham Karunia Nusantara', 'BSI', '-', 'Agussalim', 'Agussalim (+62 811-683-040)', '-', 'Jl. Sultan Malikulsaleh, no. 7E, Lamlagang, Kec. Banda Raya, Banda Aceh.', 'Banda Aceh', 1, '2026-11-25 03:55:22'),
(30, 'VND-030', 'Toko LC Com', 'Barang', 'Laptop, Komputer, Printer, Peralatan IT, Barang Elektronik', 'Laptop, Komputer, Printer, Peralatan IT, Barang Elektronik', '158-00-0152365-3', 'Said Anshar', 'Mandiri', '-', 'Said Anshar', 'Said Anshar (0821-6336-6660)', '-', 'Bakalan Baru RT 002 RW 002, Ceper, Klaten, Jawa Tengah', 'Klaten', 1, '2026-11-25 03:55:22'),
(31, 'VND-031', 'PT Willy Dwi Perkasa', 'Barang', 'BBM', 'BBM', '0053-01-004-796-30-5', 'PT Willy Dwi Perkasa', 'BRI Cab Medan Putri Hijau', '-', '-', 'Telp : (061) 88818173 | Chalik (0812-6519-400)', '-', 'Jl. KL Yos Sudarso KM18.5 No. 27A, Medan Labuhan, Medan, Sumatera Utara', 'Medan', 1, '2026-11-25 03:55:22'),
(32, 'VND-032', 'CV Mustika Raya Motor', 'Barang', 'Lubricant, Oli', 'Lubricant, Oli', '7167225227', 'Rahmad Indra Dwi Putra', 'BSI', '-', 'Indra', 'Indra (0811-6856-792)', '-', 'Jl. Nasional Desa Kuta Baro Jeuram, Nagan Raya, Aceh', 'Nagan Raya', 1, '2026-11-25 03:55:22'),
(33, 'VND-033', 'Pusat Penelitian Lingkungan Hidup & Sumber Daya Alam Unsyiah', 'Jasa', 'Jasa penyusunan dokumen persetujuan teknis pemenuhan bahan baku mutu air limbah & dokumen Pertek limbah cair domestik', 'Jasa penyusunan dokumen persetujuan teknis pemenuhan bahan baku mutu air limbah & dokumen Pertek limbah cair domestik', '7233256069', 'OPS Penerimaan USK 1', 'BSI', '-', '-', 'Prof.Dr.Ir. Mariana, M.Si., IPM, ASEAN Eng. | Lisa Juniar (+6285260031195)', '-', 'Jl. Tgk.Chik Pante Kulu No. 03, Gp. Kopelma Darussalam, Kec. Syiah Kuala, Banda Aceh.', 'Banda Aceh', 1, '2026-11-25 03:55:22'),
(34, 'VND-034', 'PT Tulip Tonata Indonesia', 'Barang', 'APAR', 'APAR', '8680 794 333', 'Tulip Tonata Indonesia PT', 'BCA', '-', 'Salsa', 'Salsa (0812-9588-3737)', '-', 'Ruko Alicante, Blok A/12, Jl. Jend. Gatot Subroto, Pagedangan, Tangerang, Banten', 'Tangerang', 1, '2026-11-25 03:55:22'),
(35, 'VND-035', 'CV Arta Logam Jaya', 'Barang', 'Anak Timbangan', 'Anak Timbangan', '1380059589999', 'CV Arta Logam Jaya', 'Mandiri', '-', 'Lutfi', 'Lutfi (0822-2587-6902)', '-', 'Bakalan Baru RT 002 RW 002, Ceper, Klaten, Jawa Tengah', 'Klaten', 1, '2026-11-25 03:55:22'),
(36, 'VND-036', 'Toko Aneka Musik', 'Barang', 'Sound System, Microphone, Speaker', 'Sound System, Microphone, Speaker', '7785052188', 'Fendy', 'BCA', '-', 'Fendy', 'Fendy (0812-6241-7900)', '-', 'Jl. Moh. Jam No.101, Kp. Baru, Baiturrahman, Banda Aceh, Aceh - 23242', 'Banda Aceh', 1, '2026-11-25 03:55:22'),
(37, 'VND-037', 'PT Telekomunikasi Internet Indonesia', 'Barang', 'Internet Service Provider, Starlink', 'Internet Service Provider, Starlink', '1050018868079', 'PT Telekomunikasi Internet Indonesia', 'Mandiri', '-', 'Ikhsan', 'Ikhsan (0821-6173-2524)', '-', 'Jl. Dr. Mr. Mohd. Hasan No. 33, Kota Banda Aceh 23245', 'Banda Aceh', 1, '2026-11-25 03:55:22'),
(38, 'VND-038', 'PT Raya Rapindo Indonesia', 'Jasa', 'Uji Riksa K3', 'Uji Riksa K3', '0670020072', 'PT Raya Rapindo Indonesia', 'BCA Syariah', '-', 'Siswandi', 'Siswandi (0821-6483-3402)', '-', 'Jln. Moh. Taher No. 169-170, Kec. Lueng Bata, Kota Banda Aceh, Aceh', 'Banda Aceh', 1, '2026-11-25 03:55:22'),
(39, 'VND-039', 'GHz CCTV', 'Barang', 'CCTV, AC, Peralatan IT', 'CCTV, AC, Peralatan IT', '1119046263', 'Yusak Kaburuan', 'BSI', '-', 'Yusak', 'Yusak (0852-6073-0608)', '-', 'Jl. Merdeka No. 65, Pasar Aceh, Meulaboh, Aceh Barat - 23681', 'Aceh Barat', 1, '2026-11-25 03:55:22'),
(40, 'VND-040', 'PT Petro Dimensi Niaga', 'Barang', 'BBM', 'BBM', '158-002424-2828', 'PT Petro Dimensi Niaga', 'Mandiri KCP Medan', '-', '-', 'Telp : (0651) 8051343 | Akmal (0812-6906-269)', '-', 'Jl. Ilie Lr. Melati No. 06 Desa Lamteh, Kecamatan Ulee Kareng, Banda Aceh', 'Banda Aceh', 1, '2026-11-25 03:55:22'),
(41, 'VND-041', 'UD Rahmat', 'Barang', 'Kayu Balok', 'Kayu Balok', '1049621497', 'Izhar Umar', 'BSI', '-', 'Pak Ing', 'Pak Ing (0853 98982724)', '-', 'Gunung Kleng, Meureubo', 'Indonesia', 1, '2026-11-25 03:55:22'),
(42, 'VND-042', 'UD Mutiara Abadi', 'Barang', 'Wooden Pallet', 'Wooden Pallet', '060-02.20.010830-6', 'Syahrul', 'Bank Aceh Cab Meulaboh', '-', 'Kamaruddin', 'Kamaruddin (0813-7732-2508)', '-', 'Jl. Kuala Bubon, Pinem, Desa Gampong Teungoh, Kec. Samatiga, Kab. Aceh Barat', 'Aceh Barat', 1, '2026-11-25 03:55:22'),
(43, 'VND-043', 'CV Genesis Makmur', 'Barang & Jasa', 'General contractor, construction supplier', 'General contractor, construction supplier', '7301376175', 'CV Genesis Makmur Abadi', 'BSI', '-', 'Wahyu', 'Wahyu (+62 822-6107-6193)', '-', 'Jl. Bungong Jaroe, Desa Seuneubok, Kec Johan Pahlawan, Aceh Barat', 'Aceh Barat', 1, '2026-11-25 03:55:22'),
(44, 'VND-044', 'PT Lautan Lepas Nusantara', 'Barang', 'Sparepart mesin dan kelistrikan', 'Sparepart mesin dan kelistrikan', '7520229897', 'Lautan Lepas Nusantara PT', 'BCA', '-', 'Christian', 'Christian (0812-8006-669)', '-', 'Jl. Mangga Besar VI Jakarta Selatan', 'Jakarta Selatan', 1, '2026-11-25 03:55:22'),
(45, 'VND-045', 'Henstiker', 'Barang', 'Cetak Sticker, Spanduk, Banner, Digital Printing', 'Cetak Sticker, Spanduk, Banner, Digital Printing', '1051958248', 'Hendra Putra', 'BSI', '-', 'Hendra', 'Hendra (0822-1171-7021)', '-', 'Jl. Singgah Mata I, Kita Padang, Meulaboh, Aceh Barat', 'Padang', 1, '2026-11-25 03:55:22'),
(46, 'VND-046', 'Percetakan SIB Babussalam', 'Barang', 'Cetak Sticker, Spanduk, Banner, Digital Printing', 'Cetak Sticker, Spanduk, Banner, Digital Printing', '7148645088', 'Waliswan', 'BSI', '-', '-', '0811-6859-222', '-', 'Jl. Cut Mutia (Babussalam), Ujong Baroh, Meulaboh, Aceh Barat', 'Aceh Barat', 1, '2026-11-25 03:55:22'),
(47, 'VND-047', 'PT Tiara Jaya Kalibrasi', 'Jasa', 'Kalibrasi Peralatan Lab', 'Kalibrasi Peralatan Lab', '003608754804', 'PT Tiara Jaya Kalibrasi', 'Bank Danamon Cab Padang Sudirman', '-', 'Furmansyah', 'Furmansyah (0812-6713-267)', '-', 'Jl. Barabah No. 8, Air Tawar Barat, Padang, Sumatera Barat', 'Padang', 1, '2026-11-25 03:55:22'),
(48, 'VND-048', 'PT Cannonex Indonesia', 'Jasa', 'Logistik, Pengiriman', 'Logistik, Pengiriman', '1570003103430', 'PT Cannonex Indonesia', 'Mandiri', '-', '-', 'Telp : (021) 877 877 51 | Agung (0812-9272-204)', '-', 'Zamzam Square, Jl. Condet Raya No. 02, Balekambang, Kramat Jati, Jakarta Timur', 'Jakarta Timur', 1, '2026-11-25 03:55:22'),
(49, 'VND-049', 'PT Victorindo Kencana Teknik', 'Barang', 'Mesin Produksi, Sparepart, Metal Detector', 'Mesin Produksi, Sparepart, Metal Detector', '8195127588', 'PT Victorindo Kencana Teknik', 'BCA', '-', '-', 'Telp: (061) 4273-7790 | Benny Lim (0812-6043-887)', '-', 'Jl. P. Bunaken No. B3, Kawasan Industri Medan III, Medan, Sumatera Utara - 20242', 'Medan', 1, '2026-11-25 03:55:22'),
(50, 'VND-050', 'Nurita Tailor', 'Barang', 'Tailor, Seragam, Konveksi', 'Tailor, Seragam, Konveksi', '1054557996', 'David Soehendroe', 'BSI', '-', 'Teuku David', 'Teuku David (0852-6086-8986)', '-', 'Jl. Sisingamangaraja, Gampa, Johan Pahlawan, Aceh Barat 23611', 'Aceh Barat', 1, '2026-11-25 03:55:22'),
(51, 'VND-051', 'CV Golden Bell', 'Barang', 'Bahan Kimia, Instrumen Lab', 'Bahan Kimia, Instrumen Lab', '86155.3333.700', 'CV Golden Bell', 'CIMB Niaga', '-', 'May', 'May (0821-4041-8003)', '-', 'Komplek Center Point Blok M II, Medan, Sumatera Utara -20231', 'Medan', 1, '2026-11-25 03:55:22'),
(52, 'VND-052', 'Toko Usaha Giat', 'Barang', 'Toko Besi', 'Toko Besi', '1050020800177', 'Veradyna', 'Mandiri', '-', 'Veradyna Zheng', 'Veradyna Zheng (0813-6141-0012)', '-', 'Jl. Singgahmata No. 16-18A, Meulaboh; Kabupaten Aceh Barat, Aceh', 'Aceh Barat', 1, '2026-11-25 03:55:22'),
(53, 'VND-053', 'Toko Baja Utama', 'Barang', 'Toko Besi', 'Toko Besi', '1978052802', 'Teuku Azdhari', 'BSI', '-', 'Adzhari', 'Adzhari (0852-6069-1031)', '-', 'Jl. Singgah Mata no. 45, Meulaboh, Aceh', 'Meulaboh', 1, '2026-11-25 03:55:22'),
(54, 'VND-054', 'CV Ramarakas', 'Jasa', 'Jasa SLF (Sertifikat Laik Fungsi)', 'Jasa SLF (Sertifikat Laik Fungsi)', '06001910201260', 'CV. RAMARAKAS', 'BSI', '-', 'Aulian', 'Aulian (62 852-6028-9213)', '-', 'Jl. Ujong Kalak No. 056, Meulaboh-Aceh Barat', 'Aceh Barat', 1, '2026-11-25 03:55:22'),
(55, 'VND-055', 'PT Sang General Industri', 'Barang', 'Pemasok peralatan industri, Pully, Sheet Steel.', 'Pemasok peralatan industri, Pully, Sheet Steel.', '010.01.91.180556-1', 'PT. Sang General Industri', 'Bank Aceh Syariah', '-', 'Rahmatillah', 'Rahmatillah (+62 853-7229-5005)', '-', 'Jl. Makam T.Nyak Arief, Gp.Mns Intan, Kec.Krueng Barona Jaya Kab. Aceh Besar.', 'Aceh Besar', 1, '2026-11-25 03:55:22'),
(56, 'VND-056', 'Badan Standarisasi Dan Kebijakan Jasa Industri (BARISTAN)', 'Jasa', 'Jasa Pengujian Outlate Air Limbah', 'Jasa Pengujian Outlate Air Limbah', '820260205539224', 'Billing', 'Billing', '-', 'Meutia', 'Meutia (+62 811-6843-343)', '-', 'Jln. Cut Nyak Dhien No. 377 Lamteumen Timur Banda Aceh 23236, | Telp. (0651) 49714 Fax. (0651) 49556', 'Banda Aceh', 1, '2026-11-25 03:55:22'),
(57, 'VND-057', 'PT Anugrah Analisis Sempurna', 'Jasa', 'Jasa Pemantauan Lingkungan Kerja', 'Jasa Pemantauan Lingkungan Kerja', '133.00.1999999.4', 'PT. ANUGRAH ANALISIS SEMPURNA', 'Mandiri', '-', 'Admin', 'Admin (+62 2129629393)', '-', 'Jalan Raya Jakarta Bogor KM. 37 | Sukamaju, Cilodong – Depok 16412', 'Jakarta', 1, '2026-11-25 03:55:22'),
(58, 'VND-058', 'UD Raya Utama', 'Barang', 'Bahan Bahan Kimia', 'Bahan Bahan Kimia', '7120576644', 'Hafnidar Nur', 'BSI', '-', 'Hafnidar Nur', 'Hafnidar Nur (0852 9607 9910)', '-', 'JL.Purnama LR.Mustajab , Desa/Kelurahan Drien Rampak, Aceh Barat, Meulaboh.', 'Aceh Barat', 1, '2026-11-25 03:55:22'),
(59, 'VND-059', 'PT Polaris Mitra Sukses', 'Jasa', 'Pelatihan dan Sertifikasi', 'Pelatihan dan Sertifikasi', '123.00.667.667.85', 'PT.Polaris Mitra Sukses', 'Mandiri', '-', 'Afifah', 'Afifah (+62 812-8780-1479)', '-', 'Ruko Mega Grosir Cempaka Mas Blok H-10 Jl.Cempaka Putih Timur, No 10 Sumur Batu Kemayoran, Jakarta Pusat 10640', 'Jakarta Pusat', 1, '2026-11-25 03:55:22'),
(60, 'VND-060', 'PT Pidoly Safety Work', 'Jasa', 'Pelatihan dan Sertifikasi', 'Pelatihan dan Sertifikasi', '106-00-1128323-', 'PT.Pidoly Safety Work', 'Mandiri', '-', 'Erwin', 'Erwin (+62 812-6573-475)', '-', 'Jl.Bangau Komp. The Raztan Palace Ruko Blok A No.34 Medan 20122.', 'Medan', 1, '2026-11-25 03:55:22'),
(61, 'VND-061', 'Toko Get UPVC', 'Barang', 'Material PVC', 'Material PVC', '7173387606', 'Fajar Mursalin Farib', 'BSI', '-', 'Fajar', 'Fajar (+62 822-9041-6016)', '-', 'Jl. Nasional Gp. Rundeng, Kec. Johan Pahlawan. Kab Aceh Barat, Provinsi Aceh.', 'Aceh Barat', 1, '2026-11-25 03:55:22'),
(62, 'VND-062', 'CV Tomo Teknik Mandiri', 'Jasa', 'Pelatihan dan Sertifikasi', 'Pelatihan dan Sertifikasi', '1171 1211 62', 'SUTOMO', 'BCA', '-', 'Sutomo', 'Sutomo (08127960316)', '-', 'Jl. Madura No 17, Kel.Hadimulyo Barat,Kota Metro, Provinsi Lampung,Provinsi Aceh.', 'Lampung', 1, '2026-11-25 03:55:22'),
(63, 'VND-063', 'CV. Indomulti Mitra Sentosa', 'Barang & Jasa', 'Kilang dan Pengerjaan Kayu', 'Kilang dan Pengerjaan Kayu', '06001910024504', 'INDOMULTI MITRA SENTOSA CV', 'Bank Aceh Syariah', '-', 'Mawan', 'Mawan (082277808998)', '-', 'Jl. Sentosa , No.160, Meulaboh', 'Meulaboh', 1, '2026-11-25 03:55:22'),
(64, 'VND-064', 'Toko Raska Perabot', 'Barang', 'Furniture', 'Furniture', '8020519728', 'Elvis Riandi', 'BSI', '-', 'Elvis Riandi', 'Elvis Riandi (0852 7099 2036)', '-', 'Jl Teuku Umar - Meulaboh', 'Meulaboh', 1, '2026-11-25 03:55:22'),
(65, 'VND-065', 'Toko Inti Elektronik', 'Barang', 'Elektronik', 'Elektronik', '7176648408', 'Muhammad Irfan', 'BSI', '-', 'Irfan', 'Irfan ( 0822 2896 1880)', '-', 'Jl. Nasional, Kuta Padang, Kec. Johan Pahlawan, Kabupaten Aceh Barat, Aceh 23612', 'Padang', 1, '2026-11-25 03:55:22'),
(66, 'VND-066', 'PT Primanusa Mukti Utama', 'Jasa', 'Percetakan Besar', 'Percetakan Besar', '0523.01.000190.30.4', 'PT. Primanusa Mukti Utama', 'BRI', '-', 'Admin', 'Admin (+62 811-1183-7707)', '-', 'Jl. Persatuan Jl. Cinere Raya No.01/03, Cinere, Kec. Cinere, Kota Depok, Jawa Barat 16514.', 'Depok', 1, '2026-11-25 03:55:22'),
(67, 'VND-067', 'Toko Pusat Timbangan 88', 'Barang', 'Timbangan', 'Timbangan', '7015-9669-55', 'SUWANDI/CEN NI', 'BCA', '-', 'Suwandi', 'Suwandi (081363072838)', '-', 'Plaza Kenari Mas Lantai 4 Blok K.3C Jakarta Pusat Kota Administrasi Jakarta Pusat DKI Jakarta 10430 Indonesia', 'Jakarta Pusat', 1, '2026-11-25 03:55:22'),
(68, 'VND-068', 'UD Peudaya', 'Barang & Jasa', 'Kilang dan Pengerjaan Kayu', 'Kilang dan Pengerjaan Kayu', '1133706700', 'SUNANTO SH', 'BSI', '-', 'Sunanto', 'Sunanto (+62 811-607-202)', '-', 'JLN. Pasar Lamno Desa Meunasah Weh, Kec. Jaya, Kab. Aceh Jaya.', 'Aceh Jaya', 1, '2026-11-25 03:55:22'),
(69, 'VND-069', 'PT Berlian Tirta Lestari', 'Barang', 'Pengolahan Air', 'Pengolahan Air', '1938098425', 'PT BERLIAN TIRTA LESTARI', 'BNI', '-', 'Admin', 'Admin (+62 822-9847-9237)', '-', 'Jl. Bunga Pancur Siwah Gg Anggrek No 13 kel. Simpang Selayang , Kec. Medan Tuntungan, kota Medan ,Sumatera Utara.', 'Medan', 1, '2026-11-25 03:55:22'),
(70, 'VND-070', 'Toko Diana Foto', 'Jasa', 'Studio Foto', 'Studio Foto', '1045242869', 'HASMADI', 'BSI', '-', 'Hasmadi', 'Hasmadi (0813 6037 6777)', '-', 'Jl.Gajah Mada - Nasional No 404 Sp. IV Rundeng Meulaboh.', 'Meulaboh', 1, '2026-11-25 03:55:22'),
(71, 'VND-071', 'CV Gata Beujaya', 'Barang', 'Pabrik Papan Tulis', 'Pabrik Papan Tulis', '1580036777779', 'GATA BEUJAYA', 'Mandiri', '-', 'Admin', 'Admin (085277744700)', '-', 'Jl.Tgk dikandang lr langsat, Peulanggahan, Kuta Raja, Banda Aceh City, Aceh 23129', 'Banda Aceh', 1, '2026-11-25 03:55:22'),
(72, 'VND-072', 'PT Logos Teknologi Utama', 'Jasa', 'Software Development', 'Software Development', '0586324631', 'PT. LOGOS TEKNOLOGI UTAMA', 'BCA', '-', 'Admin', 'Admin (021- 8774 2626)', '-', 'Eightyeight @Kasablanka Office Tower 88 Lt.38 Tebet, Jakarta Selatan.', 'Jakarta Selatan', 1, '2026-11-25 03:55:22'),
(73, 'VND-073', 'CV. RAN PERKASA ENGINEERING', 'Barang & Jasa', 'General contractor, construction supplier', 'General contractor, construction supplier', '06001910000601', 'CV RAN PERKASA ENGINEERING', 'Bank Aceh Syariah', '-', '-', '085260008652', '-', 'Jl. Manek Roo No. 40, Desa Kuta Padang, Kec. Johan Pahlawan, Kab. Aceh Barat, Provinsi Aceh', 'Padang', 1, '2026-11-25 03:55:22'),
(74, 'VND-074', 'CV. Roman Artha', 'Barang & Jasa', 'General contractor, construction supplier', 'General contractor, construction supplier', '06001056600093', 'CV Roman Artha', 'Bank Aceh Syariah', '-', 'Admin', 'Admin (+62 822-6107-6193)', '-', 'Jl. Imam Bonjol No 148, Desa Seunugok, Johan Pahlawan Kabupaten Aceh Barat', 'Aceh Barat', 1, '2026-11-25 03:55:22'),
(75, 'VND-075', 'PT. Indotara Persada', 'Barang', 'Distributor Alat Berat', 'Distributor Alat Berat', '130860000026070622', 'PT. Indotara Persada', 'BCA', '-', 'Admin', 'Admin (061-50 300 583)', '-', 'Jl. Sutomo Ujung No 28 Kota Meda Sumatera Utara 20245', 'Indonesia', 1, '2026-11-25 03:55:22'),
(76, 'VND-076', 'PT. Mitra Kharisma Perkasa', 'Barang', 'Bahan Kimia, Instrumen Lab', 'Bahan Kimia, Instrumen Lab', '1060022909090', 'PT. Mitra Kharisma Perkasa', 'BCA', '-', 'Admin', 'Admin (+62 812-6542-858)', '-', 'Jl Williem Iskandar Komp MMTC Blok Medan Estate 20371', 'Medan', 1, '2026-11-25 03:55:22'),
(77, 'VND-077', 'Toko RSM', 'Barang', 'Toko Usaha Pertanian', 'Toko Usaha Pertanian', '1059163527', 'Kian Hap', 'BSI', '-', 'Admin', 'Admin (+62 852-6230-2976)', '-', 'Jl. H Daud Dariyah 2, Meulaboh', 'Meulaboh', 1, '2026-11-25 03:55:22'),
(78, 'VND-078', 'PT. Prima Pelita Kimia', 'Barang', 'Bahan Kimia, Instrumen Lab', 'Bahan Kimia, Instrumen Lab', '8280102980', 'PT. Prima Pelita Kimia', 'BCA', '-', 'Rony', 'Rony (+62 852-9780-8910)', '-', 'Jl. Sidorukun Ko.Karakatau Permai Block C No 15 Medan 20239', 'Medan', 1, '2026-11-25 03:55:22'),
(79, 'VND-079', 'PT. Mapal Indonesia', 'Barang', 'Mesin Produksi, Sparepart, Metal Detector', 'Mesin Produksi, Sparepart, Metal Detector', '800004342200', 'PT. Mapal Indonesia', 'CIMB Niaga', '-', 'Vresty', 'Vresty (+62 811-1990-6295)', '-', 'Ruko Alam Sutera Tower Center Blok 10B No 16 Alam Sutera, Pakulonan Tangerang Selatan 15325', 'Tangerang Selatan', 1, '2026-11-25 03:55:22');

-- --------------------------------------------------------

--
-- Struktur dari tabel `vendor_incidents`
--

CREATE TABLE `vendor_incidents` (
  `id` int(10) UNSIGNED NOT NULL,
  `incident_date` date NOT NULL,
  `vendor_name` varchar(150) NOT NULL,
  `jenis` enum('SURAT_PERINGATAN','PENALTI_KETERLAMBATAN','INSIDEN_K3','PELANGGARAN_KEPATUHAN') NOT NULL,
  `po_no` varchar(60) DEFAULT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `dibuat_oleh` varchar(120) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `bid_items`
--
ALTER TABLE `bid_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_bi_bid` (`bid_id`),
  ADD KEY `fk_bi_ppbj_item` (`ppbj_item_id`),
  ADD KEY `fk_bi_vendor` (`bid_vendor_id`);

--
-- Indeks untuk tabel `bid_summaries`
--
ALTER TABLE `bid_summaries`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_bid_no` (`bid_no`),
  ADD KEY `idx_bid_ppbj` (`ppbj_id`);

--
-- Indeks untuk tabel `bid_vendors`
--
ALTER TABLE `bid_vendors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_bv_bid` (`bid_id`),
  ADD KEY `fk_bv_vendor` (`vendor_id`);

--
-- Indeks untuk tabel `divisions`
--
ALTER TABLE `divisions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_kode_divisi` (`kode_divisi`);

--
-- Indeks untuk tabel `ftb_items`
--
ALTER TABLE `ftb_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_ftb_items_ftb` (`ftb_id`);

--
-- Indeks untuk tabel `ftb_receipts`
--
ALTER TABLE `ftb_receipts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_ftb_no` (`ftb_no`),
  ADD KEY `idx_ftb_ppbj` (`ppbj_id`),
  ADD KEY `idx_ftb_po` (`po_id`),
  ADD KEY `idx_ftb_bid` (`bid_id`);

--
-- Indeks untuk tabel `po_items`
--
ALTER TABLE `po_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_pi_po` (`po_id`);

--
-- Indeks untuk tabel `ppbj_items`
--
ALTER TABLE `ppbj_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_ppbj_id` (`ppbj_id`);

--
-- Indeks untuk tabel `ppbj_logs`
--
ALTER TABLE `ppbj_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_log_ppbj` (`ppbj_id`);

--
-- Indeks untuk tabel `ppbj_requests`
--
ALTER TABLE `ppbj_requests`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_request_no` (`request_no`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_div_code` (`division_code`),
  ADD KEY `fk_ppbj_division` (`division_id`),
  ADD KEY `fk_ppbj_user` (`user_id`),
  ADD KEY `fk_ppbj_vendor` (`vendor_id`);

--
-- Indeks untuk tabel `purchase_orders`
--
ALTER TABLE `purchase_orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_po_no` (`po_no`),
  ADD KEY `idx_po_ppbj` (`ppbj_id`),
  ADD KEY `idx_po_bid` (`bid_id`),
  ADD KEY `fk_po_vendor` (`vendor_id`);

--
-- Indeks untuk tabel `report_settings`
--
ALTER TABLE `report_settings`
  ADD PRIMARY KEY (`skey`);

--
-- Indeks untuk tabel `saving_targets`
--
ALTER TABLE `saving_targets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_periode_kategori` (`periode`,`kategori`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_username` (`username`),
  ADD KEY `idx_users_div` (`division_id`);

--
-- Indeks untuk tabel `vendors`
--
ALTER TABLE `vendors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_kode_vendor` (`kode_vendor`);

--
-- Indeks untuk tabel `vendor_incidents`
--
ALTER TABLE `vendor_incidents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_vendor` (`vendor_name`),
  ADD KEY `idx_date` (`incident_date`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `bid_items`
--
ALTER TABLE `bid_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `bid_summaries`
--
ALTER TABLE `bid_summaries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `bid_vendors`
--
ALTER TABLE `bid_vendors`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `divisions`
--
ALTER TABLE `divisions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `ftb_items`
--
ALTER TABLE `ftb_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `ftb_receipts`
--
ALTER TABLE `ftb_receipts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `po_items`
--
ALTER TABLE `po_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `ppbj_items`
--
ALTER TABLE `ppbj_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `ppbj_logs`
--
ALTER TABLE `ppbj_logs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT untuk tabel `ppbj_requests`
--
ALTER TABLE `ppbj_requests`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `purchase_orders`
--
ALTER TABLE `purchase_orders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `saving_targets`
--
ALTER TABLE `saving_targets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `vendors`
--
ALTER TABLE `vendors`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- AUTO_INCREMENT untuk tabel `vendor_incidents`
--
ALTER TABLE `vendor_incidents`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `bid_items`
--
ALTER TABLE `bid_items`
  ADD CONSTRAINT `fk_bi_bid` FOREIGN KEY (`bid_id`) REFERENCES `bid_summaries` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_bi_ppbj_item` FOREIGN KEY (`ppbj_item_id`) REFERENCES `ppbj_items` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_bi_vendor` FOREIGN KEY (`bid_vendor_id`) REFERENCES `bid_vendors` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `bid_summaries`
--
ALTER TABLE `bid_summaries`
  ADD CONSTRAINT `fk_bid_ppbj` FOREIGN KEY (`ppbj_id`) REFERENCES `ppbj_requests` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `bid_vendors`
--
ALTER TABLE `bid_vendors`
  ADD CONSTRAINT `fk_bv_bid` FOREIGN KEY (`bid_id`) REFERENCES `bid_summaries` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_bv_vendor` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE SET NULL;

--
-- Ketidakleluasaan untuk tabel `ftb_items`
--
ALTER TABLE `ftb_items`
  ADD CONSTRAINT `fk_ftb_items_receipt` FOREIGN KEY (`ftb_id`) REFERENCES `ftb_receipts` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `ftb_receipts`
--
ALTER TABLE `ftb_receipts`
  ADD CONSTRAINT `fk_ftb_bid` FOREIGN KEY (`bid_id`) REFERENCES `bid_summaries` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_ftb_po` FOREIGN KEY (`po_id`) REFERENCES `purchase_orders` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_ftb_ppbj` FOREIGN KEY (`ppbj_id`) REFERENCES `ppbj_requests` (`id`) ON DELETE SET NULL;

--
-- Ketidakleluasaan untuk tabel `po_items`
--
ALTER TABLE `po_items`
  ADD CONSTRAINT `fk_poi_po` FOREIGN KEY (`po_id`) REFERENCES `purchase_orders` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `ppbj_items`
--
ALTER TABLE `ppbj_items`
  ADD CONSTRAINT `fk_items_ppbj` FOREIGN KEY (`ppbj_id`) REFERENCES `ppbj_requests` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `ppbj_logs`
--
ALTER TABLE `ppbj_logs`
  ADD CONSTRAINT `fk_logs_ppbj` FOREIGN KEY (`ppbj_id`) REFERENCES `ppbj_requests` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `ppbj_requests`
--
ALTER TABLE `ppbj_requests`
  ADD CONSTRAINT `fk_ppbj_division` FOREIGN KEY (`division_id`) REFERENCES `divisions` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_ppbj_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_ppbj_vendor` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE SET NULL;

--
-- Ketidakleluasaan untuk tabel `purchase_orders`
--
ALTER TABLE `purchase_orders`
  ADD CONSTRAINT `fk_po_bid` FOREIGN KEY (`bid_id`) REFERENCES `bid_summaries` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_po_ppbj` FOREIGN KEY (`ppbj_id`) REFERENCES `ppbj_requests` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_po_vendor` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
