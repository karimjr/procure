<?php
/**
 * Konfigurasi Koneksi Database MySQL / MariaDB (phpMyAdmin)
 * PT. Potensi Bumi Sakti - Sistem Informasi PPBJ & FTB
 */

function get_db(): PDO
{
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }

    $host = getenv('DB_HOST') ?: '127.0.0.1';
    $port = getenv('DB_PORT') ?: '3306';
    $dbname = getenv('DB_NAME') ?: 'db_ppbj_pbs';

    // Mendukung akun sandbox (pbs_user) maupun default XAMPP/Laragon (root tanpa password)
    $credentials = [
        [getenv('DB_USER') ?: 'pbs_user', getenv('DB_PASS') !== false ? getenv('DB_PASS') : 'pbs_pass123'],
        ['root', ''],
    ];

    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];

    $lastException = null;
    foreach ($credentials as [$user, $pass]) {
        try {
            $dsn = "mysql:host={$host};port={$port};dbname={$dbname};charset=utf8mb4";
            $pdo = new PDO($dsn, $user, $pass, $options);
            return $pdo;
        } catch (PDOException $e) {
            $lastException = $e;
        }
    }

    die(
        '<div style="font-family:sans-serif;padding:24px;max-width:640px;margin:40px auto;border:1px solid #fecaca;background:#fef2f2;border-radius:12px;color:#991b1b;">'
        . '<h2 style="margin-top:0;">Koneksi Database MySQL Gagal</h2>'
        . '<p>Pastikan service MySQL/MariaDB berjalan dan file <code>database.sql</code> sudah di-import ke phpMyAdmin (database <code>db_ppbj_pbs</code>).</p>'
        . '<p style="font-size:13px;color:#7f1d1d;">Detail: ' . htmlspecialchars($lastException ? $lastException->getMessage() : 'Unknown error') . '</p>'
        . '</div>'
    );
}
